# Betty's Bird Boutique — Agentic Bird Brain

A customer-support agent for Betty's Bird Boutique, built with Google's Agent Development Kit (ADK) on Google Cloud. It answers questions about the store (hours, history, staff, prices) and about pet birds, remembers earlier turns of the conversation, and stays on topic. It never takes orders: when a customer wants to buy something, it gives the price and invites them to visit the store.

| Tool | Source of truth | Implementation |
|---|---|---|
| `datastore_search_tool` | The store PDFs in `starter/docs/` (hours, history, staff) | Vertex AI Search data store queried with `google-cloud-discoveryengine` (`starter/datastore.py`) |
| `bird_web_search_agent` | The web | A separate Gemini agent with Grounding with Google Search, wrapped as an `AgentTool` (`starter/search_agent.py`) |
| `get-product-price` | `products` table in Cloud SQL for MySQL | MCP Toolbox for Databases (`starter/tools.yaml`), loaded with `ToolboxSyncClient` |
| `get_current_date` | System clock | Plain function (`starter/date_tool.py`), so "Are you open today?" works |

## Getting Started

### Dependencies

- A Google Cloud project with billing (the Udacity Cloud Lab works) and Cloud Shell
- Python 3.10+ (Cloud Shell's default is fine)
- Python packages in `starter/requirements.txt`: `google-adk`, `google-cloud-discoveryengine`, `toolbox-core==0.5.3`, `tzdata`
- MCP Toolbox for Databases server **v0.20.0**, downloaded by `scripts/run_agent.sh`. It is pinned because v0.20.0 uses the `sources:` / `tools:` + `kind:` format in `tools.yaml`; newer 1.x servers use a different format.

### Installation

All steps run in **Cloud Shell**, which is already authenticated to your project, so no service-account key is needed.

1. Upload this project folder to Cloud Shell (⋮ → Upload), then `cd` into it.
2. Create the cloud resources and the `.env` file:
   ```bash
   bash scripts/setup_gcp.sh
   ```
   This creates a Cloud SQL MySQL instance (`betty` database from `starter/docs/betty_db.sql`, read-only user `betty_reader`), a bucket with the PDFs, and a Vertex AI Search data store and app. It takes about 10–15 minutes.
3. Start MCP Toolbox and the ADK web previewer:
   ```bash
   bash scripts/run_agent.sh
   ```
   Then choose **Web Preview → Preview on port 8080** and pick the `starter` agent.
4. When finished, delete the resources so the lab budget stops being used:
   ```bash
   bash scripts/teardown_gcp.sh
   ```

To run without the scripts, copy `.env.example` to `.env`, fill it in, and run:

```bash
cd starter && ../toolbox --tools-file tools.yaml
adk web .                # from the project folder
```

## Testing

### Break Down Tests

| Test | What it checks | How |
|---|---|---|
| Toolbox smoke test | Toolbox loaded `tools.yaml`, reached MySQL, and the `LIKE` query works | `run_agent.sh` calls `get-product-price` with `"seed"`. The response should list Bird Seed Mix and Sunflower Seeds. |
| Assessment conversation | All three tools in one session, plus memory across turns | In `adk web`: "When are you open on Thursday?", "Who is Betty?", "What kind of bird did she own?", "What do they eat?", "Can I buy that from you?" |
| Guardrail | Off-topic questions are refused without tool calls | e.g. "Who won the World Cup?" |
| No orders | The agent gives a price and invites a visit instead of taking an order | e.g. "Please order two bags of millet for delivery." |
| Model comparison | gemini-2.5-pro vs flash vs flash-lite on the same conversation | `bash scripts/run_agent.sh --no-web` then `.venv/bin/python scripts/compare_models.py` → `evidence/model-comparison.md` |

## Project Instructions

| Requirement | Where |
|---|---|
| Root agent, `InMemorySessionService`, model choice with justification | `starter/agent.py` |
| Persona, tool guidance, topic boundaries, no orders | `starter/agent-prompt.txt` |
| `get-product-price` (`kind: mysql-sql`, `LIKE` with wildcards and `?`, env-based source) | `starter/tools.yaml` |
| `search()` with `SearchRequest` (serving config, query, content search spec, plus chunk, query expansion and spell correction specs) and `datastore_search_tool` | `starter/datastore.py` |
| Grounded search agent (`google_search`) wrapped as `AgentTool`, model choice with justification | `starter/search_agent.py`, `starter/search-prompt.txt` |
| Stand-out: date awareness | `starter/date_tool.py` |
| Screenshot evidence | `evidence/` (see `evidence/SCREENSHOT-GUIDE.md`) |

## Built With

* [Google Agent Development Kit](https://google.github.io/adk-docs/) - agent framework and `adk web` test UI
* [Gemini on Vertex AI](https://cloud.google.com/vertex-ai/generative-ai/docs) - models for the root agent and the search agent
* [Vertex AI Search](https://cloud.google.com/generative-ai-app-builder/docs) - search over the store PDFs
* [MCP Toolbox for Databases](https://github.com/googleapis/genai-toolbox) - MySQL tool server
* [Cloud SQL for MySQL](https://cloud.google.com/sql/docs/mysql) - product price database

## License
[License](../LICENSE.md)
