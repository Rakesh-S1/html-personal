#!/usr/bin/env bash
# One-time Google Cloud setup for Betty's Bird Boutique agent. Run in Cloud Shell, from the
# project folder (the one containing starter/ and scripts/):
#
#     bash scripts/setup_gcp.sh
#
# Creates (all names can be overridden with environment variables):
#   - Cloud SQL for MySQL instance  $SQL_INSTANCE  (smallest tier, MySQL 8.0, public IP)
#       database `betty` from starter/docs/betty_db.sql + read-only user `betty_reader`
#   - Cloud Storage bucket          gs://$BUCKET   with the three store PDFs
#   - Vertex AI Search data store   $DATASTORE_ID  (layout parsing + chunking) and app $ENGINE_ID
#   - ../.env (project folder)      with every value the agent and Toolbox need
#
# Cost: the Cloud SQL instance is the only thing that bills while idle (~$0.01-0.02/hour).
# Run scripts/teardown_gcp.sh when you are finished.
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$PROJECT_DIR"

PROJECT_ID="${PROJECT_ID:-$(gcloud config get-value project 2>/dev/null)}"
REGION="${REGION:-us-central1}"
SQL_INSTANCE="${SQL_INSTANCE:-betty-sql}"
BUCKET="${BUCKET:-${PROJECT_ID}-betty-docs}"
DATASTORE_ID="${DATASTORE_ID:-betty-store-docs}"
ENGINE_ID="${ENGINE_ID:-betty-search-app}"
DB_USER="betty_reader"

[ -n "$PROJECT_ID" ] || { echo "No project set. Run: gcloud config set project <your-project-id>"; exit 1; }
step() { printf '\n==== %s ====\n' "$*"; }
gen_password() { python3 -c "import secrets,string;a=string.ascii_letters+string.digits;print(''.join(secrets.choice(a) for _ in range(24)))"; }

step "Project $PROJECT_ID, region $REGION"
gcloud config set project "$PROJECT_ID" >/dev/null

step "Enabling APIs (Cloud SQL Admin, Vertex AI, Discovery Engine, Storage)"
gcloud services enable sqladmin.googleapis.com aiplatform.googleapis.com \
  discoveryengine.googleapis.com storage.googleapis.com

# ---------------------------------------------------------------- Cloud SQL
SHELL_IP="$(curl -s https://ifconfig.me)"
ROOT_PASSWORD="$(gen_password)"
DB_PASSWORD="$(gen_password)"

if gcloud sql instances describe "$SQL_INSTANCE" >/dev/null 2>&1; then
  step "Cloud SQL instance $SQL_INSTANCE already exists - resetting passwords, authorizing $SHELL_IP"
  gcloud sql instances patch "$SQL_INSTANCE" --authorized-networks="$SHELL_IP/32" --quiet
  gcloud sql users set-password root --host=% --instance="$SQL_INSTANCE" --password="$ROOT_PASSWORD"
else
  step "Creating Cloud SQL for MySQL instance $SQL_INSTANCE (takes 5-10 minutes)"
  gcloud sql instances create "$SQL_INSTANCE" \
    --database-version=MYSQL_8_0 --edition=enterprise --tier=db-f1-micro \
    --region="$REGION" --storage-type=HDD --storage-size=10 \
    --no-backup --availability-type=zonal \
    --root-password="$ROOT_PASSWORD" \
    --authorized-networks="$SHELL_IP/32"
fi
SQL_HOST="$(gcloud sql instances describe "$SQL_INSTANCE" --format='value(ipAddresses[0].ipAddress)')"
echo "MySQL public IP: $SQL_HOST (authorized network: $SHELL_IP/32 - this Cloud Shell)"

command -v mysql >/dev/null || { echo "Installing MySQL client"; sudo apt-get -qq install -y default-mysql-client; }

step "Loading starter/docs/betty_db.sql and creating read-only user $DB_USER"
export MYSQL_PWD="$ROOT_PASSWORD"   # keeps the password off the command line
mysql -h "$SQL_HOST" -u root < starter/docs/betty_db.sql
mysql -h "$SQL_HOST" -u root -e "
  CREATE USER IF NOT EXISTS '$DB_USER'@'%' IDENTIFIED BY '$DB_PASSWORD';
  ALTER USER '$DB_USER'@'%' IDENTIFIED BY '$DB_PASSWORD';
  GRANT SELECT ON betty.* TO '$DB_USER'@'%';
  FLUSH PRIVILEGES;"
unset MYSQL_PWD
MYSQL_PWD="$DB_PASSWORD" mysql -h "$SQL_HOST" -u "$DB_USER" betty \
  -e "SELECT COUNT(*) AS products_visible_to_betty_reader FROM products;"

# ---------------------------------------------------------------- Cloud Storage
step "Uploading the store PDFs to gs://$BUCKET"
gcloud storage buckets describe "gs://$BUCKET" >/dev/null 2>&1 || \
  gcloud storage buckets create "gs://$BUCKET" --location=US --uniform-bucket-level-access
gcloud storage cp starter/docs/*.pdf "gs://$BUCKET/docs/"

# ---------------------------------------------------------------- Vertex AI Search
DE="https://discoveryengine.googleapis.com/v1/projects/$PROJECT_ID/locations/global/collections/default_collection"
api() {  # api METHOD URL [JSON]
  curl -s -X "$1" "$2" -H "Authorization: Bearer $(gcloud auth print-access-token)" \
    -H "x-goog-user-project: $PROJECT_ID" -H "Content-Type: application/json" ${3:+-d "$3"}
}
wait_op() {  # wait_op OPERATION_NAME
  for _ in $(seq 1 90); do
    out="$(api GET "https://discoveryengine.googleapis.com/v1/$1")"
    if echo "$out" | grep -q '"done": true'; then echo "$out" | grep -E '"error"|successCount|failureCount' || true; return 0; fi
    sleep 10
  done
  echo "Timed out waiting for $1 - check the Vertex AI Search console."; return 1
}

step "Creating Vertex AI Search data store $DATASTORE_ID (layout parser + chunking)"
if api GET "$DE/dataStores/$DATASTORE_ID" | grep -q '"name"'; then
  echo "Data store already exists"
else
  out="$(api POST "$DE/dataStores?dataStoreId=$DATASTORE_ID" '{
    "displayName": "Bettys Bird Boutique documents",
    "industryVertical": "GENERIC",
    "solutionTypes": ["SOLUTION_TYPE_SEARCH"],
    "contentConfig": "CONTENT_REQUIRED",
    "documentProcessingConfig": {
      "defaultParsingConfig": {"layoutParsingConfig": {}},
      "chunkingConfig": {"layoutBasedChunkingConfig": {"chunkSize": 500, "includeAncestorHeadings": true}}
    }}')"
  echo "$out" | grep -q '"error"' && { echo "$out"; exit 1; }
  op="$(echo "$out" | python3 -c 'import json,sys;print(json.load(sys.stdin).get("name",""))')"
  [ -n "$op" ] && wait_op "$op"
fi

step "Importing gs://$BUCKET/docs/*.pdf into the data store (a few minutes)"
out="$(api POST "$DE/dataStores/$DATASTORE_ID/branches/default_branch/documents:import" "{
  \"gcsSource\": {\"inputUris\": [\"gs://$BUCKET/docs/*.pdf\"], \"dataSchema\": \"content\"},
  \"reconciliationMode\": \"INCREMENTAL\"}")"
echo "$out" | grep -q '"error"' && { echo "$out"; exit 1; }
wait_op "$(echo "$out" | python3 -c 'import json,sys;print(json.load(sys.stdin)["name"])')"

step "Creating the Vertex AI Search app $ENGINE_ID"
if api GET "$DE/engines/$ENGINE_ID" | grep -q '"name"'; then
  echo "Search app already exists"
else
  out="$(api POST "$DE/engines?engineId=$ENGINE_ID" "{
    \"displayName\": \"Bettys Bird Boutique search\",
    \"dataStoreIds\": [\"$DATASTORE_ID\"],
    \"solutionType\": \"SOLUTION_TYPE_SEARCH\",
    \"industryVertical\": \"GENERIC\",
    \"searchEngineConfig\": {\"searchTier\": \"SEARCH_TIER_ENTERPRISE\", \"searchAddOns\": [\"SEARCH_ADD_ON_LLM\"]}}")"
  echo "$out" | grep -q '"error"' && { echo "$out"; exit 1; }
  op="$(echo "$out" | python3 -c 'import json,sys;print(json.load(sys.stdin).get("name",""))')"
  [ -n "$op" ] && wait_op "$op"
fi

# ---------------------------------------------------------------- .env
step "Writing $PROJECT_DIR/.env"
cat > .env <<EOF
# Betty's Bird Boutique agent - generated by scripts/setup_gcp.sh on $(date -u +%Y-%m-%d)
# Gemini on Vertex AI
GOOGLE_GENAI_USE_VERTEXAI=TRUE
GOOGLE_CLOUD_PROJECT=$PROJECT_ID
GOOGLE_CLOUD_LOCATION=$REGION
# Vertex AI Search (store PDFs)
DATASTORE_PROJECT_ID=$PROJECT_ID
DATASTORE_ENGINE_ID=$ENGINE_ID
DATASTORE_LOCATION=global
# Cloud SQL for MySQL via MCP Toolbox (read-only user)
MYSQL_HOST=$SQL_HOST
MYSQL_PORT=3306
MYSQL_DATABASE=betty
MYSQL_USER=$DB_USER
MYSQL_PASSWORD=$DB_PASSWORD
TOOLBOX_URL=http://127.0.0.1:5000
# Used by run_agent.sh to re-authorize Cloud Shell's IP after a restart
BETTY_SQL_INSTANCE=$SQL_INSTANCE
EOF
chmod 600 .env

step "Done"
echo "Next: bash scripts/run_agent.sh   (starts MCP Toolbox + adk web on port 8080)"
echo "Search indexing can take a few more minutes after import; if the first store question"
echo "returns 'No results found.', wait 5 minutes and ask again."
