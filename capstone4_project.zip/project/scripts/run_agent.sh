#!/usr/bin/env bash
# Start MCP Toolbox (product database) and the ADK web previewer. Run in Cloud Shell from the
# project folder after scripts/setup_gcp.sh:
#
#     bash scripts/run_agent.sh            # Toolbox + adk web on port 8080
#     bash scripts/run_agent.sh --no-web   # Toolbox only (for scripts/compare_models.py)
#
# Then use Cloud Shell's "Web Preview" button -> "Preview on port 8080" and pick "starter".
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$PROJECT_DIR"
TOOLBOX_VERSION="v0.20.0"   # uses the sources:/tools: "kind:" format in starter/tools.yaml
PORT="${PORT:-8080}"

[ -f .env ] || { echo "No .env - run scripts/setup_gcp.sh first."; exit 1; }
set -a; . ./.env; set +a

# Cloud Shell's public IP can change between sessions; Cloud SQL only accepts authorized IPs.
SHELL_IP="$(curl -s https://ifconfig.me)"
if [ -n "${BETTY_SQL_INSTANCE:-}" ]; then
  current="$(gcloud sql instances describe "$BETTY_SQL_INSTANCE" --format='value(settings.ipConfiguration.authorizedNetworks[0].value)' 2>/dev/null || true)"
  if [ "$current" != "$SHELL_IP/32" ]; then
    echo "Authorizing this Cloud Shell ($SHELL_IP) on Cloud SQL instance $BETTY_SQL_INSTANCE ..."
    gcloud sql instances patch "$BETTY_SQL_INSTANCE" --authorized-networks="$SHELL_IP/32" --quiet
  fi
fi

if [ ! -x .venv/bin/python ]; then
  echo "Creating .venv and installing requirements ..."
  python3 -m venv .venv
  .venv/bin/pip install -q --upgrade pip
  .venv/bin/pip install -q -r starter/requirements.txt
fi

if [ ! -x ./toolbox ]; then
  echo "Downloading MCP Toolbox $TOOLBOX_VERSION ..."
  curl -sSL -o toolbox "https://storage.googleapis.com/genai-toolbox/$TOOLBOX_VERSION/linux/amd64/toolbox"
  chmod +x toolbox
fi

# (Re)start Toolbox in the background, from the folder that holds tools.yaml
pkill -f "toolbox --tools-file" 2>/dev/null || true
(cd starter && nohup ../toolbox --tools-file "tools.yaml" --port 5000 > ../toolbox.log 2>&1 &)
for _ in $(seq 1 20); do
  curl -s http://127.0.0.1:5000/api/toolset >/dev/null 2>&1 && break
  sleep 1
done
if ! curl -s http://127.0.0.1:5000/api/toolset | grep -q "get-product-price"; then
  echo "Toolbox did not start correctly - last lines of toolbox.log:"; tail -20 toolbox.log; exit 1
fi
echo "Toolbox is running on $TOOLBOX_URL. Database check (keyword 'seed'):"
curl -s -X POST http://127.0.0.1:5000/api/tool/get-product-price/invoke \
  -H "Content-Type: application/json" -d '{"product_name": "seed"}'
echo

[ "${1:-}" = "--no-web" ] && { echo "Toolbox only (--no-web)."; exit 0; }

echo
echo "Starting adk web on port $PORT. In Cloud Shell: Web Preview -> Preview on port $PORT,"
echo "then choose the 'starter' agent. Press Ctrl+C to stop (Toolbox keeps running; 'pkill toolbox')."
exec .venv/bin/adk web --port "$PORT" .
