#!/usr/bin/env bash
# Delete everything scripts/setup_gcp.sh created, so the lab budget stops being spent.
# Run in Cloud Shell from the project folder:   bash scripts/teardown_gcp.sh
set -uo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$PROJECT_DIR"
PROJECT_ID="${PROJECT_ID:-$(gcloud config get-value project 2>/dev/null)}"
SQL_INSTANCE="${SQL_INSTANCE:-betty-sql}"
BUCKET="${BUCKET:-${PROJECT_ID}-betty-docs}"
DATASTORE_ID="${DATASTORE_ID:-betty-store-docs}"
ENGINE_ID="${ENGINE_ID:-betty-search-app}"
DE="https://discoveryengine.googleapis.com/v1/projects/$PROJECT_ID/locations/global/collections/default_collection"
api() { curl -s -X "$1" "$2" -H "Authorization: Bearer $(gcloud auth print-access-token)" -H "x-goog-user-project: $PROJECT_ID"; }

echo "This deletes: Cloud SQL $SQL_INSTANCE, search app $ENGINE_ID, data store $DATASTORE_ID, bucket gs://$BUCKET"
read -r -p "Type DELETE to continue: " answer
[ "$answer" = "DELETE" ] || { echo "Cancelled."; exit 0; }

pkill -f "toolbox --tools-file" 2>/dev/null
echo "- search app";  api DELETE "$DE/engines/$ENGINE_ID" >/dev/null; sleep 20
echo "- data store";  api DELETE "$DE/dataStores/$DATASTORE_ID" >/dev/null
echo "- Cloud SQL";   gcloud sql instances delete "$SQL_INSTANCE" --quiet
echo "- bucket";      gcloud storage rm -r "gs://$BUCKET" --quiet
rm -f .env
echo "Done. Check the console (Cloud SQL, Vertex AI Search, Cloud Storage) that nothing is left."
