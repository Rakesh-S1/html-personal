"""Run the assessment conversation on several Gemini models and compare them.

For each model this creates a fresh in-memory session, asks the five assessment questions in
order (so follow-ups like "she" and "that" rely on conversation memory), and records per turn:
latency, which tools were called (with arguments), and the start of the answer.

Run from the project folder after `scripts/run_agent.sh --no-web` (Toolbox must be running):
    python scripts/compare_models.py                       # all three models
    python scripts/compare_models.py gemini-2.5-flash      # just one
Writes evidence/model-comparison.md.
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
import time
from pathlib import Path

from dotenv import load_dotenv

PROJECT_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_DIR))
load_dotenv(PROJECT_DIR / ".env")

from google.adk.runners import Runner  # noqa: E402
from google.genai import types  # noqa: E402

from starter.agent import root_agent, session_service  # noqa: E402

QUESTIONS = [
    "When are you open on Thursday?",
    "Who is Betty?",
    "What kind of bird did she own?",
    "What do they eat?",
    "Can I buy that from you?",
]
DEFAULT_MODELS = ["gemini-2.5-pro", "gemini-2.5-flash", "gemini-2.5-flash-lite"]


async def run_conversation(model: str) -> list[dict]:
    agent = root_agent.clone(update={"model": model})
    runner = Runner(agent=agent, app_name="betty_compare", session_service=session_service)
    session = await session_service.create_session(app_name="betty_compare", user_id="model-test")
    turns = []
    for question in QUESTIONS:
        start = time.perf_counter()
        tools, answer = [], ""
        message = types.Content(role="user", parts=[types.Part(text=question)])
        try:
            async for event in runner.run_async(user_id="model-test", session_id=session.id, new_message=message):
                for call in event.get_function_calls():
                    tools.append(f"{call.name}({json.dumps(call.args, ensure_ascii=False)})")
                if event.is_final_response() and event.content and event.content.parts:
                    answer = "".join(p.text or "" for p in event.content.parts).strip()
        except Exception as e:  # keep comparing the other models
            answer = f"ERROR: {e}"
        turns.append({"question": question, "seconds": time.perf_counter() - start,
                      "tools": tools, "answer": answer})
        print(f"[{model}] {question} -> {turns[-1]['seconds']:.1f}s, tools={tools}")
    return turns


def to_markdown(results: dict[str, list[dict]]) -> str:
    lines = ["# Model comparison - assessment conversation", "",
             f"Session id per model is fresh; root agent tools: datastore_search_tool, "
             f"bird_web_search_agent, get-product-price, get_current_date.", "",
             "| Model | Total time (s) | Tool calls | Turns that called the expected tool |",
             "|---|---:|---:|---|"]
    expected = ["datastore_search_tool", "datastore_search_tool", None,
                "bird_web_search_agent", "get-product-price"]
    for model, turns in results.items():
        total = sum(t["seconds"] for t in turns)
        n_calls = sum(len(t["tools"]) for t in turns)
        hits = sum(1 for t, e in zip(turns, expected) if e and any(c.startswith(e) for c in t["tools"]))
        lines.append(f"| {model} | {total:.1f} | {n_calls} | {hits}/4 |")
    for model, turns in results.items():
        lines += ["", f"## {model}", ""]
        for t in turns:
            lines.append(f"**Q: {t['question']}** ({t['seconds']:.1f}s)  ")
            lines.append(f"Tools: {', '.join(t['tools']) or 'none'}  ")
            lines.append(f"A: {t['answer'][:600]}")
            lines.append("")
    return "\n".join(lines)


async def main() -> None:
    models = sys.argv[1:] or DEFAULT_MODELS
    results = {m: await run_conversation(m) for m in models}
    out = PROJECT_DIR / "evidence" / "model-comparison.md"
    out.parent.mkdir(exist_ok=True)
    out.write_text(to_markdown(results), encoding="utf-8")
    print(f"\nWrote {out}")


if __name__ == "__main__":
    asyncio.run(main())
