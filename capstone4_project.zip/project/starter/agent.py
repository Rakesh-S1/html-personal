"""Root agent for Betty's Bird Boutique: answers questions about the store and about birds.

Run from the project folder (the parent of this package):
    adk web            # then open the URL it prints and pick "starter"

Tools:
    - datastore_search_tool  (datastore.py)    store PDFs via Vertex AI Search
    - bird_web_search_agent  (search_agent.py) general bird questions via Grounding with Google Search
    - get-product-price      (tools.yaml)      product prices from Cloud SQL via MCP Toolbox
    - get_current_date       (date_tool.py)    today's date, for "are you open today?"
"""
import logging
import os

from google.adk.agents import Agent
from google.adk.sessions import InMemorySessionService
from toolbox_core import ToolboxSyncClient

from .datastore import datastore_search_tool
from .date_tool import get_current_date
from .search_agent import search_agent_tool

logger = logging.getLogger(__name__)

# Configure short-term session to use the in-memory service
# Conversations only need to remember earlier turns of the *current* chat ("she", "that bird"),
# not past visits, so sessions are kept in memory and disappear when the server stops.
session_service = InMemorySessionService()

# Read the instructions from a file in the same
# directory as this agent.py file.
script_dir = os.path.dirname(os.path.abspath(__file__))
instruction_file_path = os.path.join(script_dir, "agent-prompt.txt")
with open(instruction_file_path, "r") as f:
    instruction = f.read()

# Model choice for the root agent: gemini-2.5-flash.
# The three required candidates (run scripts/compare_models.py to time them on the same
# test conversation):
# - gemini-2.5-pro: the strongest reasoning, but slower and several times the price per token.
#   Choosing between four tools and resolving "she"/"that" from earlier turns does not need it,
#   and slow replies hurt a customer-facing chat.
# - gemini-2.5-flash: fast and inexpensive, with dependable function calling, including several
#   tool calls in one turn. The best balance of speed, cost and tool-use quality for this agent.
# - gemini-2.5-flash-lite: cheapest and fastest, but the weakest at multi-step tool use, e.g.
#   chaining store-docs -> web search -> price lookup, or picking a good keyword for the price
#   database, so it risks missed prices on exactly the questions this store cares about.
# Override with ROOT_AGENT_MODEL to compare models without editing code.
model = os.environ.get("ROOT_AGENT_MODEL", "gemini-2.5-flash")

# Product database tool, served by MCP Toolbox for Databases (see tools.yaml).
toolbox_url = os.environ.get("TOOLBOX_URL", "http://127.0.0.1:5000")
db_client = ToolboxSyncClient(toolbox_url)


def load_product_price_tool():
    """Loads the get-product-price tool from the Toolbox server, or None if it is unreachable.

    Failing soft keeps the rest of the agent usable (and the error visible in the logs) when the
    Toolbox server was not started, instead of the whole agent failing to load.
    """
    try:
        return db_client.load_tool("get-product-price")
    except Exception as e:  # server not running, wrong URL, tool name missing, ...
        logger.error("Could not load get-product-price from Toolbox at %s: %s", toolbox_url, e)
        db_client.close()
        return None


product_price_tool = load_product_price_tool()

# Set up the tools that we will be using for the root agent
tools = [
    datastore_search_tool,
    search_agent_tool,
    get_current_date,
]
if product_price_tool is not None:
    tools.append(product_price_tool)

# Create our agent
root_agent = Agent(
    name="bettys_bird_boutique_agent",
    description=(
        "Customer service assistant for Betty's Bird Boutique that answers questions about the "
        "store (hours, history, staff, product prices) and about pet birds, without taking orders."
    ),
    instruction=instruction,
    model=model,
    tools=tools,
)
