"""Date-awareness tool (project stand-out suggestion).

The store hours document lists hours by weekday, but the model does not know what day it is.
This tool gives the agent today's date and weekday so it can answer "Are you open today?".
"""
import os
from datetime import datetime, timezone, tzinfo
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError


def get_current_date() -> dict[str, str]:
    """Returns today's date and day of the week in the store's local time zone.

    Use this before answering any question that depends on today's date, such as
    "Are you open today?" or "Are you open tomorrow?". Then look up that weekday's hours
    with the store document search tool.

    Returns:
        A dict with "date" (YYYY-MM-DD), "day_of_week" (e.g. "Thursday"), "time" (HH:MM, 24h)
        and "time_zone".
    """
    tz_name = os.environ.get("STORE_TIME_ZONE", "America/Chicago")
    tz: tzinfo
    try:
        tz = ZoneInfo(tz_name)
    except ZoneInfoNotFoundError:
        # No time-zone database available (e.g. Windows without the tzdata package)
        tz_name, tz = "UTC", timezone.utc
    now = datetime.now(tz)
    return {
        "date": now.strftime("%Y-%m-%d"),
        "day_of_week": now.strftime("%A"),
        "time": now.strftime("%H:%M"),
        "time_zone": tz_name,
    }
