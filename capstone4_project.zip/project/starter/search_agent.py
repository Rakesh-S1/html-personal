"""General bird-knowledge tool: a small agent that uses Grounding with Google Search.

Gemini's built-in google_search tool cannot be combined with other tools in the same agent,
so it lives in its own agent and is handed to the root agent wrapped in an AgentTool. The
root agent calls it like any other tool with a question, and gets back a grounded answer
that lists its web sources.
"""
import os

from google.adk.agents import Agent
from google.adk.tools import AgentTool, google_search

# Definition of an agent tool that accesses Grounding with Google Search

# Read the instructions from a file in the same
# directory as this file.
script_dir = os.path.dirname(os.path.abspath(__file__))
instruction_file_path = os.path.join(script_dir, "search-prompt.txt")
with open(instruction_file_path, "r") as f:
  instruction = f.read()

# Model choice for the search agent: gemini-2.5-flash.
# - It supports Grounding with Google Search on Vertex AI and is fast enough to answer inside a
#   live chat turn; the search agent runs on top of the root agent's own model call, so its
#   latency adds directly to the customer's wait.
# - Its job is narrow (search, then summarise 3-5 facts with sources), so gemini-2.5-pro's extra
#   reasoning adds cost and seconds without a better answer.
# - gemini-2.5-flash-lite also supports grounding and is cheaper and faster, but it is the
#   weakest of the three at turning several search results into one specific, accurate answer
#   (diet details, foods to avoid), which is exactly what this tool is for.
# Override with SEARCH_AGENT_MODEL to compare models without editing code
# (scripts/compare_models.py runs the same questions on all three).
search_model = os.environ.get("SEARCH_AGENT_MODEL", "gemini-2.5-flash")

search_agent = Agent(
    name="bird_web_search_agent",
    description=(
        "Answers general questions about birds (species, diet, care, behaviour, health, "
        "lifespan) using Grounding with Google Search, and cites the web sources it used."
    ),
    instruction=instruction,
    model=search_model,
    tools=[google_search],
)

# Wrap the search agent so the root agent can call it as a tool.
search_agent_tool = AgentTool(agent=search_agent)
