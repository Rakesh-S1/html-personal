"""Vertex AI Search (Discovery Engine) tool: answers store questions from Betty's PDFs.

The PDFs in docs/ (bettys-hours.pdf, bettys-history.pdf, bettys-staff.pdf) are uploaded to a
Cloud Storage bucket and indexed by a Vertex AI Search data store. The root agent calls
`datastore_search_tool`, which calls `search()` and returns the matching passages.
"""
import os

from google.api_core.client_options import ClientOptions
from google.cloud import discoveryengine_v1 as discoveryengine

# Definition of a tool that accesses a Vertex AI Search Datastore

#
# This is based on code provided by Google at
# https://cloud.google.com/generative-ai-app-builder/docs/samples/genappbuilder-search
#
# Changes from the Google sample, and why:
# - The request asks for CHUNKS (search_result_mode) instead of whole documents with
#   summaries. Our PDFs are short and each chunk is a self-contained passage (one day's hours,
#   one staff bio), so passing the chunks to the root agent gives it the exact source text to
#   quote instead of an LLM-written summary. Data stores created without document chunking
#   cannot return chunks; set DATASTORE_RESULT_MODE=DOCUMENTS to use extractive segments then.
# - page_size is small (5): only a few passages are ever relevant and fewer tokens keep the
#   root agent fast and focused.
# - Query expansion and spell correction are AUTO so customer phrasings like
#   "when r u open thursday" still match the hours document.
#
# The object definitions aren't available to all IDEs because of Google's ProtoBuf
# implementation, so the IDE may generate a warning, but work fine. Dicts are used below,
# with the matching discoveryengine class named in a comment above each one.
# You can see the definitions at
# https://cloud.google.com/python/docs/reference/discoveryengine/latest/google.cloud.discoveryengine_v1.types
#
def search(
    project_id: str,
    location: str,
    engine_id: str,
    search_query: str,
    result_mode: str = "CHUNKS",
    page_size: int = 5,
) -> list[str]:
    """Query a Vertex AI Search app and return the matching passages as plain strings.

    Args:
        project_id: Google Cloud project that owns the search app.
        location: Data store location ("global", "us" or "eu").
        engine_id: ID of the Vertex AI Search app (engine).
        search_query: The customer's question or keywords.
        result_mode: "CHUNKS" (needs a data store with document chunking) or "DOCUMENTS".
        page_size: Maximum number of results to return.

    Returns:
        A list of passages, each prefixed with the source document's title when known.
    """
    #  For more information, refer to:
    # https://cloud.google.com/generative-ai-app-builder/docs/locations#specify_a_multi-region_for_your_data_store
    # quota_project_id: with user credentials (Cloud Shell, `gcloud auth application-default
    # login`) the Discovery Engine API needs to know which project to bill the call to.
    client_options = ClientOptions(
        api_endpoint=(
            f"{location}-discoveryengine.googleapis.com" if location != "global" else None
        ),
        quota_project_id=project_id or None,
    )

    # Create a client
    client = discoveryengine.SearchServiceClient(client_options=client_options)

    # The full resource name of the search app serving config
    serving_config = f"projects/{project_id}/locations/{location}/collections/default_collection/engines/{engine_id}/servingConfigs/default_config"

    use_chunks = result_mode.upper() == "CHUNKS"

    # discoveryengine.SearchRequest.ContentSearchSpec
    if use_chunks:
        content_search_spec = {
            "search_result_mode": discoveryengine.SearchRequest.ContentSearchSpec.SearchResultMode.CHUNKS,
            # discoveryengine.SearchRequest.ContentSearchSpec.ChunkSpec:
            # include the neighbouring chunk so a passage split mid-paragraph keeps its context
            "chunk_spec": {"num_previous_chunks": 1, "num_next_chunks": 1},
        }
    else:
        content_search_spec = {
            "search_result_mode": discoveryengine.SearchRequest.ContentSearchSpec.SearchResultMode.DOCUMENTS,
            # discoveryengine.SearchRequest.ContentSearchSpec.SnippetSpec
            "snippet_spec": {"return_snippet": True},
            # discoveryengine.SearchRequest.ContentSearchSpec.ExtractiveContentSpec
            "extractive_content_spec": {"max_extractive_segment_count": 2},
        }

    # discoveryengine.SearchRequest
    request = {
        "serving_config": serving_config,
        "query": search_query,
        "page_size": page_size,
        "content_search_spec": content_search_spec,
        # discoveryengine.SearchRequest.QueryExpansionSpec
        "query_expansion_spec": {
            "condition": discoveryengine.SearchRequest.QueryExpansionSpec.Condition.AUTO,
        },
        # discoveryengine.SearchRequest.SpellCorrectionSpec
        "spell_correction_spec": {
            "mode": discoveryengine.SearchRequest.SpellCorrectionSpec.Mode.AUTO,
        },
    }

    page_result = client.search(request)

    # Format the results as a list of strings the agent can read and quote
    results: list[str] = []
    for result in page_result:
        if use_chunks:
            results.extend(_chunk_passages(result))
        else:
            results.extend(_document_passages(result))
        if len(results) >= page_size:
            break
    return results


def _chunk_passages(result) -> list[str]:
    """Turn one CHUNKS-mode SearchResult into '[title] text' strings (chunk plus neighbours)."""
    chunk = result.chunk
    if not chunk or not chunk.content:
        return []
    title = chunk.document_metadata.title if chunk.document_metadata else ""
    context = chunk.chunk_metadata
    parts = [c.content for c in context.previous_chunks] if context else []
    parts.append(chunk.content)
    if context:
        parts.extend(c.content for c in context.next_chunks)
    text = "\n".join(p.strip() for p in parts if p and p.strip())
    return [f"[{title}] {text}" if title else text]


def _document_passages(result) -> list[str]:
    """Turn one DOCUMENTS-mode SearchResult into strings from extractive segments or snippets."""
    data = dict(result.document.derived_struct_data or {})
    title = data.get("title") or data.get("link") or ""
    passages = [seg.get("content", "") for seg in data.get("extractive_segments", [])]
    if not any(passages):
        passages = [snip.get("snippet", "") for snip in data.get("snippets", [])]
    return [f"[{title}] {p}" if title else p for p in passages if p]


def datastore_search_tool(search_query: str) -> list[str] | str:
    """Searches Betty's Bird Boutique store documents (PDFs) for store-specific information.

    Use this for questions about the store itself: opening hours for each day of the week,
    the store's history and founder Betty Winger, and the current staff, their roles and
    their own birds (including the store mascot).

    Args:
        search_query (str): What the customer wants to know about the store, as keywords or a
            short question, e.g. "Thursday opening hours" or "who is Betty".

    Returns:
        A list of passages from the store documents (each starts with the document title),
        "No results found." when nothing matches, or a message describing an error.
    """
    try:
        results = search(
            project_id=os.environ.get("DATASTORE_PROJECT_ID", os.environ.get("GOOGLE_CLOUD_PROJECT", "")),
            location=os.environ.get("DATASTORE_LOCATION", "global"),
            engine_id=os.environ.get("DATASTORE_ENGINE_ID", ""),
            search_query=search_query,
            result_mode=os.environ.get("DATASTORE_RESULT_MODE", "CHUNKS"),
        )
        if not results:
            return "No results found."
        return results
    except Exception as e:  # report the problem to the agent instead of crashing the turn
        return f"A problem occurred while searching the store documents: {e}"
