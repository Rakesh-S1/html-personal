# Screenshot guide (assessment evidence)

The rubric checks the screenshots for: the **session ID**, every question and full answer, and for
**each tool call the detailed request and response**. Save them in this `evidence/` folder,
numbered in order (e.g. `01-thursday-hours.png`).

## In `adk web`

1. Pick the `starter` agent, then click **+ New Session**. The session ID is shown at the top of the chat
   (and in the Sessions tab) — make sure it is visible in at least the first screenshot.
2. Ask the questions below one at a time, in this order, in the same session.
3. After each answer, click the tool-call chips in the chat (or open the **Events** tab and click the
   `functionCall` and `functionResponse` events). The side panel shows the request arguments and
   the response. Take one screenshot of the chat + one of the request/response panel.

## The conversation

| # | Ask | Tool it should call | What the request/response should show |
|---|---|---|---|
| 1 | When are you open on Thursday? | `datastore_search_tool` | Request `search_query` about Thursday hours; response passage from `bettys-hours` with `Thursday: 9am - 5pm` |
| 2 | Who is Betty? | `datastore_search_tool` | Response passage from `bettys-history` ("our founder - Betty Winger ...") |
| 3 | What kind of bird did she own? | `datastore_search_tool` (the history says Pip was a budgie) and/or `bird_web_search_agent` | Answer: a budgie (budgerigar) named Pip |
| 4 | What do they eat? | `bird_web_search_agent` | Request is a full question naming budgies; response is grounded text ending with a `Sources:` line |
| 5 | Can I buy that from you? | `get-product-price` (often several calls: e.g. `seed`, `millet`, `pellet`) | Request `product_name` keyword; response rows such as `Bird Seed Mix 15.99`, `Millet 8.00`, `Parrot Pellets 28.99`. The answer gives prices and invites a store visit (no order taken). |

Extra screenshots that strengthen the submission (optional):

- **Not-found handling** (rubric: "appropriate handling of not-found scenarios"): ask
  "Do you sell bird cages?" — `get-product-price` returns no rows and the agent says it is not listed.
- **Guardrail**: "Who won the World Cup?" — polite refusal, no tool calls.
- **Date tool**: "Are you open today?" — `get_current_date`, then `datastore_search_tool`.

## Also capture

- The terminal where `run_agent.sh` started Toolbox (shows the `get-product-price` smoke test).
- `evidence/model-comparison.md` from `scripts/compare_models.py` (backs the model-choice comments).
