# Retail Customer Support Context Strategy

**Course:** Claude Certified Architect — Foundations / Course 1, Harness Engineering
**Module:** 2 — Context Engineering Foundations
**Status:** Solution exemplar
**Build:** Python 3.11+, `anthropic` SDK, runs in Docker with `$ANTHROPIC_API_KEY`

This is the reference solution. The system designs a context-management strategy for a 48-turn retail customer-support conversation that spans three issues — a refund inquiry (resolved), a subscription cancellation (resolved), and a payment-method update (active). The raw transcript is ~35,000 tokens; the assembled context is **the project's measurable output**, recorded in `runs/<run_id>/context.md` alongside `budget.json` (token accounting) and `eval.jsonl` (evaluation results against the compressed context).

The defining architectural choice is **application-side context engineering**: the harness owns the assembly, compression, and pruning decisions, not the model. This is the pattern to apply for context engineering ("trim verbose tool outputs … *before they accumulate in context*"). The cookbook labs demonstrate the *server-side* counterpart (`clear_tool_uses_20250919`, `compact_20260112`) — see "What I'd do next" below for the contrast.

---

## Context-window anatomy

```
┌─────────────────────────────────────────────────────────┐
│ Layer 5  System prompt                                  │  set at session start
├─────────────────────────────────────────────────────────┤
│ Layer 4  CLAUDE.md  (project + user + directory)        │  walked once at boot
├─────────────────────────────────────────────────────────┤
│ Layer 3  Memory / scratchpad files                      │  loaded on demand
├─────────────────────────────────────────────────────────┤
│ Layer 2  Conversation history     ← THIS PROJECT ──┐    │  appended each turn
│                                                    │    │  auto-compressed when full
├─────────────────────────────────────────────────────────┤
│ Layer 1  Current turn                                   │  the user's new message
└─────────────────────────────────────────────────────────┘
```

This project operates on **Layer 2** — the conversation history layer. We do not write CLAUDE.md or memory files. The strategy below decides what survives compression and where it sits inside the history block when it does.

## Why this layout?

The assembled context places **case facts at the top boundary**, **resolved-issue summaries in the compressible middle**, and **the active issue verbatim at the bottom boundary** — directly above the new user turn:

```
# Case Facts                                    ← top boundary, structured (≤ 600 tokens)
# Resolved: Refund inquiry                      ← middle, summary (~300-500 tokens)
# Resolved: Subscription cancellation           ← middle, summary (~300-500 tokens)
# Active issue: Payment-method update           ← bottom boundary, byte-exact verbatim
```

Three considerations drive this layout:

1. **Lost in the middle** — attention models reliably process content at the start and end of long inputs but degrade on middle sections. We park the *resolved* narrative — the part where small fidelity losses are acceptable — in the middle. The most decision-load-bearing content (case-facts identifiers; live turn-by-turn active conversation) sits at the boundaries where attention is strongest.

2. **Resolved-vs-active fidelity tradeoff** — for resolved issues, the facts that matter have stabilized (amounts, IDs, statuses, dates) and can be condensed without information loss. For the *active* issue, every turn-by-turn nuance is potentially decision-load-bearing because the resolution is still being worked out. We summarize the first, preserve the second byte-exact.

3. **The pass-complete-history baseline** — the standard guidance names "the importance of passing complete conversation history in subsequent API requests to maintain conversational coherence." This project deliberately deviates from that default *only* for resolved threads, where conversational coherence is no longer load-bearing. The active thread is preserved verbatim, so coherence on the live issue is uncompromised. The case-facts block exists precisely so that the resolved-thread compression cannot accidentally drop a fact the agent needs later — it's the **scratchpad** that survives compression (the term "scratchpad" is sometimes used for what this project calls the case-facts block; same pattern, different name).

## Before / after token budget

Token-counting methodology: **Anthropic `messages.count_tokens` endpoint** (model-authoritative) when `ANTHROPIC_API_KEY` is set; a documented `len(text) / 3.8` heuristic falls back when running against the Claude Code CLI subscription. Either path flows through the single canonical `retail_context.tokens.count` function.

Numbers below are from `runs/20260519-124910/budget.json` (Haiku 4.5, heuristic counter):

| Section | Tokens |
|---|---:|
| `case_facts` | 149 |
| `resolved_refund` | 296 |
| `resolved_subscription` | 365 |
| `active` (verbatim) | 19,538 |
| **Assembled total** | **20,350** |
| Baseline transcript | 47,144 |
| **Reduction vs baseline** | **56.83%** |

Observations:
- The active (verbatim) segment dominates the budget at ~96% of the assembled context. That's by design — the active issue is where decisions are still being made, so fidelity is non-negotiable. Compression bought us back ~27,000 tokens, all from the resolved segments and the case-facts distillation.
- The case-facts block is **149 tokens** — small enough to sit at the top boundary without crowding out attention, dense enough to carry all 12 transactional fields.
- The resolved-segment summaries averaged ~330 tokens each, compressing ~13,000 tokens of raw narrative per segment to <500 tokens — ~97.5% reduction on the resolved portion.

## Eval results

Six questions span all three issues. Pass threshold ≥ 5/6 against the assembled context. A control variant strips the case-facts block; at least one of Q1/Q6 must fail in the control, proving the block carries information the summaries don't.

From `runs/20260519-124910/eval.jsonl`:

| # | Question (source) | Result | Model answer (excerpt) |
|---|---|:-:|---|
| Q1 | Actual refund amount for ORD-77310? (case facts) | ✅ | "...processed for order ORD-77310 was **$22.14**..." |
| Q2 | Why did the customer cancel their subscription? (subscription summary) | ✅ | "...due to a **duplicate charge**..." |
| Q3 | Failure code on the current payment-method update? (active verbatim) | ✅ | "...is **AVS_MISMATCH**..." |
| Q4 | Last-4 of the new card the customer is trying to add? (active verbatim) | ✅ | "...are **7782**..." |
| Q5 | Did the customer receive their subscription proration refund? (subscription summary) | ✅ | "...not yet... processed and initiated, but not yet received..." |
| Q6 | Structured status of the payment-method update issue? (case facts) | ✅ | "...the structured status token... is `in_progress`..." |
|   | **Total** | **6/6** |   |

**Control variant** (case-facts block stripped, Q1 + Q6 only):

| # | Result | Notes |
|---|:-:|---|
| Q1 | ✅ (unexpected pass) | The refund summary preserved `$22.14` verbatim, so the answer is still recoverable without the case-facts block. |
| Q6 | ❌ (expected fail) | The structured token `in_progress` appears only in the case-facts block; the active verbatim describes the state in prose ("still trying to figure out...") but never uses the snake_case status token. This is the strict load-bearing demonstration. |

The mixed control result is honest about how compression works in practice: when the summarizer preserves a numeric value (Q1), the case-facts block becomes a *cheaper* path to the same answer rather than the *only* path. Q6 demonstrates the strict case — case-facts is the only source of structured tokens.

See [`runs/20260519-124910/eval.jsonl`](runs/20260519-124910/eval.jsonl) and [`eval_control.jsonl`](runs/20260519-124910/eval_control.jsonl) for raw model answers.

## Quickstart

```bash
export ANTHROPIC_API_KEY=sk-ant-...

# Build the assembled context + run all evals + control:
python -m retail_context.run --all

# Build the assembled context only (no eval calls):
python -m retail_context.run --build

# Try a stronger summarization model:
python -m retail_context.run --all --model claude-sonnet-4-6
```

Artifacts land in `runs/<run_id>/`:
- `context.md`         — the assembled context (read this first)
- `budget.json`        — token accounting + methodology
- `case_facts_call.json` — LLM call log for case-facts extraction
- `eval.jsonl`         — per-question results
- `eval_control.jsonl` — control variant (Q1, Q6 with case facts stripped)

## What I'd do next

- **Session resumption** — when the same customer returns 4 hours later, do we reload the verbatim active segment or re-extract case facts and start fresh? The case-facts block is the right *durable* artifact to carry across `--resume`; the verbatim active section becomes stale (tool results referenced by turn-id may have expired in the backend).

- **Server-side context editing** is the modern API-level alternative this project deliberately does not use. The Anthropic Messages API exposes:
  - **`clear_tool_uses_20250919`** (beta `context-management-2025-06-27`) — drops stale tool-result blocks server-side, transparent to the model. Preferable to this project's `pruner.py` when the *whole tool result* can be dropped (vs preserving 5 of 40 fields).
  - **`compact_20260112`** (beta `compact-2026-01-12`) — server-side rolling compression of old turns. Preferable to this project's resolved-segment summarizer when the cutoff between "compressible" and "not" is *temporal* rather than *issue-based*.
  Application-side pruning (this project) wins when (a) the field-level keep-set is decision-specific, (b) the resolved-vs-active boundary is semantic, not chronological, or (c) you need the auditable artifact (`context.md`) for compliance review. Server-side editing wins on simplicity and zero application-layer state.

- **"Lost in the middle" negative variant** — re-run eval against an assembled context where the case-facts block is placed in the middle instead of the top. If Q1 and Q6 degrade, the position effect is empirically demonstrated, not just diagrammed.

- **Summarize the active segment too** — a stand-out experiment that demonstrates the fidelity-loss the verbatim choice avoids. Run Q3 and Q4 against a context where the active segment was *also* run through the compressor.

---

## Repo layout

```
module-02-retail-context-strategy/
├── pyproject.toml
├── README.md
├── retail_context/
│   ├── __init__.py
│   ├── __main__.py
│   ├── client.py               # Claude API + Claude Code CLI fallback
│   ├── tokens.py               # canonical token-count function
│   ├── transcript.py           # loader + segmentation
│   ├── case_facts.py           # extraction into persistent block
│   ├── pruner.py               # deterministic tool-output pruning
│   ├── compressor.py           # resolved-segment summarization
│   ├── assemble.py             # position-aware assembly
│   ├── evaluate.py             # eval-question runner
│   ├── run.py                  # CLI entry point
│   └── prompts/
│       └── compression_prompt.md
├── data/
│   ├── transcript_48turns.json     # 48-turn fixture, 3 issues
│   ├── lookup_order_response.json  # 57-field tool response fixture
│   └── eval_questions.json
├── scripts/
│   └── generate_transcript.py      # one-shot fixture authoring (Sonnet 4.6)
├── tests/
│   ├── test_transcript.py
│   ├── test_pruner.py
│   ├── test_assemble.py
│   └── test_antipatterns.py
└── runs/
    └── <run_id>/
        ├── context.md
        ├── budget.json
        ├── case_facts_call.json
        ├── eval.jsonl
        └── eval_control.jsonl
```
