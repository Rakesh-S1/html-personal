# Run summary — 20261111_163300

- Model: `claude-haiku-4-5-20251001`
- Fixtures processed: 8
- Estimated total cost: **$0.1196** USD

| claim_id | outcome | claim_type | severity | turns | clarifications_asked | input_tokens | output_tokens | est_cost_usd | elapsed_s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| claim_01_kitchen_fire | escalated |  | - | 2 | 0 | 6372 | 469 | 0.0087 | 5.4 |
| claim_02_stolen_bike | routed | theft | low | 6 | 0 | 21156 | 898 | 0.0256 | 10.9 |
| claim_03_water_damage | escalated |  | - | 2 | 0 | 5731 | 182 | 0.0066 | 3.2 |
| claim_04_neighbor_injury | routed | liability | medium | 4 | 0 | 14174 | 822 | 0.0183 | 10.3 |
| claim_05_auto_collision | routed | auto | high | 4 | 0 | 14952 | 984 | 0.0199 | 11.7 |
| claim_06_low_confidence_escalation | escalated |  | - | 2 | 0 | 6285 | 576 | 0.0092 | 6.8 |
| claim_07_tree_falls_on_car | escalated |  | - | 2 | 0 | 6388 | 505 | 0.0089 | 5.3 |
| claim_08_minor_porch_damage | routed | property_damage | low | 5 | 0 | 18126 | 855 | 0.0224 | 9.5 |
