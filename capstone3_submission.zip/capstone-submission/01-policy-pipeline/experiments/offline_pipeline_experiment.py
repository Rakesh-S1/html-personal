"""System 1 offline experiment: retry boundary + deterministic routing.

No API key was available, so the model's replies are SCRIPTED with the test
suite's own RecordedClient / make_tool_use_message (tests/conftest.py). Everything
else is the real pipeline code from 04-hitl-routing/solution:

  extract_with_retry  -> validator + retry-with-error-feedback (US-01)
  integration_pass    -> cross-field checks (US-03)
  route_extraction    -> deterministic (confidence AND reviewer AND integration) gate (US-04)
  apply_stratified_spot_check, write_routing_decisions (US-04)

Run from the policy-pipeline solution folder with its venv:
    .venv\\Scripts\\python <this file> <output routing json>
"""
from __future__ import annotations

import json
import sys
from dataclasses import asdict
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path.cwd()))  # make tests.conftest importable

from policy_extractor.records import Endorsement, PolicyExtraction, RetryFutileEscalation
from policy_extractor.retry import extract_with_retry
from policy_extractor.reviewer import FieldAgreement, ReviewResult, integration_pass
from policy_extractor.routing import (
    apply_stratified_spot_check,
    route_extraction,
    write_routing_decisions,
)
from tests.conftest import RecordedClient, load_policy_text, make_tool_use_message

FIELDS = ("policy_type", "premium_amount", "deductible", "coverage_limit", "endorsements", "exclusions")


def conf(default: float = 0.95, **overrides: float) -> dict[str, float]:
    c = {f: default for f in FIELDS}
    c.update(overrides)
    return c


def reply(**fields: Any) -> Any:
    return make_tool_use_message("extract_policy", fields)


def show(title: str, outcome: object, calls: int) -> None:
    kind = "ESCALATION" if isinstance(outcome, RetryFutileEscalation) else "EXTRACTION"
    print(f"\n--- {title}")
    print(f"API calls made: {calls}  ->  {kind}")
    record = asdict(outcome)  # type: ignore[call-overload]
    if kind == "EXTRACTION":
        record = {k: record[k] for k in ("policy_id", "policy_type", "premium_amount",
                                         "retry_count", "final_attempt_index") if k in record}
    print(json.dumps(record, indent=2, default=str))


print("=" * 78)
print("PART A - retry boundary (validated retry vs immediate escalation)")
print("=" * 78)

doc_001 = load_policy_text("POL-2025-001")
good_001 = dict(policy_type="auto", premium_amount=1847.62, deductible=500.0, coverage_limit=300000.0,
                endorsements=[{"name": "Rental Reimbursement Endorsement (AU-21)", "limit": None}],
                exclusions=["Racing or speed contest activity"], confidence=conf(0.96))

# A1 - unperturbed baseline: well-formed reply on the bundled document
client = RecordedClient([reply(**good_001)])
a1 = extract_with_retry(client=client, policy_id="POL-2025-001", document_text=doc_001, max_retries=3)
show("A1 baseline: POL-2025-001 as bundled, well-formed reply", a1, client.call_count)

# A2 - fixable error: first reply has a negative premium (a format error), second is correct
bad = dict(good_001, premium_amount=-1847.62)
client = RecordedClient([reply(**bad), reply(**good_001)])
a2 = extract_with_retry(client=client, policy_id="POL-2025-001", document_text=doc_001, max_retries=3)
show("A2 fixable: first reply premium_amount=-1847.62 (format error), then corrected", a2, client.call_count)
second_prompt = json.dumps(client.calls[1]["messages"])
print("retry prompt carried the validation error back to the model:",
      "premium_amount" in second_prompt and ("-1847.62" in second_prompt or "negative" in second_prompt))

# A3 - PERTURBATION: blank the premium in a copy of the document, so the value is genuinely absent
perturbed_doc = "\n".join(
    line for line in doc_001.splitlines() if "Total Policy Premium" not in line
)
assert "1,847.62" not in perturbed_doc
print("\n[perturbation] removed the line 'Total Policy Premium .... $ 1,847.62' from a copy of POL-2025-001")
# A model that does not invent values returns null for the missing premium
# (3 replies are queued so any retry would be visible as extra calls)
missing = dict(good_001, premium_amount=None, confidence=conf(0.96, premium_amount=0.1))
client = RecordedClient([reply(**missing)] * 3)
a3 = extract_with_retry(client=client, policy_id="POL-2025-001-perturbed", document_text=perturbed_doc,
                        max_retries=3)
show("A3 PERTURBED: premium genuinely absent, model returns null", a3, client.call_count)

# A4 - the bundled case with genuinely missing data (shape=missing_endorsement_schedule)
missing_009 = dict(policy_type="auto", premium_amount=1512.88, deductible=500.0, coverage_limit=300000.0,
                   endorsements=None, exclusions=["Nuclear hazard"], confidence=conf(0.95, endorsements=0.2))
client = RecordedClient([reply(**missing_009)] * 3)
a4 = extract_with_retry(client=client, policy_id="POL-2025-009", document_text=load_policy_text("POL-2025-009"),
                        max_retries=3)
show("A4 bundled POL-2025-009 (shape=missing_endorsement_schedule)", a4, client.call_count)

print()
print("=" * 78)
print("PART B - deterministic routing: flip one independent signal at a time")
print("=" * 78)


def extraction(pid: str, ptype: str, *, c: dict[str, float], coverage: float = 300000.0,
               endorsements: list[Endorsement] | None = None) -> PolicyExtraction:
    return PolicyExtraction(
        policy_id=pid, policy_type=ptype, premium_amount=1500.0, deductible=500.0,  # type: ignore[arg-type]
        coverage_limit=coverage,
        endorsements=endorsements if endorsements is not None else [Endorsement(name="Standard", limit=None)],
        exclusions=["Intentional acts"], premium_components=None, confidence=c,
    )


def review(disagree: tuple[str, ...] = ()) -> ReviewResult:
    return ReviewResult(agreements={
        f: FieldAgreement(field=f, agreement="disagree" if f in disagree else "agree",
                          reason="independent reviewer read a different value" if f in disagree else None,
                          review_confidence=0.9)
        for f in FIELDS
    })


cases = [
    # (description, extraction, review)
    ("clean auto", extraction("POL-2025-001", "auto", c=conf(0.96)), review()),
    ("clean auto", extraction("POL-2025-003", "auto", c=conf(0.95)), review()),
    ("clean home", extraction("POL-2025-005", "home", c=conf(0.95)), review()),
    ("clean umbrella", extraction("POL-2025-007", "umbrella", c=conf(0.94)), review()),
    ("REVIEWER signal: all confidence 0.99, reviewer disagrees on premium_amount",
     extraction("POL-2025-002", "auto", c=conf(0.99)), review(disagree=("premium_amount",))),
    ("CONFIDENCE signal: exclusions confidence 0.82 (< 0.90 threshold)",
     extraction("POL-2025-004", "home", c=conf(0.95, exclusions=0.82)), review()),
    ("INTEGRATION signal: endorsement limits (250k + 150k) exceed coverage_limit 300k",
     extraction("POL-2025-006", "umbrella", c=conf(0.97),
                endorsements=[Endorsement(name="Excess Auto", limit=250000.0),
                              Endorsement(name="Excess Home", limit=150000.0)]),
     review()),
]

decisions = []
for desc, ext, rev in cases:
    findings = integration_pass(ext)  # real cross-field checks
    d = route_extraction(extraction=ext, review=rev, integration_findings=findings)
    confidence_only = "auto_approve" if min(ext.confidence.values()) >= 0.90 else "human_review"
    print(f"{ext.policy_id:13} {ext.policy_type:9} -> {d.decision:12} | trusting confidence alone -> "
          f"{confidence_only:12} | {desc}")
    if d.decision == "human_review":
        print(f"{'':13} reason: {d.reason}")
    decisions.append(d)

decisions = apply_stratified_spot_check(decisions, sample_pct=0.1, seed=42)
out = Path(sys.argv[1] if len(sys.argv) > 1 else "routing_decisions.json")
write_routing_decisions(decisions, out)
counts = {k: sum(1 for d in decisions if d.decision == k) for k in ("auto_approve", "human_review", "spot_check")}
print(f"\nafter apply_stratified_spot_check(sample_pct=0.1, seed=42): {json.dumps(counts)}")
print(f"routing decisions written to {out.name}")
