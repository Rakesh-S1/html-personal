# Evidence Pack — Evaluation and Observability Capstone

The layout follows the starter `README.md`. Every value quoted in `reflection-brief.md` can be found in the file it cites.

| File | What it is |
|---|---|
| `reflection-brief.md` | Completed brief (official template) |
| `perturbation-log.md` | One experiment per system (official template) |
| `environment.txt` | OS, Python versions, venv setup, problems hit and how they were fixed |

## 01-policy-pipeline/ — validated, routed pipeline (`04-hitl-routing/solution`)

| File | Content |
|---|---|
| `tests.txt` | `pytest tests/ -v`: **45 passed, 3 skipped** (the live-API tests) |
| `static-checks.txt` | mypy (no issues, 11 files) + ruff (all checks passed) |
| `routing-tests-offline.txt` | Instructions' no-API fallback: `pytest tests/test_us04_routing.py -v`, 9 passed |
| `perturbation-run.txt`, `experiments/offline_pipeline_experiment.py` | Offline run of the real retry loop, validator, integration checks and router, with scripted model replies |
| `routing_decisions.json` | Routing output written by `write_routing_decisions()` in that run (1 auto_approve / 3 human_review / 3 spot_check) |
| `calibration-report.txt` | Output of the provided `calibration_report.py` |
| `source-documents/` | Bundled policies used in the experiment |
| `screenshots/tests-and-calibration.png` | Test run + calibration report in a console window |

## 02-mortgage-extraction/ — two-pass extraction (`04-validate-mathematical-consistency/solution`)

| File | Content |
|---|---|
| `tests.txt` | **25 passed** |
| `static-checks.txt` | mypy (no issues, 11 files) + ruff (all checks passed) |
| `extract-run.txt` | `appraisal_informal_sqft.txt`, classified `appraisal`, sq ft normalized to `2400` |
| `missing-field-run.txt` | `income_missing_bonus.txt`, `bonus_monthly: null` |
| `discrepancy-run.txt` | `income_sum_mismatch.txt`, validator reports `calculated 9642.17` vs `stated 10892.17`, exit 1 |
| `perturbation-run.txt`, `experiments/` | Edited stated total (replay refuses) + tolerance sweep |
| `source-documents/` | The three fixture documents |
| `screenshots/discrepancy-run.png` | Discrepancy run in a console window |

## 03-supply-chain/ — multi-source synthesis (`03-resilient-coordinator/solution`)

| File | Content |
|---|---|
| `tests.txt` | **34 passed** |
| `static-checks.txt` | mypy (no issues, 8 files) + ruff (all checks passed) |
| `investigation-run.txt`, `briefing.md` | `meridian --offline`: Well-Established / Contested / Incomplete |
| `timeout-run.txt`, `briefing-timeout.md` | `--simulate-timeout`: exit 0, logistics annotated as unavailable |
| `perturbation-run.txt`, `experiments/data-perturbed/` | Audit on-time delivery edited 95 → 86 (copy of the data) |
| `screenshots/` | Timeout run, including the Incomplete section |

All runs are offline (no API key was available); see `environment.txt`.
