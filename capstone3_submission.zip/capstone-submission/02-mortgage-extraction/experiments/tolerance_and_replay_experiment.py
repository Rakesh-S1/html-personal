"""System 2 offline experiment.

E1 (input perturbation): copy income_sum_mismatch.txt, change the stated total so it matches the line
    items, and run it in --mode replay. Replay keys recordings by a hash of the request, so an edited
    document has no recording: the client must refuse rather than reuse the old answer.
E2 (configuration perturbation): replay the ORIGINAL mismatch document through the real two-pass
    pipeline once, then validate the same extraction at several tolerances (config default 1.00 USD).

Run from the mortgage solution folder with its venv:
    .venv\\Scripts\\python <this file> <scratch dir>
"""
from __future__ import annotations

import sys
from pathlib import Path

from mortgage_extractor.client import RecordingClient
from mortgage_extractor.config import DEFAULT_MODEL, DEFAULT_TOLERANCE_USD
from mortgage_extractor.pipeline import Pipeline
from mortgage_extractor.validator import validate

scratch = Path(sys.argv[1] if len(sys.argv) > 1 else ".")
scratch.mkdir(parents=True, exist_ok=True)
original = Path("fixtures/documents/income_sum_mismatch.txt").read_text()

print("=" * 78)
print("E1 - edit the stated total, re-run in replay mode")
print("=" * 78)
edited = original.replace("TOTAL MONTHLY EARNINGS                         10,892.17",
                          "TOTAL MONTHLY EARNINGS                          9,642.17")
assert edited != original
edited_path = scratch / "income_sum_mismatch_EDITED.txt"
edited_path.write_text(edited)
print(f"changed line: 'TOTAL MONTHLY EARNINGS  10,892.17' -> '9,642.17'  (saved as {edited_path.name})")
try:
    Pipeline(model=DEFAULT_MODEL, client=RecordingClient(mode="replay")).run(edited)
    print("RESULT: extraction returned (unexpected)")
except FileNotFoundError as exc:
    print(f"RESULT: replay refused -> FileNotFoundError: {exc}")

print()
print("=" * 78)
print(f"E2 - same extraction, different validator tolerance (config default = {DEFAULT_TOLERANCE_USD:.2f} USD)")
print("=" * 78)
extraction = Pipeline(model=DEFAULT_MODEL, client=RecordingClient(mode="replay")).run(original)
assert extraction.income is not None
print(f"calculated_monthly_total = {extraction.income.calculated_monthly_total:.2f} "
      f"(sum of extracted line items)")
print(f"stated_monthly_total     = {extraction.income.stated_monthly_total:.2f} (copied from the document)")
for tol in (DEFAULT_TOLERANCE_USD, 100.0, 1249.99, 1250.00, 5000.0):
    report = validate(extraction, tolerance=tol)
    d = report.discrepancies[0] if report.discrepancies else None
    detail = f"delta={d.delta:+.2f}" if d else "no discrepancy reported"
    print(f"tolerance={tol:>8.2f}  consistent={str(report.consistent):5}  {detail}")
