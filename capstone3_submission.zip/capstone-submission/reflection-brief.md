# Reflection Brief — Evaluation and Observability Capstone

**Name:** Rakesh
**Date:** 2026-11-13

> Ground every answer in your own run. When a question asks for a number, file name, or line, paste
> it from your artifacts — a reviewer should be able to find it. Answers that are correct in the
> abstract but cite nothing do not meet the bar. Keep it short and specific.

---

## 0. Environment

| Field | Value |
|---|---|
| OS & version | Windows 11 Home 10.0.26300 (64-bit), local machine (`environment.txt`) |
| Python version | 3.15.2 for Systems 1 and 2; 3.12.10 for System 3 (its `onnxruntime`/`chroma-hnswlib` have no 3.15 wheels). Both are python.org builds. |
| Date run | 2026-11-13 |
| Ran any system live? (which) | No. No API key was available. All runs are offline: recorded replays, `--mode replay`, `--offline`, and the System 1 routing fallback plus an offline experiment with scripted model replies (see `environment.txt`). |

---

## 1. Validated, routed pipeline

| Evidence | Value |
|---|---|
| Passing test count | **45 passed, 3 skipped** (the 3 live-API tests), `01-policy-pipeline/tests.txt`; mypy `Success: no issues found in 11 source files`, ruff `All checks passed!`, `static-checks.txt` |
| Routing output file | `01-policy-pipeline/routing_decisions.json`, written by the real `write_routing_decisions()` in my offline experiment (`perturbation-run.txt`), plus the instructions' fallback `routing-tests-offline.txt` (`9 passed`) |
| auto_approve / human_review / spot_check counts | 1 / 3 / 3 (`after apply_stratified_spot_check(sample_pct=0.1, seed=42): {"auto_approve": 1, "human_review": 3, "spot_check": 3}`) |

**1a. Retry boundary.** From your perturbation run (a required field removed), paste the escalation
record. How many API calls did the system make, and why is retrying a futile case worse than
escalating it?

> From `01-policy-pipeline/perturbation-run.txt`, A3: I removed the line `Total Policy Premium .... $ 1,847.62` from a copy of POL-2025-001.
> ```
> API calls made: 1  ->  ESCALATION
> "policy_id": "POL-2025-001-perturbed", "field": "premium_amount", "category": "missing_source",
> "detected_pattern": "premium_amount_absent",
> "reason": "Field 'premium_amount' returned null — the source document does not contain this information. Retry is futile; escalate to human review."
> ```
> **One API call**, even though `max_retries=3` and three replies were queued. Compare A2, a fixable negative premium: `API calls made: 2 -> EXTRACTION` with `retry_count: 1`. The validator labels the failure category, and only `format`/`consistency` errors earn a retry.
>
> Retrying a missing-source case is worse than escalating for three reasons:
> - It spends calls (here up to 3 more) and latency on something no prompt can fix, because the premium isn't in the document.
> - Each retry pushes the model ("premium_amount was null, please fix") toward inventing a plausible number. A fabricated $1,847.62-looking premium is far more dangerous than a null.
> - It delays the human who has to fetch the real declarations page anyway.

**1b. Reading the router.** Pick one `human_review` record from your routing output. Which of the
three signals (confidence, reviewer, integration) sent it to a human? If you had trusted the model's
confidence alone, what would have happened?

> `POL-2025-002` in `routing_decisions.json`: `"decision": "human_review"`, `"reviewer_disagreements": ["premium_amount"]`, `"fields_below_threshold": []`, with every value in `confidence_summary` at `0.99`.
> - **Signal:** the **independent reviewer** sent it to a human (`reason: reviewer_disagreement=['premium_amount']`). Confidence and integration were both clean.
> - **Trusting confidence alone:** the experiment prints it directly, `trusting confidence alone -> auto_approve`. A premium the reviewer read differently would have gone straight through, and since only `auto_approve` records are sampled for `spot_check`, it might never have been looked at.
> - **Integration does the same job:** `POL-2025-006` (confidence 0.97) failed `coverage_limit_exceeds_endorsement_sum` (endorsement limits 250k + 150k > coverage_limit 300k). That is a second record a confidence-only router would have auto-approved.

**1c. Where the aggregate lies.** Run the calibration snippet. Quote the one cell whose accuracy lags
its confidence, plus the overall figure. What does slicing by `policy_type × field` catch that a
single number hides?

> From `01-policy-pipeline/calibration-report.txt`:
> `umbrella  exclusions  n=2 conf=0.93 acc=0.00 brier=0.865` vs `OVERALL brier=0.291`.
> - **What the aggregate shows:** across all 6 labels, accuracy is 4/6 = 0.67 and mean confidence is 0.935. A Brier of 0.291 looks like a model that is "somewhat overconfident" everywhere.
> - **What slicing shows:** the model is well calibrated on `auto/premium_amount` (`acc=1.00 brier=0.003`) and `home/deductible` (`brier=0.010`), and **always wrong** on umbrella exclusions while reporting 0.93 confidence. Averaging the healthy cells with a cell that fails every time produces a respectable-looking number that points at no specific problem.
> - **Consequence for routing:** at 0.93 those umbrella exclusions clear the 0.90 threshold, so they would be auto-approved. Only the slice tells me to lower trust for that one `policy_type × field`, or always route it to a reviewer.

---

## 2. Schema-enforced two-pass extraction

| Evidence | Value |
|---|---|
| Passing test count | **25 passed**, `02-mortgage-extraction/tests.txt` (25 defined, 25 collected; the README's "28" is stale). mypy `no issues found in 11 source files`, ruff `All checks passed!` |
| Document run | `fixtures/documents/appraisal_informal_sqft.txt`, `02-mortgage-extraction/extract-run.txt` |
| Classified type | `appraisal` (`classify: model=claude-haiku-4-5-20251001 in=2169 out=108 type=appraisal`, then `extract: ... tool=extract_appraisal`) |

**2a. Two guarantees.** Paste your discrepancy-run output. Tool use already forces valid JSON, yet the
validator still catches a bad sum. Why are these two different guarantees? Name one error each cannot
catch.

> From `02-mortgage-extraction/discrepancy-run.txt` (`income_sum_mismatch.txt`, `type=income_verification`):
> ```
> "validation": { "consistent": false, "discrepancies": [ { "field": "total_monthly_income",
>   "calculated": 9642.17, "stated": 10892.17, "delta": -1250.0 } ] }
> (exit code: 1  - 0 = consistent, 1 = validator found a discrepancy)
> ```
> - **Tool use + JSON Schema guarantees shape.** Every field exists, numbers are numbers, and enums are in range.
> - **The validator guarantees a relationship between values.** The five extracted components (5,416.67 + 2,140.00 + 1,250.00 + 385.50 + 450.00 = 9,642.17) must equal the stated total.
>
> `10892.17` is a perfectly valid `number`, so the schema has nothing to object to. The document itself is wrong: its total is exactly the $1,250.00 bonus higher than the line items, as if the bonus were counted twice.
>
> **What each cannot catch:**
> - **The schema** cannot catch a well-typed but wrong value, such as this inflated total.
> - **The validator** cannot catch an error that keeps the sum intact, such as a bonus filed under `base_monthly` (same total, wrong category). It also can't check anything when there is nothing to compare: in `missing-field-run.txt`, `stated_monthly_total` is `null`, so the run reports `"consistent": true` vacuously. That means "nothing to compare", not "verified".

**2b. Refusing to fabricate.** Run on a document missing a field. Paste that field's output. Why null
instead of an invented value? Point to the schema choice that allows it.

> From `02-mortgage-extraction/missing-field-run.txt` (`income_missing_bonus.txt`, `type=income_verification`):
> `"base_monthly": 5673.08, "bonus_monthly": null, "bonus_ytd": null, ... "stated_monthly_total": null`
> - **Why null:** the payslip never mentions a bonus. `0.0` would assert "this borrower earns no bonus", and a plausible number would be invented income. `null` says "the document does not say", which is the only true statement. Downstream, `Income.calculated_monthly_total` keeps that distinction: its docstring says `None` versus `0.0` "distinguishes 'the document stated no income components' from 'the document stated all components are zero'".
> - **The schema choice:** nullable union types in `mortgage_extractor/schema.py`, e.g. `{"type": ["number", "null"]}`. The module docstring says these exist "so the model can return `null` for absent fields rather than fabricating values". A non-nullable `number` would *force* the model to emit some number.
> - **The prompt rule:** "Return null for any field not explicitly stated in the document. Do not infer, default, or fabricate." (`prompts.py`)

**2c. Normalization.** Quote one field where the source text and extracted value differ in format
("about 2,400 sq ft" → `2400`). Why normalize at extraction time rather than downstream?

> The source line in `appraisal_informal_sqft.txt` is `Gross Living Area:   approximately 2,400 sq ft (above-grade finished)`. In `extract-run.txt` it becomes `"gross_living_area_sqft": 2400`. The schema type is `["integer", "null"]`, and rule 1 of `NORMALIZATION_RULES` is `"about 2,400 sq ft" → 2400`.
>
> I'd normalize at extraction time because only the extractor sees the context needed to pick and clean the right number. The same document also contains `approx. 20,037 sq ft` (lot size), `~900 sq ft` (basement), `441 sq ft` (garage) and `~2,400` in the comparables table. Downstream code receiving the string "approximately 2,400 sq ft" would have to re-parse free text at every consumer, each with its own rules. Emitting a typed integer once at the boundary means the validator, the underwriting rules and any comparison can trust the type.

---

## 3. Multi-source synthesis

| Evidence | Value |
|---|---|
| Passing test count | **34 passed**, `03-supply-chain/tests.txt`. mypy `no issues found in 8 source files`, ruff `All checks passed!` |
| Briefing file | `03-supply-chain/briefing.md` (also in `investigation-run.txt`); the degraded version is `briefing-timeout.md` / `timeout-run.txt` |
| Section the conflict landed in | **Contested**: `### on_time_delivery_rate  _[2 sources, conflicting]_  ⚠️ ESCALATE` |

**3a. Annotate, don't arbitrate.** Quote one conflicting-metric pair from your briefing — both values,
sources, dates. Give one way a reader is better served by the preserved conflict than by a single
reconciled number.

> From `03-supply-chain/briefing.md`:
> ```
> ### on_time_delivery_rate  _[2 sources, conflicting]_  ⚠️ ESCALATE
> - escalation: high-impact metric is contested across sources
>     - 95.0 percent — supplier_audit (as of 2026-04-10)
>     - 78.0 percent — logistics (as of 2026-04-05)
> ```
> - **What the gap means:** the 17 points between the two sources are the finding. 95% is the supplier's own audit statement ("consistent with our internal service-level commitments"). 78% comes from our shipment records, which the same briefing backs with `late_shipment_count` 11.0 shipments (logistics) and a port strike that delayed deliveries "five to nine days" (industry_news, 2026-03-17).
> - **What a single number would do:** a reconciled 86.5% would be a number neither source reported. It would sit comfortably inside a 10% tolerance and look fine.
> - **What the preserved conflict does:** it tells a buyer exactly what to do next, which is to challenge the supplier's self-reported figure with our own shipment data before renewing.

**3b. Source goes dark.** Run with `--simulate-timeout`. Paste the part of the briefing showing the
failed source. How is "unreachable" handled differently from "nothing to report," and why does the run
still finish?

> From `03-supply-chain/timeout-run.txt` (`(exit code: 0)`; screenshot `screenshots/timeout-run-incomplete-section.png`):
> ```
> > Sources unavailable: logistics unavailable (timeout)
> ## Incomplete
> ### late_shipment_count  _[missing source: timeout reading logistics]_
> ### production_capacity_utilization  _[missing source: no source reported this metric]_  ⚠️ ESCALATE
> ```
> - **Unreachable vs nothing to report:** "unreachable" carries the failure reason (`timeout reading logistics`), and the briefing header names the dead source. "Nothing to report" (`no source reported this metric`) means every source answered and none had the metric. These need different follow-ups: retry or fix the feed, versus find a new data source.
> - **Why the run finishes:** each reader returns a `ReaderResult` with `ok`/`error` instead of raising. `coordinator.investigate()` collects only the successful claims and records the failure in `unavailable_sources`, so one source's timeout can't abort the investigation.
> - **What my run also showed:** only metrics that logistics reports *exclusively* (`EXCLUSIVE_METRICS`) are marked Incomplete. `on_time_delivery_rate` dropped to `_[single source only]_` (95.0 percent, supplier_audit) under Well-Established, and the Contested section reads `_none_`. A known high-impact conflict lost its ESCALATE, and only the one-line banner hints at it. I documented this in `perturbation-log.md`.

**3c. Dates as a guardrail.** Quote two claims about the same supplier with different dates. How does
requiring a date stop a time difference from reading as a contradiction?

> From `03-supply-chain/briefing.md`:
> `field_quality_concern: Meridian Components issued a voluntary precautionary recall of a single capacitor-assembly lot in Q1 2026 ... (industry_news, 2026-02-19)` and
> `defect_rate_ppm: 180.0 ppm — supplier_audit (as of 2026-04-10)` / `190.0 ppm — internal_quality (as of 2026-04-08)`.
> - **Why these aren't a contradiction:** without dates, "Meridian had a quality recall" and "Meridian's defect rate is a healthy 180–190 ppm" read as one source contradicting another. With dates they tell a sequence: a February lot recall, then defect measurements taken in April, after it. Both can be true.
> - **How the date is enforced:** `source_date: date` is a **required** field on `Claim` (`models.py`, no default), so no claim can enter the briefing without one, and every line renders `(as of …)`.
> - **Limit:** in this code the date protects the *reader*, not the algorithm. Conflict detection (`_classify`) compares values only, so the reader is the one who can see that the logistics figure (collected 2026-04-05) and the audit (2026-04-10, "Q1 2026") describe slightly different windows.

---

## 4. Synthesis

**4a. One principle.** Name the single moment in your runs (system + artifact) where *evaluate the
output, don't trust the model's word* most clearly caught something a trusting design would have
shipped.

> **System 2, `discrepancy-run.txt`:**
> - **What looked fine:** the model classified the payslip correctly (`type=income_verification`) and returned schema-valid JSON with every component extracted faithfully. A trusting design would have shipped `"stated_monthly_total": 10892.17` as the borrower's monthly income.
> - **What the check caught:** the Python check `calculated 9642.17 vs stated 10892.17, delta -1250.0` showed that figure overstates income by $1,250 a month, about $15,000 a year, in a mortgage qualification.
> - **Why the model couldn't catch it:** nothing about the model's output was "wrong" by its own standards. It copied what the document said. Only an independent computation over the output caught it, and the exit code (`1`) makes it impossible to miss in a pipeline.

**4b. Confidence ≠ correctness.** Pick the system where this mattered most, and explain why using
something you observed.

> **System 1.** In `calibration-report.txt`, the umbrella exclusions cell reports `conf=0.93` with `acc=0.00`. That's high confidence and wrong every time, which clears the 0.90 routing threshold.
>
> My routing experiment shows the same gap from the other side. `POL-2025-002` had every field at 0.99 confidence and still went to `human_review`, because an independent reviewer disagreed on `premium_amount`. `POL-2025-006` (0.97) failed an integration check. In both cases `trusting confidence alone -> auto_approve`.
>
> It matters most here because routing is the gate that decides whether a human ever sees the record. A self-rated score can only ever be one of the signals. That's why `route_extraction` requires confidence **and** reviewer **and** integration, and why the calibration slices exist to find where the confidence score lies.

**4c. Apply it.** Describe a real workflow where an LLM pulls structured results from messy input.
Which pattern — validated retry with escalation, independent review with deterministic routing, or
provenance-preserving conflict annotation — would you reach for first, and what would you instrument
to know when it broke?

> **Workflow:** extracting vendor invoices (scanned PDFs, emails) into an accounts-payable system: vendor, invoice number, line items, tax and total.
>
> **Pattern I'd reach for first:** validated retry with escalation, paired with a System 2-style arithmetic check:
> - Line items + tax must equal the stated total. A failure gets one retry with the error fed back.
> - A null required field (no invoice number, no total) escalates immediately with one call, as in my A3 run, so the system never invents a number that would then get paid.
>
> **Instrumentation, so I'd know when it broke:**
> - **Escalation rate and retry-count distribution, per vendor × field.** Slices, not one average, because 1c showed the aggregate hides the bad cell.
> - **Rate of `consistent: true` with a null total, tracked separately.** It looks like a pass but checked nothing (2a).
> - **Replay or recording misses** after a template changes, so drift shows up loudly (System 2, E1).
> - **Accuracy on a small stratified spot-check sample** of auto-approved invoices, so every vendor gets sampled even when its records are all "high confidence".
>
> **Later:** once that is stable, I'd add an independent reviewer and the deterministic AND-gate before anything is auto-paid.
