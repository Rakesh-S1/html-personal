# Perturbation Log

For each system, make one deliberate change to an input or configuration, predict the outcome, run
it, and record what actually happened. See the starters in the Instructions, or design your own (your
own experiment earns more credit).

---

### System 1 — validated, routed pipeline

- **Change I made (file + what I changed):** Copied `data/policies/POL-2025-001.txt` in memory and deleted the line `Total Policy Premium ........................  $ 1,847.62`, so the premium is genuinely absent from the document. No API key was available, so the model's reply is scripted with the suite's own `RecordedClient` (`tests/conftest.py`). It returns `"premium_amount": null`, which is what an extractor following the "null for unstated fields" rule produces. Three replies were queued, so any retry would show up as an extra call. The validator, retry loop and escalation are the real `policy_extractor` code. As a second, routing-side change, I flipped one routing signal at a time on otherwise clean records (Part B).
- **Command I ran:** `.venv\Scripts\python experiments\offline_pipeline_experiment.py routing_decisions.json` (from the `04-hitl-routing/solution` folder). Full output is in `01-policy-pipeline/perturbation-run.txt`; the script is `01-policy-pipeline/experiments/offline_pipeline_experiment.py`.
- **What I predicted:** A null required field is a `missing_source` failure, not a format error, so the retry loop should stop at once: 1 API call, one `RetryFutileEscalation` for `premium_amount`, and no value invented. For routing, I expected any one failing signal to force `human_review`, even when every confidence is 0.99.
- **What actually happened (paste the key output line):**
  ```
  --- A3 PERTURBED: premium genuinely absent, model returns null
  API calls made: 1  ->  ESCALATION
    "field": "premium_amount", "category": "missing_source", "detected_pattern": "premium_amount_absent",
    "reason": "Field 'premium_amount' returned null — the source document does not contain this information. Retry is futile; escalate to human review."
  ```
  Routing (Part B): `POL-2025-002  auto  -> human_review | trusting confidence alone -> auto_approve | REVIEWER signal: all confidence 0.99, reviewer disagrees on premium_amount`
- **How this differs from the unperturbed run:**
  - **A1 (unperturbed `POL-2025-001`, well-formed reply):** `API calls made: 1 -> EXTRACTION` with `premium_amount: 1847.62, retry_count: 0`.
  - **A2 (fixable format error, `premium_amount=-1847.62`):** `API calls made: 2 -> EXTRACTION`, `retry_count: 1`, and the retry prompt carried the validation error back (`True`).
  - **A3 (perturbed):** the same 3-retry budget was available, but only 1 call was spent, because retrying cannot recover data that isn't in the document.
  - **Bundled case (shape `missing_endorsement_schedule`):** `POL-2025-009` behaved the same way: `1 -> ESCALATION`, `"endorsements_absent"`.
  - **Routing:** clean records went `auto_approve` (3 of them were then sampled to `spot_check` by the stratified sampler, `seed=42`). Each single flipped signal sent its record to `human_review`. In 2 of those 3 cases (reviewer, integration), a confidence-only router would have auto-approved.

---

### System 2 — schema-enforced two-pass extraction

- **Change I made (file + what I changed):**
  - **E1 (input):** Copied `fixtures/documents/income_sum_mismatch.txt` to `experiments/income_sum_mismatch_EDITED.txt` and changed the stated total `TOTAL MONTHLY EARNINGS 10,892.17` to `9,642.17`, so it now matches the line items.
  - **E2 (configuration):** Re-validated the original document's extraction with the validator `tolerance` swept from the `config.DEFAULT_TOLERANCE_USD = 1.00` default up to `5000.00`.
- **Command I ran:** `.venv\Scripts\python experiments\tolerance_and_replay_experiment.py experiments\` and `mortgage-extract experiments\income_sum_mismatch_EDITED.txt --mode replay`. Outputs are `02-mortgage-extraction/perturbation-run.txt` and `02-mortgage-extraction/experiments/edited-doc-cli-run.txt`.
- **What I predicted:**
  - **E1:** The live route (`--mode record`) needs an API key. In replay I expected the edited document *not* to reuse the original recording, because the cache key is a SHA-256 of the request.
  - **E2:** The $1,250 error should stay flagged until the tolerance reaches $1,250, then disappear.
- **What actually happened (paste the key output line):**
  - **E1:** `RESULT: replay refused -> FileNotFoundError: No recorded response for key 5d33a488a3de54cd (mode=replay). Re-run with mode='record' or 'auto' to populate the cache.` The CLI shows the same error as a raw traceback and `(exit code: 1)`.
  - **E2:**
  ```
  tolerance=    1.00  consistent=False  delta=-1250.00
  tolerance= 1249.99  consistent=False  delta=-1250.00
  tolerance= 1250.00  consistent=True   no discrepancy reported
  ```
- **How this differs from the unperturbed run:**
  - **Unperturbed `discrepancy-run.txt` (tolerance 1.00):** `"consistent": false`, `"calculated": 9642.17, "stated": 10892.17, "delta": -1250.0`, `(exit code: 1)`. **E2** shows that this safeguard is exactly as strong as one configuration number. At `tolerance=1250.00` the same bad payslip, whose stated total counts the $1,250.00 bonus twice, reports `consistent=True`.
  - **E1:** an unperturbed document replays from its recording. The edited one is refused instead of silently getting the old answer. That keeps replay honest, but on the CLI it surfaces as an unhandled Python traceback rather than a clear "no recording for this document" message, which is an observability gap.

---

### System 3 — multi-source synthesis

- **Change I made (file + what I changed):**
  - **Own experiment:** copied `data/meridian/` to `03-supply-chain/experiments/data-perturbed/meridian/` and changed the supplier audit's `on_time_delivery_rate` in `audit.json` from `95` to `86`, moving it closer to logistics' 78. With `REL_TOL = 0.10` in `synthesis.py`, the gap (86 − 78) / 86 = 9.3% is just under the 10% conflict threshold.
  - **Starter experiment:** `--simulate-timeout` on the unchanged data.
- **Command I ran:**
  - `supply-chain-investigate meridian --offline --data-root experiments/data-perturbed`, saved as `03-supply-chain/perturbation-run.txt`.
  - `supply-chain-investigate meridian --offline --simulate-timeout`, saved as `03-supply-chain/timeout-run.txt` and `briefing-timeout.md`.
- **What I predicted:** An 8-point disagreement on a high-impact metric would be classified as agreement: the metric moves from Contested to Well-Established, "corroborated", and loses its ESCALATE flag. For the timeout run, I predicted that the run finishes and logistics is annotated as unavailable.
- **What actually happened (paste the key output line):**
  ```
  ### on_time_delivery_rate  _[corroborated across 2 sources]_
      - 86.0 percent — supplier_audit (as of 2026-04-10)
      - 78.0 percent — logistics (as of 2026-04-05)
  ## Contested
  _none_
  ```
  For the timeout run, `(exit code: 0)` with `> Sources unavailable: logistics unavailable (timeout)` and, under Incomplete, `### late_shipment_count  _[missing source: timeout reading logistics]_`. But `on_time_delivery_rate` became `_[single source only]_` (95.0 percent from supplier_audit) under Well-Established, with no ESCALATE.
- **How this differs from the unperturbed run:**
  - **Unperturbed `briefing.md`:** puts `on_time_delivery_rate` under Contested with `⚠️ ESCALATE`, `escalation: high-impact metric is contested across sources`, showing 95.0 (supplier_audit, 2026-04-10) vs 78.0 (logistics, 2026-04-05).
  - **Both perturbations remove that escalation:** one through a tolerance edge, the other through a source failure.
  - **Shared metrics are not marked Incomplete when their only dissenting source fails.** The timeout run marks just the metric that logistics reports *exclusively* (`EXCLUSIVE_METRICS` in `coordinator.py`). The contested metric quietly loses its dissenting source, and the only remaining warning is the one-line banner at the top. Graceful degradation kept the run alive, at the cost of hiding a known conflict.
