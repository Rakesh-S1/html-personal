# Claims intake run 20261111T134106Z

- Mode: `offline-scripted`  Model: `offline-scripted`
- Claims processed: 8  Routed: 4  Escalated: 4
- Turns per claim: min 3, max 5, mean 4.00
- Tokens (input+output, estimated): 35,026

| Claim | Outcome | Decision | Turns | stop_reason sequence |
|---|---|---|---|---|
| CLM-1001 | routed | CLM-1001-S1 -> auto_physical_damage | 4 | tool_use -> tool_use -> tool_use -> end_turn |
| CLM-1002 | routed | CLM-1002-S1 -> property_claims | 4 | tool_use -> tool_use -> tool_use -> end_turn |
| CLM-1003 | escalated | high_value: Routing was rejected: Sub-issue amount $38,000 exceeds the auto-routing limit of $25,000; escalate with category high_value. | 5 | tool_use -> tool_use -> tool_use -> tool_use -> end_turn |
| CLM-1004 | escalated | coverage: Not covered: policy status is lapsed | 4 | tool_use -> tool_use -> tool_use -> end_turn |
| CLM-1005 | routed | CLM-1005-S1 -> travel_claims | 4 | tool_use -> tool_use -> tool_use -> end_turn |
| CLM-1006 | escalated | missing_information: No policy_id on the claim; cannot look up a policy. | 3 | tool_use -> tool_use -> end_turn |
| CLM-1007 | routed | CLM-1007-S1 -> property_claims, CLM-1007-S2 -> theft_unit | 4 | tool_use -> tool_use -> tool_use -> end_turn |
| CLM-1008 | escalated | fraud_review: Fraud signals: third claim this year, cash only | 4 | tool_use -> tool_use -> tool_use -> end_turn |
