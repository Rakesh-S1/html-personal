---
description: Safety rules for SQL migrations
paths:
  - "services/*/migrations/*.sql"
---

# Migration rules

- Migrations are forward-only and additive; drop columns in a later release after code stops reading them.
- Add indexes with `CREATE INDEX CONCURRENTLY`.
- Never edit a migration that has already been merged to `main`.
