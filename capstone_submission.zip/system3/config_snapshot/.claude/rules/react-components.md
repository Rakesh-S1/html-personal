---
description: Conventions for React components in the storefront
paths:
  - "apps/web/src/**/*.tsx"
---

# React component rules

- Function components with typed props; no default exports.
- Format money only with `formatCents()` from `packages/shared`; never divide by 100 inline.
- Every interactive element needs an accessible name.
- Data fetching lives in hooks under `src/hooks`, not inside components.
