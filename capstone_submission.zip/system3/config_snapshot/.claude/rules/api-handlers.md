---
description: Conventions for HTTP handlers in every Python service
paths:
  - "services/*/api/**/*.py"
---

# API handler rules

- Handlers stay thin: parse and validate input, call a service function, wrap the result in the envelope.
- Validate request bodies with the service's pydantic models; never trust client totals.
- Return 422 for validation errors, 409 for idempotency conflicts, 404 for missing resources.
- Write endpoints must read the `Idempotency-Key` header and pass it to the service layer.
