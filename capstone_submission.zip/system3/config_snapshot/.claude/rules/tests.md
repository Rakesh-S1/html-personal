---
description: Conventions for test files in every app and service
paths:
  - "services/*/tests/**/*.py"
  - "apps/web/src/**/*.test.tsx"
---

# Test file rules

- Name tests after behaviour: `test_refund_rejected_when_order_not_paid`, not `test_refund_2`.
- Arrange / act / assert, separated by blank lines.
- Use the shared fakes for payments and email; no network in unit tests.
