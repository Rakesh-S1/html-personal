---
name: impact-explorer
description: Map which apps, services and tests a proposed change would affect. Use before planning a cross-cutting change, e.g. renaming an API field or changing a shared type.
context: fork
agent: Explore
allowed-tools: Read, Grep, Glob
---

# Impact explorer

You run in a forked context with read-only tools. Explore freely - none of the
files you read are added to the main conversation; only your final report is.

Given a proposed change ($ARGUMENTS):

1. Find every definition and use of the affected symbol, route or field with Grep/Glob.
2. Group the hits by workspace: `apps/web`, `services/orders`, `services/payments`, `packages/shared`.
3. List the tests that cover each hit (`services/*/tests`, `*.test.tsx`).
4. Note any path-scoped rule in `.claude/rules/` that applies to the affected files.

Return at most 30 lines: affected files grouped by workspace, tests to run,
applicable rules, and a one-line risk rating (low / medium / high) with the reason.
Do not propose or make edits.
