# Security standards

- Never log card numbers, CVVs, full addresses or auth tokens.
- Secrets come from the environment; `.env` files are never read or committed (enforced in `.claude/settings.json`).
- All SQL goes through parameterised queries.
- Customer PII leaves a service only through the documented API envelope.
