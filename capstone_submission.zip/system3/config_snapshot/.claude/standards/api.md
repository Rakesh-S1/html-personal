# API standards

- All HTTP APIs are versioned under `/v1/...`; breaking changes need a new version.
- Responses use the envelope `{"data": ..., "error": null}` or `{"data": null, "error": {"code", "message"}}`.
- Money is an integer number of cents plus an ISO-4217 currency code. Never floats.
- Every write endpoint accepts an `Idempotency-Key` header.
- Timestamps are UTC ISO-8601 strings ending in `Z`.
