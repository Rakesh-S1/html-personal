# Testing standards

- Every bug fix ships with a test that fails before the fix.
- Python services use pytest; the web app uses Vitest + Testing Library.
- Tests must not call real payment providers or third-party APIs; use the fakes in `packages/shared`.
- Keep unit tests under 100 ms each; anything slower is marked as integration.
