---
description: Review the current branch against the team checklist
argument-hint: "[optional focus area, e.g. payments]"
allowed-tools: Bash(git diff:*), Bash(git log:*), Read, Grep, Glob
---

Review the changes on this branch compared with `main`.

1. Run `git diff main...HEAD --stat`, then read each changed file.
2. Check every change against the imported standards (API, testing, security)
   and any path-scoped rule in `.claude/rules/` whose globs match the file.
3. Flag: money handled as floats, missing `Idempotency-Key` handling, PII in logs,
   SQL built with string formatting, bug fixes without a failing-first test.
4. Focus area from the user (may be empty): $ARGUMENTS

Report findings as a list ordered by severity, each with `file:line`, the rule it
breaks, and a suggested fix. Say "No findings" if there are none.
