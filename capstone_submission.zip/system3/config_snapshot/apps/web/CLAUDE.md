# apps/web - storefront

- Vite + React 18 + TypeScript. Start with `npm run dev`; test with `npm test` (Vitest).
- Talks to services only through `src/api/client.ts`, never with raw `fetch`.
- Component conventions are in `.claude/rules/react-components.md` (loaded automatically for `*.tsx`).
