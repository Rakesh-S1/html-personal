# Shopfront monorepo - team instructions

E-commerce monorepo: a React storefront (`apps/web`), Python services
(`services/orders`, `services/payments`) and shared types (`packages/shared`).

## Always-on standards (imported)

@.claude/standards/api.md
@.claude/standards/testing.md
@.claude/standards/security.md

## How this config is organised

- This file holds only what applies to every task in every directory.
- Conventions that apply to a *kind of file* anywhere in the repo (API handlers,
  React components, tests, SQL migrations) live in `.claude/rules/` and are
  scoped with `paths:` globs, so they load only when matching files are touched.
- Directory-specific context (how to run one app or service) lives in that
  directory's own `CLAUDE.md`.
- `/review` (`.claude/commands/review.md`) runs the team's review checklist.
- The `impact-explorer` skill maps the blast radius of a change in a forked,
  read-only context, so its file reads never flood the main conversation.

## Commands

- Web: `cd apps/web && npm test`
- Services: `cd services/<name> && pytest`
- Validate this configuration: `python -m ecommerce_team_config .`

## Workflow

- Use plan mode for changes that touch more than one app or service; see
  `docs/decisions/plan-mode-and-explore.md`.
- Never commit directly to `main`; open a PR and run `/review` first.
