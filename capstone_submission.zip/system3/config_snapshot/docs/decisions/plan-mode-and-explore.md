# Decision: when to use plan mode and the impact-explorer skill

Status: accepted

## Context

The team works across a React storefront, two Python services and a shared
package. Cross-cutting changes (renaming an API field, changing money types)
have broken other workspaces when they were made without first mapping impact.

## Decision

| Situation | Use |
|---|---|
| Change stays inside one file or one directory | Work directly; path-scoped rules load automatically |
| Change touches 2+ workspaces, an API contract, or a migration | Start in **plan mode** (read-only until the plan is approved) |
| You need to know *what* a change would touch before planning | Run the **impact-explorer** skill (forked, read-only) |
| Reviewing a branch before a PR | Run `/review` |

## Why a forked skill for exploration

Exploration reads many files. In the main context those reads would push out
the plan and the conversation. A forked context explores, then returns only a
short report (at most 30 lines), so the main context stays small. Its tools are
limited to `Read, Grep, Glob`, so exploration cannot change files.

## Why path-scoped rules instead of more CLAUDE.md files

API handlers, tests and migrations exist in *every* service. A directory-level
`CLAUDE.md` would have to be copied into each service and kept in sync. One rule
file with a `paths:` glob (`services/*/api/**/*.py`) covers every current and
future service, and only loads when a matching file is in play.

## Consequences

- `python -m ecommerce_team_config .` must pass in CI; it rejects stale globs,
  broken `@` imports and forked skills that have write tools.
