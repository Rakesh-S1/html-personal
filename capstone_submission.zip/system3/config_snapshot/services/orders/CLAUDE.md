# services/orders

- FastAPI service. Run with `uvicorn orders.app:app --reload`; test with `pytest`.
- Owns orders, refunds and the order state machine (`pending -> paid -> shipped -> delivered | refunded`).
- Talks to `services/payments` only through its `/v1/payments` API.
