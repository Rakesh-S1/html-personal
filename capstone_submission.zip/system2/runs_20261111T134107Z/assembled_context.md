## Case Facts (verbatim - authoritative for all numbers and IDs)
Customer: Priya Nair (account C-55821)
### Damaged blender
- [m2 customer] First, the blender from order RS-40418 arrived with a cracked jar.
- [m2 customer] It was delivered on March 2.
- [m7 agent] The replacement blender has shipped with tracking number 1Z999AA10123456784, and you can keep or recycle the damaged one.
### Late patio set delivery
- [m9 customer] Next, my patio set order RS-40977 was promised for March 10 and it still hasn't arrived.
- [m14 agent] I've issued a $25.00 shipping refund to your card, reference RF-7781.
### Promo code not applied
- [m16 customer] Also, the promo code SPRING20 didn't apply when I placed order RS-41203.
- [m19 agent] The 20% discount on that order works out to $18.40.
- [m20 agent] I've added $18.40 as store credit, credit ID SC-3390, which you can use on any future order.
### Shipping address change
- [m22 customer] Can you change the shipping address on order RS-41560?
- [m24 customer] It's 221 Lakeview Dr, Apt 4B, Austin TX 78704.
- [m25 agent] Order RS-41560 will now ship to 221 Lakeview Dr, Apt 4B, Austin TX 78704.
### Missing loyalty points
- [m27 customer] Last thing on my list: my loyalty balance dropped by 1,250 points and I didn't redeem anything.
- [m28 agent] I see a duplicate redemption posted in error on March 15.
- [m30 agent] I've restored the 1,250 points under ticket LP-2209; they're back in your balance now.

## Earlier conversation (summarised)
- Opening (context): Hi, I have a few different problems with recent orders and my account, is this the right place? Agent: Let's go through everything one at a time.
- Damaged blender (resolved): First, the blender from order [see Case Facts] arrived with a cracked jar. Agent: The replacement blender has shipped with tracking number [see Case Facts], and you can keep or recycle the damaged one.
- Late patio set delivery (resolved): Next, my patio set order [see Case Facts] was promised for [see Case Facts] and it still hasn't arrived. Agent: I've issued a [see Case Facts] shipping refund to your card, reference [see Case Facts].
- Promo code not applied (resolved): Also, the promo code [see Case Facts] didn't apply when I placed order [see Case Facts]. Agent: I've added [see Case Facts] as store credit, credit ID [see Case Facts], which you can use on any future order.
- Shipping address change (resolved): Can you change the shipping address on order [see Case Facts]? Agent: Order [see Case Facts] will now ship to [see Case Facts].
- Missing loyalty points (resolved): Last thing on my list: my loyalty balance dropped by [see Case Facts] and I didn't redeem anything. Agent: I've restored the [see Case Facts] under ticket [see Case Facts]; they're back in your balance now.

## Most recent messages (verbatim)
[m31] customer: I've been a customer for years and usually everything goes smoothly, so this was a surprise. Thank you, that's a relief. My sister actually recommended your store, so I really want this to work out.
[m32] customer: Oh, one more request. Can you add gift wrap to order RS-41560? It's a birthday present for my mom.
[m33] agent: I can request that. Gift wrap needs a warehouse confirmation, so it's pending until they reply.
[m34] customer: Please make sure it still goes to 221 Lakeview Dr, I won't be at the old place.
[m35] agent: It will. Your open request now is gift wrap on order RS-41560, pending warehouse confirmation within 24 hours.
[m36] customer: Thanks, I'll watch for the email.