# Reflection Brief — Harness Engineering Capstone

**Name:** Rakesh
**Date:** 2026-11-11

Evidence folders next to this file: `system1/` `system2/` `system3/` `system4/`. Every run below was made in my Udacity workspace against the four reference `solution/` folders. Each log starts with a header naming its system, path and command.

**Environment**

- Model(s): `claude-haiku-4-5-20251001` for System 1 (`system1/runs/20261111_163300/summary.md`: "Model: `claude-haiku-4-5-20251001`") and System 2 (`system2/runs/20261111-175306/case_facts_call.json`: `"model": "claude-haiku-4-5-20251001"`). System 4 ran offline with `--recorded-response fixtures/recorded_responses/shift_C_2026-04-30.json` (no API call). System 3 needs no API.
- OS / Python: Udacity workspace (Linux, code-server), Python `3.13.0 (main, Dec 3 2024) [GCC 12.2.0]`; pytest 8.4.2.
- Approx. API spend: **≈ $0.33**.
  - System 1: $0.1196, from `summary.md`, "Estimated total cost: **$0.1196** USD".
  - System 2: ≈ $0.21. Its calls used 198,228 input and 1,815 output tokens in total (case-facts call, 2 compression calls, 6 eval calls and 2 control calls), priced at Haiku 4.5 list rates of $1 / $5 per MTok.
  - System 4: $0.
  - Plus a few cents for the failed first System 1 attempt, `runs/20261111_162451` (see Q19).

Test totals, from each `tests.log` footer:

| System | Result |
|---|---|
| 1 | `30 passed in 0.68s` |
| 2 | `28 passed, 2 skipped` before the run (`tests_before_run.log`), then `30 passed in 2.99s` after it |
| 3 | `35 passed in 0.24s` |
| 4 | `33 passed in 0.76s` |

---

## Part 1 — Per-system

### System 1 — Agentic loop

1. **Loop control.** Quote the `stop_reason` sequence from one trace. Name the file and function that decides continue-vs-stop, and how.
   → From `system1/runs/20261111_163300/traces/claim_02_stolen_bike.jsonl`:
   `tool_use → tool_use → tool_use → tool_use → tool_use → end_turn` (6 turns).

   The tools called per turn were:
   1. `lookup_policy`
   2. `record_claim_fact` ×5, run in parallel
   3. `classify_claim` (theft, confidence 1.0)
   4. `assess_severity` (low)
   5. `route_to_adjuster` (queue `theft`)
   6. none: the turn returned `end_turn`

   Continue-vs-stop is decided in **`claims_intake/loop.py`, function `run()`**. Inside `while True:` it calls the model and then branches only on `response.stop_reason`:
   - `if response.stop_reason == "end_turn":` returns a `FinalState` (line 103).
   - `if response.stop_reason == "tool_use":` executes every `tool_use` block, appends all `tool_result`s in one user message, and `continue`s (line 113).
   - Anything else hits `raise UnexpectedStopReason(f"turn {turn}: unexpected stop_reason=...")` (line 130).

   The docstring states the contract: "Loop continues iff stop_reason == "tool_use". Loop returns iff stop_reason == "end_turn"."

2. **Anti-pattern.** Name one anti-pattern `test_antipatterns.py` checks for. What would break in your run if the loop used it?
   → `test_no_integer_literal_iteration_cap_in_loop` walks the AST of `loop.py` and fails on any `for _ in range(<int literal>)` or `while <x> < <int literal>`. The only stopping mechanisms allowed are `stop_reason` plus the config-sourced `Budget`, whose `budget.check()` is called at the top of every iteration (line 70). All 4 tests in `tests/test_antipatterns.py` pass in `system1/tests.log`.

   **What would break in my run:** turn counts ranged from 2 to 6 (`summary.md`), and `claim_02_stolen_bike` needed **6 turns** to reach `routed`. A "reasonable-looking" cap of 4 would have stopped it after `assess_severity` (turn 4), before `route_to_adjuster` was ever called, so a correctly classified theft claim (confidence 1.0) would never reach the `theft` queue. At best `run.py`'s backstop would then mis-escalate a routable claim to a human. At worst, if the cap exited without returning a state, the claim would end neither routed nor escalated, and nothing in the trace would say the work was unfinished. A cap of 5 would route it but cut off the model's closing `end_turn`, so the loop would stop because a counter ran out, not because the model finished.

3. **Tool design.** Pick two tools with overlapping inputs. How do the descriptions prevent misrouting? What did a structured tool error let the agent do that a generic string would not?
   → `route_to_adjuster` and `escalate_to_human` (`claims_intake/tools.py`) overlap: both are terminal, both are called "exactly once", and both carry the claim's type, as `queue` (enum `CLAIM_TYPES`) or as `candidate_claim_types` (same enum). The descriptions split them with an explicit, mutually exclusive threshold:
   - `route_to_adjuster`: "Call this exactly once when classification confidence is **at least 0.6** and severity has been assessed".
   - `escalate_to_human`: "when classification confidence is **below 0.6** even after clarification, or when the claim cannot be routed safely".

   Both start with "TERMINAL TOOL" and end with "stop with end_turn". In my run, all 4 routed claims (02, 04, 05, 08) followed `classify_claim` → `assess_severity` → `route_to_adjuster`, with queue = claim_type each time: `theft`, `liability`, `auto` and `property_damage` in `queues/*.jsonl`.

   Errors use the "Graceful Tool Failure" shape, for example `{"is_error": true, "error_category": "permanent", "is_retryable": false, "message": "classify_claim must be called before routing"}`. A plain string like "Error" tells the agent only that something failed. The structured error tells it **whether to retry** (`is_retryable: false`), **what kind of failure** it was (`permanent` vs `transient`), and **exactly what to do next** (call `classify_claim` first). The system prompt then says "Read the message and adapt — do not retry blindly."

   In run `20261111_163300` the traces show no repeated or out-of-order tool calls, so no claim needed that recovery path. `tests/test_tools.py` (12 tests, all passing in `system1/tests.log`) exercises it, including `test_routing_requires_classification_and_severity`, `test_double_terminal_is_graceful_error` and `test_handler_exception_is_caught_as_transient_error`.

4. **Your numbers.** Quote the turn count and cost for one claim. How does it differ from the README sample, and why?
   → `claim_02_stolen_bike` (`summary.md`): **6 turns, 21,156 input / 898 output tokens, est. $0.0256**, routed `theft`/`low`. Input tokens per turn grew 2,761 → 2,943 → 3,559 → 3,794 → 3,967 → 4,132, because every turn re-sends the whole conversation plus all earlier tool results. Cost is therefore driven by turn count. My cheapest claims were the 2-turn ones (claim_03: 5,731 input tokens, $0.0066).

   My evidence doesn't include the README's sample numbers, so I compare against the reference outcome each fixture declares. `run.py` prints it per claim, e.g. `[claim_01_kitchen_fire] policy=POL-1001 expected=routed`. The fixtures expect 7 of 8 claims to route (all but claim_06), but I got **4 routed, 4 escalated**. Claims 01, 03 and 07 did not route as expected. In each, Haiku made one `tool_use` turn (`lookup_policy`, plus `record_claim_fact` calls in 01 and 07), then returned `end_turn` **without** calling `classify_claim` or any terminal tool. `run.py`'s `_escalate_without_terminal()` backstop then escalated all three. `escalations.jsonl` records `"reason": "model ended its turn without a terminal action (deterministic backstop)"`.

   Why: valid runs vary by model and input. Haiku 4.5 sometimes treats "facts recorded" as "done" and ends its turn early. The harness can't change that decision, but it guarantees that the claim still ends in an escalation rather than in limbo.

### System 2 — Context strategy

5. **The reduction.** From `budget.json`: baseline tokens, assembled tokens, reduction %. Which section dominates the assembled context, and why keep it verbatim?
   → `system2/runs/20261111-175306/budget.json`:
   - `"baseline_tokens": 38708`
   - `"assembled_tokens": 16875`
   - `"reduction_pct": 56.4`
   - counted with `"Anthropic messages.count_tokens endpoint (model-authoritative)"`

   The **active** section dominates: `"active": 15789` tokens, **93.6%** of the assembled context. The other sections are `case_facts` 204, `resolved_refund` 386 and `resolved_subscription` 514.

   It is the payment-method update that is **still in progress**. The next user turn continues it, so every detail may still matter: failure codes, the card being added, and what the agent already tried. `assemble.py` places it at the bottom boundary, "byte-exact verbatim", next to the new user turn. `test_assembled_context_active_segment_byte_exact` checks it against the source. That test was one of the 2 skipped before my run and passed after it.

6. **Summarize vs preserve.** State the rule for what gets summarized vs kept byte-exact, citing your per-section token numbers.
   → The rule has three parts:
   - **Resolved issues get summarized.** Their narrative is finished, so it can be compressed. The refund thread went from `"input_tokens": 12334` into the compressor down to a `resolved_refund` section of **386 tokens**. The subscription thread went from 11,475 down to **514 tokens** (`budget.json` → `compression_api`).
   - **The active issue is kept byte-exact**, at 15,789 tokens.
   - **Exact values that a paraphrase could corrupt are lifted into Case Facts** before compression: IDs, amounts, status tokens and codes. That block is 12 fixed fields in **204 tokens**, at the top, for example `refund_amount_usd: $22.14`, `payment_update_failure_code: AVS_MISMATCH` and `payment_update_status: in_progress` (`context.md`).

   My run shows why the rule matters. The refund summary names the customer "Linda Marchetti", while the byte-exact active segment names "Jennifer Ostrowski" 9 times for the same `CUST-88421` (`context.md`). I could not confirm from the raw transcript which name is right. Either way, the `customer_id` stayed exact because it lives in Case Facts, and the summary is the part that can drift.

   One more observation: the subscription summary came out at 514 tokens. That is over the "≤ 500 tokens" target in `compression_prompt.md` and the `assemble.py` docstring. The limit is a prompt instruction, not a code-enforced cap.

7. **Facts block.** Compare `eval.jsonl` to `eval_control.jsonl`. Which question regressed, and what does that prove?
   → `eval.jsonl`: **6/6 passed** (run.log: `=> 6/6 passed`). The control variant (`evaluate.strip_case_facts()` removes the `# Case Facts` block) re-ran Q1 and Q6:
   - **Q1 held.** "$22.14" also appears in the resolved refund summary.
   - **Q6 regressed.** `expected_fragment: "in_progress"`. With Case Facts, the model answered "**`payment_update_status`: in_progress** … This is the exact status token from the case facts section". Without them, it answered "there is no structured case record or status token documented for the payment-method update issue" (`eval_control.jsonl`; run.log: `1/2 control questions regressed`).

   This proves that the 204-token Case Facts block is the only place the exact structured status token exists. Even the 15,789-token verbatim active segment, which describes the same issue in conversation, never states `in_progress` as a token. So a small structured block at the top buys answerability that thousands of tokens of narrative don't.

### System 3 — Claude Code config

8. **Path-scoped rules.** Quote the glob frontmatter from one rule file. Why is it better than a directory-level CLAUDE.md for cross-cutting conventions?
   → `.claude/rules/tests.md` (`system3/config_snapshot/.claude/rules/tests.md`):
   ```yaml
   ---
   description: Conventions for test files (co-located *.test.ts and *.test.tsx)
   paths:
     - "**/*.test.tsx"
     - "**/*.test.ts"
   ---
   ```
   Test files are co-located everywhere, for example `src/components/Cart/Cart.test.tsx` next to `Cart.tsx`. No single directory owns them, so a directory-level `CLAUDE.md` would have to be copied into `src/components/`, `src/api/` and so on, and kept in sync. It would also load for every file in those directories, not just tests.

   One glob does it once, applies wherever a test file appears (including future directories), and loads only when a matching file is being edited, which keeps always-on context small. The root `CLAUDE.md` says the same: "We prefer `.claude/rules/` with glob `paths:` instead, so cross-cutting conventions (e.g. test files everywhere) work cleanly."

   The rule also stacks: "Applies on top of the React or API rules", whose `paths:` are `src/components/**/*`, `src/pages/**/*` and `src/api/**/*`. `system3/claude_structure.txt` lists the three rule files, each with a `paths:` line, and the validator printed `OK` (exit 0) after `_check_rules()`.

9. **Forked skill.** Quote the `context: fork` and `allowed-tools` lines. What does running forked + read-only buy you? What breaks without it?
   → `.claude/skills/deploy-check/SKILL.md`:
   ```yaml
   context: fork
   allowed-tools:
     - Read
     - Grep
     - Glob
     - Bash(git status:*)
     - Bash(git diff:*)
     - Bash(git log:*)
     - Bash(git rev-parse:*)
     - Bash(git ls-files:*)
     - Bash(gh pr view:*)
     - Bash(gh pr checks:*)
   ```
   **Forked:** `/deploy-check` produces "verbose intermediate output (file enumeration, diff parsing, check execution traces)". In a fork that stays in the sub-agent, and only "a single structured summary" returns to the main session. My main working context stays small and on-task.

   **Read-only:** the only shell access is scoped to read verbs like `git diff` and `gh pr checks`. There is no `Edit`, no `Write`, no bare `Bash`, and no `git push`, so a pre-deploy check cannot itself change the tree, commit or deploy.

   **Without these:** the check's noise would flood the main conversation and push out the plan. A bare `Bash` or `Edit` would let a "validation" step modify the branch it is supposed to be validating.

   Both settings are enforced, not just documented. The validator's `_check_deploy_check_skill()` reports "frontmatter missing context: fork" or "allowed-tools includes write-capable entries", using `tool_allowlist.write_capable_tools()`. Tests `test_ac_04_02_name_description_context_fork` and `test_ac_04_03_allowed_tools_read_only` pass in `system3/tests.log` (35 passed), and the validator printed `OK`.

10. **Scope.** From the validator output: project-level vs user-level scope. Give one example of each from this config.
    → `system3/validator.log` prints `OK` with `# exit code: 0`. Part of that check is `distinguishes_project_vs_user_scope(CLAUDE.md)`, which requires the root `CLAUDE.md` to name both scopes, state that user-level files are not version-controlled, and give a user-scope example. Otherwise it fails with "CLAUDE.md scope documentation block is incomplete".
    - **Project-level** (in git, shared with the team): `./CLAUDE.md` with its four `@`-imports (`@.claude/standards/frontend.md`, `api.md`, `database.md`, `testing.md`), the three rules, `/review` and `/deploy-check`. `SKILL.md` says "This skill is project-scoped (`.claude/skills/deploy-check/`) so the whole team gets the same checks."
    - **User-level** (`~/.claude/`, "Not shared via version control"): the config's own example is a stricter personal variant in `~/.claude/skills/deploy-check-strict/`, which "will not affect teammates and will not be committed to the repo". `CLAUDE.md` also gives "a personal `/morning` summary command" as something that belongs under `~/.claude/`.

### System 4 — Orchestration

11. **Push work down.** Defects the SQL query returned vs warm-tier total. Name the indexed query. Why does the model never see the full history?
    → `system4/run_shift.log`: `run_shift done: shift=C new=17` / `shift C: 17 new defects`. That is **17 of 40** rows; the warm tier was seeded from `fixtures/defects.json`, which has 40 defects.

    The query is `WarmStore.defects_since()` in `shift_monitor/warm.py`: `SELECT * FROM defects WHERE ts > ? ORDER BY ts DESC LIMIT ?`, backed by `idx_defects_ts` (plus `idx_defects_shift_ts`). `test_defects_since_uses_index_and_does_not_load_full_table` asserts that `EXPLAIN QUERY PLAN` uses the index and that exactly 17 April rows come back. `test_gather_new_defects_has_no_python_side_filtering` keeps all filtering in SQL. Both pass in `system4/tests.log` (33 passed).

    The model never sees the full history because `pipeline.run_shift()` builds the prompt from only two inputs: the small hot state and the SQL slice (`limit=50`). `test_build_rich_prompt_stays_under_4000_chars` pins the prompt size. History stays in SQLite (warm tier) and in monthly summaries (cold tier), and the database does the filtering, not the model.

    An observation from my run: `defects_since()` filters by time only. The 17 rows reported as "shift C: 17 new defects" are 6 shift A + 5 shift B + 6 shift C, everything since 2026-04-01 (I checked `fixtures/defects.json`). The `(shift, ts)` index exists but the query doesn't use the shift. See Q20.

12. **Crash recovery.** The resume-vs-fresh decision and its staleness threshold (`recovery.py`). Why is a fresh start with an injected summary sometimes more reliable than resuming?
    → `recovery.decide(state, now)` reads the manifest of completed steps:
    - **fresh** if there are no steps, or if the manifest is already `complete`.
    - **resume** if `now - last_step.ts <= timedelta(minutes=STALE_RESUME_THRESHOLD_MINUTES)`, where the constant is **30**.
    - **fresh** otherwise.

    The docstring explains the 30 minutes as "~1/16 of an 8-hour shift cycle: a resume inside this window is still operating on the same shift's working set". `test_recovery_decide_truth_table`, `test_recovery_decide_empty_manifest_is_fresh` and `test_threshold_constant_is_30_minutes` pin this, and all pass in `system4/tests.log`.

    A stale resume would carry an old working set into a world that has moved on. New defects have landed in the warm tier, and the partial reasoning was done against data that is no longer current. The model would then continue an analysis whose premises are out of date.

    A fresh start instead uses the `invocation.resumed()` shape: a "## Prior partial findings" section injected as a short summary, plus a fresh `defects_since(last_step_ts)` query. It keeps what was learned but re-grounds it in current data. `test_resumed_prompt_has_both_sections` checks both parts are present. My shift run completed normally (exit 0), so the evidence for this path is the test suite, not a live crash.

13. **Small state.** Byte size of your `hot_state.json`. Why does the budget matter for a system run once per shift, indefinitely?
    → `system4/hot_state_size.txt`: **`965 data/hot_state.json`**, which is 18.8% of `HOT_STATE_BYTE_BUDGET = 5_120` (`state.py`). It holds 17 `recent_defect_hashes` (max `MAX_RECENT_HASHES = 20`), a one-line `current_shift_summary`, 3 `active_alerts` and 3 `threshold_statuses` (`"defect_rate_per_shift": "ALARM"`, `"lot_defect_concentration": "ALARM"`).

    The hot state is loaded into **every** shift's prompt, three shifts a day, forever. If each shift appended a little, the state and prompt cost would grow without bound, and old alerts would crowd out new ones. A fixed budget keeps every shift equally cheap and focused, however long the system runs.

    The budget is enforced in code. `_trim_to_budget()` drops alerts from the end of the list until the state fits, and `HotState.write_atomic()` raises `ValueError` rather than write more than 5,120 bytes. The write goes to a temp file, then `fsync`, then an atomic rename, so a crash can't leave a half-written state. `test_hotstate_roundtrip_and_size_budget` and `test_hotstate_atomic_write` pass in `system4/tests.log`.

---

## Part 2 — Synthesis

14. **Three layers.** Point to a file/artifact for each layer and justify.
    → **Model:** `claims_intake/loop.py` line 72, `response = client.messages.create(model=model, max_tokens=max_tokens, system=system, tools=tools, messages=working_messages)`. This is the single stateless request/response with Claude. Its observable outputs are what each trace line records: `stop_reason`, `tool_calls`, `input_tokens`, `output_tokens` (e.g. claim_02 turn 1: `"stop_reason": "tool_use"`, `"input_tokens": 2761`).

    → **Harness:** `claims_intake/loop.py` `run()` with `tools.py` (7 tool schemas and the graceful-error dispatcher) and `run.py` `_escalate_without_terminal()`. Everything that wraps the model inside one task lives here: the loop, tool execution, the budget and the backstop. It turned one model into 8 terminated claims (`summary.md`: 4 routed, 4 escalated). For Claude Code the harness is System 3's `CLAUDE.md`, `.claude/rules/*.md`, `/review` and `/deploy-check` (validator `OK`).

    → **Orchestration:** `shift_monitor/pipeline.py` `run_shift()` with `state.py` (hot), `warm.py` (SQLite) and `cold.py` (monthly), plus `recovery.py` and `fork.py`. This is what spans sessions: each shift is a fresh session that reads only the 965-byte `hot_state.json` and a 17-row SQL slice, then appends one line to `data/shift_scratchpad.jsonl` (`"hypothesis_id":"shift-C","evidence":"17 new defects analyzed since 2026-04-01T00:00:00Z"`) for the next shift.

15. **Deterministic vs prompt.** Cite one behavior guaranteed in code (terminal tool, read-only allowlist, atomic write, byte budget) and one guided by prompt. When is each right?
    → **Guided by prompt:** `SYSTEM_PROMPT` step 6 tells the model to "Choose exactly one terminal action", and step 7 says "After your terminal tool call, respond with a one-sentence confirmation… and stop." In run `20261111_163300` Haiku followed this for claims 02, 04, 05 and 08, and **did not** for claims 01, 03, 06 and 07, ending its turn with no terminal call.

    → **Guaranteed in code:** the terminal outcome. `run.py` checks `if state is not None and not session.terminal_called:` and calls `_escalate_without_terminal()`. All 4 of those claims were escalated, and `escalations.jsonl` records `"model ended its turn without a terminal action (deterministic backstop)"` with `"recommended_action": "human review of the full transcript"`. Other code guarantees work the same way: `route_to_adjuster` refuses to run before `classify_claim` and `assess_severity`, `terminal_called` blocks a second terminal call, `HotState.write_atomic()` enforces the 5,120-byte budget, and the System 3 validator rejects write-capable `allowed-tools`.

    → **When each is right:** use a prompt for **judgement**: which of four claim types fits, whether confidence clears 0.6, how to word a summary. Code can't make those calls without branching on `claim_type` in Python, which `test_no_claim_type_equality_branching_in_package` forbids. Use code for **invariants** whose failure is unsafe or silent: every claim must terminate, state must never exceed its budget, and a check must never write. My run is the evidence: the prompt-guided step failed 4 of 8 times, and the code-guaranteed invariant held 8 of 8 times.

16. **Context, two faces.** Compare context management in System 2 (intra-session) and System 4 (cross-session) with cited numbers from both. Same principle, different mechanism — how?
    → **System 2, within one session:** a 38,708-token conversation was **restructured** into a 16,875-token prompt (56.4% smaller). That is 204 tokens of exact Case Facts at the top, 386 + 514 tokens of summarized resolved issues in the middle, and the 15,789-token active issue verbatim at the bottom.

    → **System 4, across sessions:** nothing carries over between shifts unless it is written down. A 40-row history was **moved out of the prompt** into SQLite, and each shift sees only a **17-row** `defects_since` slice plus a **965-byte** `hot_state.json` (budget 5,120). One scratchpad line is appended per shift.

    → **Same principle:** keep the small set of exact, decision-critical facts close and protected (Case Facts' 12 fields; the hot state's alerts and threshold statuses), and keep everything else compressed or out of the window.

    → **Different mechanism:** System 2 **compresses and positions inside one context window**, using LLM summaries for resolved narrative and boundary placement for what matters. System 4 **tiers data outside the window**: hot/warm/cold storage, with SQL doing the selection and a byte budget enforced in code. A summary that drifts (the customer-name discrepancy in Q6) is a System 2 risk. In System 4 the source of truth stays in SQLite.

17. **Reliability you can't see in one run.** Name one behavior a test guarantees that a single successful run would not reveal. Why does it matter before shipping?
    → `test_no_integer_literal_iteration_cap_in_loop` (System 1, `tests/test_antipatterns.py`, passing in `system1/tests.log`) guarantees that `loop.py` contains no hard-coded turn limit.

    My run can't show that. The longest claim took 6 turns, so a loop with a hidden `range(10)` would have produced the **same 8 outcomes and identical traces**. The flaw would only surface on some future claim that needs 11 turns, which would be silently cut off. A successful run proves that no claim *hit* a cap, never that no cap *exists*. The test inspects the code itself, so the guarantee covers every input, not just today's 8 fixtures.

    The same holds for `UnexpectedStopReason` (all 8 of my traces ended `end_turn`, so that branch never ran) and for System 4's stale-checkpoint → fresh path (my shift never crashed). It matters before shipping because production inputs are the ones you didn't test by hand. The rare path is where a silent failure would cost the most, for example a claim lost without anyone noticing.

18. **Blast radius.** Pick one system. What's the blast radius if it misbehaves, and what's the kill switch? Ground it in that system's tools, enforcement points, and state.
    → **System 1 (claims intake).**

    **Blast radius.** It is small by construction. The agent's only side effects are the two terminal tools, and each just appends one JSON line: `route_to_adjuster` to `runs/<ts>/queues/<queue>.jsonl`, or `escalate_to_human` to `escalations.jsonl`. No tool pays, denies or edits a policy; `lookup_policy` is read-only. The worst case is one claim in the wrong adjuster queue, which a human adjuster reads first anyway.

    **Enforcement points that limit it** (`tools.py`):
    - `queue` must be one of the 4 `CLAIM_TYPES`.
    - Routing is refused until `classify_claim` and `assess_severity` have run.
    - `terminal_called` stops a claim from being both routed and escalated, or routed twice.
    - Each run writes into its own timestamped `runs/<ts>/` folder (mine: `20261111_163300`), so a bad run can be quarantined by deleting or ignoring one directory.

    **Kill switches**, from narrow to broad:
    1. **Per claim:** the `Budget`, with `--max-input-tokens` (default 500,000) and `--max-wall-clock-s` (default 180). It is checked at the top of every turn and raises `BudgetExceeded`, which `run.py` catches, so that claim stops without a terminal action.
    2. **Per run:** `main()` returns exit code 1 if any claim did not terminate (`return 1 if any_failure else 0`). That gives a cron job or CI a hard signal to stop. In my run all 8 claims terminated (`summary.md` has an outcome for every row).
    3. **Global:** revoke `ANTHROPIC_API_KEY`. `make_client()` then fails before any claim is processed, which is exactly what happened in my first terminal (Q19).

    If the model itself misbehaves by ending early, the backstop sends the claim to human review rather than dropping it. That happened 4 times in my run.

---

## Part 3 — Honest assessment

19. **What broke.** One thing that failed first try in your environment, and how you fixed it. (If nothing, what you checked to be sure.)
    → **The API key.**
    - My first `python -m claims_intake.run --all` failed in `client.py` `make_client()` with `RuntimeError: ANTHROPIC_API_KEY is not set`. I had exported the key in a different terminal, and environment variables are per terminal session.
    - After re-exporting, the next attempt failed with `anthropic.BadRequestError: Error code: 400 - {'error': {'message': 'This key was not found. Please check key was inputed correctly.'}}`. I had retyped the `voc-` key by hand and introduced extra characters. That attempt left the partial run folder `runs/20261111_162451`.
    - The fix was to copy the key exactly from the Vocareum workspace and set `ANTHROPIC_BASE_URL=https://claude.vocareum.com` in the **same** shell that runs the system.
    - The next run, `20261111_163300`, completed all 8 claims (`summary.md`: 4 routed, 4 escalated, total $0.1196).

    For Systems 2-4 I then ran everything from one script in one shell, so the key was set once. I verified every exit code: all `# exit code: 0` in the logs, and test totals 30/30/35/33 as expected, with System 2's `28 passed, 2 skipped` before its run.

20. **What you'd change.** One architectural decision you'd make differently, grounded in what you observed.
    → **In System 1, give the model one structured nudge before the backstop fires.** In run `20261111_163300`, **4 of 8** claims (01, 03, 06, 07) ended after a single `tool_use` turn without classifying or routing. Three of them were expected to route (`expected_outcome: "routed"`). Today `run.py` immediately escalates them to humans (`escalations.jsonl`), which is safe but sends 50% of claims to manual review.

    I would keep the loop exactly as it is. In `_run_one()`, when `run()` returns but `not session.terminal_called`, I'd send **one** follow-up user message, "You ended without a terminal action; call `route_to_adjuster` or `escalate_to_human`", and call `run()` again. The **same `Budget`** object would bound the retry, so the loop still has no turn counter.

    Only if the model still doesn't commit would the deterministic backstop escalate. Every claim still terminates, but the 3 routable claims would likely route. The comparison run to confirm this, the rubric's stand-out suggestion `--model claude-sonnet-4-6`, would also show whether a stronger model removes the need.

    A second, smaller change, from System 4: `defects_since()` ignores the shift. "shift C: 17 new defects" actually counts 6 A + 5 B + 6 C rows. I'd add `AND shift = ?` so the query uses the existing `idx_defects_shift_ts` index as its name implies.
