# Reflection brief - Harness Engineering with Claude and Claude Code

**Name:** Rakesh
**Date:** 2026-11-11
**Run mode and model(s):**

- **System 1: live.** I ran `python -m claims_intake.run --all` against the Claude API (Vocareum
  endpoint) in `exercises/03-dynamic-decomposition/solution`, with model
  `claude-haiku-4-5-20251001` (from `summary.md`). The run is `runs/20261111_163300`, with a total
  estimated cost of $0.1196. Evidence is in `system1/`.
- **Systems 2 and 4: offline.** System 2 used the chars/4 token estimate, extractive summaries and
  an answerability check (`budget.json`: `"token_counter": "heuristic-chars/4"`). System 4 replayed
  the recorded response, which is an authored fixture (see its `_provenance` field).
- **System 3** needs no key.

Every log header in `system2/` to `system4/` states its mode.

Evidence folders: `system1/` `system2/` `system3/` `system4/` (next to this file).

---

## Part 1 - System by system

### System 1 - Agentic loop

**1.1 Where is loop termination decided?**

Loop termination is decided in `claims_intake/loop.py`, in the function `run()` (line 46).

The loop is driven only by the `stop_reason` contract, never by the assistant's text. The module
docstring states it (lines 4-7): control flow is driven by `response.stop_reason`, and the loop
condition is `response.stop_reason == "tool_use"`, nothing else (line 60).

- **`stop_reason == "end_turn"`: stop (line 103).** The model has finished, so `run()` returns.
  If the model ended without a terminal action (no `route_to_adjuster` call), the deterministic
  backstop escalates the claim, so it is never silently dropped. `tests/test_run_backstop.py`
  covers this, and it happened 4 times in my run (see 1.3).
- **`stop_reason == "tool_use"`: continue (line 113).** `run()` executes the requested tools,
  sends the results back, and calls the model again.
- **Any other `stop_reason`** (for example `max_tokens`): `run()` raises `UnexpectedStopReason`
  with the message `turn {turn}: unexpected stop_reason=...` (line 131). The loop fails loudly
  instead of treating a truncated response as a finished one.

Each iteration starts with `budget.check()` (line 70). That is what bounds the loop, not a
hard-coded number of turns. Every turn's `stop_reason` is recorded in the trace (line 95).

Evidence from my run `20261111_163300`: every claim in `summary.md` ended in a routing decision
or an escalation, and each trace finishes with `end_turn` after one or more `tool_use` turns.

**1.2 One anti-pattern the loop avoids, and what would break if it were used**

**Anti-pattern: an integer-literal iteration cap**, such as `for turn in range(10):` or
`while turns < 5:`, used as the way to stop the loop.

**Concrete consequence if it were used:** the loop would stop because a counter ran out, not
because the model finished. My own run shows the risk. In run `20261111_163300`, the number of
turns per claim varied from 2 to 6, and `claim_02_stolen_bike` needed **6 turns** to reach
`routed`. A literal cap of 5, which looks generous next to the 2-turn claims, would have cut
claim_02 off mid-work. It would have returned **neither routed nor escalated**, and nothing would
have signalled that the work was incomplete. The opposite failure also happens: if the number is
set too high, a model stuck repeating a tool call burns tokens until the arbitrary limit is
reached. That costs money: claim_02 alone used 21,156 input tokens.

**How my code avoids it:** `run()` continues only on `tool_use` and stops on `end_turn`. Runaway
cost is controlled by `budget.check()`, which fails loudly instead of silently truncating. The
test `test_no_integer_literal_iteration_cap_in_loop` pins this. It fails if anyone adds a literal
turn cap to the loop. It is part of my suite run, `system1/tests.log`: **30 passed in 0.56s**,
including `tests/test_antipatterns.py` (4 tests).

**1.3 Run summary and one trace**

Live run `python -m claims_intake.run --all`, saved to `runs/20261111_163300/` (summary in
`runs/20261111_163300/summary.md`). It processed 8 claims: **4 routed, 4 escalated**. Total
estimated cost was $0.1196.

| Claim | Expected | Outcome | Turns | Tokens in/out |
|---|---|---|---|---|
| claim_01_kitchen_fire | routed | escalated | 2 | 6,372 / 469 |
| claim_02_stolen_bike | routed | routed | 6 | 21,156 / 898 |
| claim_03_water_damage | routed | escalated | 2 | 5,731 / 182 |
| claim_04_neighbor_injury | routed | routed | 4 | 14,174 / 822 |
| claim_05_auto_collision | routed | routed | 4 | 14,952 / 984 |
| claim_06_low_confidence_escalation | escalated | escalated | 2 | 6,285 / 576 |
| claim_07_tree_falls_on_car | routed | escalated | 2 | 6,388 / 505 |
| claim_08_minor_porch_damage | routed | routed | 5 | 18,126 / 855 |

Every claim ended in a routing decision or an escalation, so none hit `UnexpectedStopReason`.

**What I observed.** The routed and escalated claims followed two different paths in the traces:

- **Routed (02, 04, 05, 08).** `lookup_policy` → `record_claim_fact` → `classify_claim` →
  `assess_severity` → `route_to_adjuster`, then `end_turn`. 4-6 turns.
- **Escalated (01, 03, 06, 07).** Only one `tool_use` turn (`lookup_policy`, plus
  `record_claim_fact` calls for 01, 06 and 07), then the model returned `end_turn` *without* calling
  a terminal tool. It never called `classify_claim`. Every row in `escalations.jsonl` gives the
  same reason: `"model ended its turn without a terminal action (deterministic backstop)"`, with
  `recommended_action: "human review of the full transcript"`.

So none of the 4 escalations was a decision by the model. All 4 came from the deterministic
backstop. For claim_06 (designed to be low-confidence) escalation was the expected result. For
01, 03 and 07, which the fixtures expected to route, Haiku stopped early and the backstop caught
it. This is the loop's guarantee working as designed: `run()` stops when the model says
`end_turn`, but a claim can never end in limbo, because the backstop turns an unfinished claim
into an escalation for human review. The loop guarantees *that* every claim ends in a routing
decision or an escalation; it does not guarantee *which* one the model reaches.

Trace `runs/20261111_163300/traces/claim_02_stolen_bike.jsonl`, stop_reason by turn:

| Turn | stop_reason | Tools the model called | What `run()` did |
|---|---|---|---|
| 1 | `tool_use` | `lookup_policy` (POL-1007) | executed, continued (line 113) |
| 2 | `tool_use` | `record_claim_fact` ×5, in parallel | executed all 5, continued |
| 3 | `tool_use` | `classify_claim` (theft, confidence 1.0) | executed, continued |
| 4 | `tool_use` | `assess_severity` (low) | executed, continued |
| 5 | `tool_use` | `route_to_adjuster` (queue `theft`) | executed, continued |
| 6 | `end_turn` | none | returned; claim routed to `queues/theft.jsonl` (line 103) |

`tool_use -> tool_use -> tool_use -> tool_use -> tool_use -> end_turn`

The loop ran exactly as long as the model needed (6 turns) and stopped only on `end_turn`. The
run folder also holds `escalations.jsonl` (the 4 escalated claims) and `queues/` with
`auto.jsonl`, `liability.jsonl`, `property_damage.jsonl` and `theft.jsonl` (the 4 routed claims).

### System 2 - Context strategy

**2.1 What was summarised, what was kept verbatim, and why.**
Run `20261111T134107Z`, from `system2/runs_20261111T134107Z/budget.json`: raw baseline **2,123 tokens**
(37 messages), assembled context **884 tokens**, a **58.4% reduction**, against a ceiling of 1,061.

| Section | Tokens | Position | What it holds |
|---|---|---|---|
| Case Facts | 365 | Top | Kept **verbatim**: every sentence that carries an exact value. Order IDs (RS-40418, RS-40977, RS-41203, RS-41560), amounts ($25.00, $18.40), reference IDs (RF-7781, SC-3390, LP-2209), tracking number 1Z999AA10123456784, the full address with ZIP 78704, and 1,250 points |
| Summaries | 333 | Middle | One line per resolved issue. Exact values are replaced by `[see Case Facts]` |
| Recent window | 186 | Bottom | The last 6 messages, **verbatim** |

Why this split:

- Exact values are what a support answer gets wrong, and a paraphrase can silently change them.
  Keeping them verbatim in one block also gives a single source of truth: the summaries never repeat a value that could drift.
- The narrative ("customer's blender arrived cracked, replacement shipped") can be compressed without loss.
- The recent window stays verbatim because it holds the open request (gift wrap on RS-41560).
- Position matters. Facts go first and recent turns go last, so nothing critical sits in the
  middle, where long contexts are least reliable. `eval.jsonl` records where each answer was
  found. Every fact answer for Q1-Q5 sits in `case_facts`, between 9.1% (the tracking number) and
  40.1% (LP-2209) into the context. Q6's "gift wrap" sits in `recent_window` at 87.5%.

**2.2 Control variant.**
`eval.jsonl` scored **6/6**. `eval_control.jsonl` (Case Facts removed, 519 tokens) scored **1/6**.

- Q1-Q5 regressed. Their values existed only in the Case Facts block, because the summaries deliberately strip them.
- Q4 partly survived. "221 Lakeview Dr" appears in the recent window (message m34), but ZIP 78704 does not.
- Q6 (the open gift-wrap request) still passed because it lives in the verbatim recent window.

The extra 365 tokens of Case Facts are therefore what make 5 of the 6 questions answerable.

### System 3 - Claude Code configuration

**3.1 Why a path-scoped rule rather than a directory-level CLAUDE.md.**
API handlers, tests and migrations exist in every service, not in one directory.

- `.claude/rules/api-handlers.md` declares `paths: "services/*/api/**/*.py"`. In `system3/validator.log`
  that one glob matches 2 files, in both `services/orders` and `services/payments`. It will also
  cover any future service with no extra file.
- A directory-level `CLAUDE.md` would have to be copied into every service and kept in sync. It
  would also load for every file in that directory, not just handlers.
- `tests.md` makes the same point across surfaces. One rule spans Python (`services/*/tests/**/*.py`,
  2 files) and React (`apps/web/src/**/*.test.tsx`, 1 file).
- Directory `CLAUDE.md` files (`apps/web/CLAUDE.md`, `services/orders/CLAUDE.md`) are kept for
  what is truly local, such as how to run that app.
- Path-scoped rules load only when a matching file is in play, which keeps the always-on context
  small. The root `CLAUDE.md` holds only the 3 `@` imports (`@.claude/standards/api.md`, `testing.md`, `security.md`) plus workflow notes.

**3.2 Why the skill runs in a forked context.**
`.claude/skills/impact-explorer/SKILL.md` declares `context: fork` and `allowed-tools: Read, Grep, Glob`.
The validator log shows `skill impact-explorer: context=fork allowed-tools=Read, Grep, Glob`.

- Mapping the impact of a change means reading many files. In a fork those reads stay in the
  sub-context, and only the report of at most 30 lines returns. The main conversation, which holds
  the plan, does not fill up with file contents.
- The read-only tool set means exploration cannot change the repo.
- The validator enforces this. `test_forked_skill_with_write_tool` in `system3/tests.log` shows that
  adding `Edit, Bash` makes validation fail.

### System 4 - Layer 3 orchestrator

**4.1 Resume vs fresh, and the staleness threshold.**
`shift_monitor/state.py::decide_recovery()` (line 106) reads `data/checkpoint.json`, which
`run_shift()` writes after the `sliced` and `analyzed` stages. It decides:

- **resume**: a checkpoint exists, it belongs to the same shift, and it is at most
  `STALENESS_THRESHOLD = timedelta(minutes=30)` old (line 16).
- **fresh**: anything else. A stale checkpoint is deleted and the slice is pulled again, because
  new defects may have landed and an old analysis would be wrong.

`system4/recovery_demo.log` shows both paths:

- The first run used `--crash-after analyzed` and exited with code 3, keeping the checkpoint.
- The next run printed `Recovery: resume (checkpoint at stage 'analyzed' is 0 min old (<= threshold))`.
  It reused the saved analysis instead of calling the model again, and still reported 17 of 40.
- The tests cover the other side: `test_stale_crash_restarts_fresh` (2 hours old gives fresh, and
  the model is called once) and `test_checkpoint_at_exact_threshold_is_resumed`.

**4.2 How a fork stays isolated.**
`shift_monitor/fork.py` isolates forks in three ways:

- `create_fork()` copies the hot state into `data/forks/<name>/` and gives the fork its own `scratchpad.jsonl`.
- `query_fork()` opens SQLite with `mode=ro`, so a fork cannot write to the warm tier.
- Every fork write goes under `data/forks/<name>/`.

In `system4/forks.log` I forked two competing hypotheses about the L2/S4 seal leaks:

| Fork | Query | Matches | Finding |
|---|---|---|---|
| `seal-lot` | S4, SEAL_LEAK, shift C | 8 | 7 fall after Apr 22 |
| `press-fixture` | S4, SEAL_LEAK, all shifts | 10 | D-007 (shift A) and D-014 (shift B) also leaked in March |

Both `isolation` reports show `"main_unchanged": true`: the main `hot_state.json` hash equals the
hash recorded when each fork was taken. The main `shift_scratchpad.jsonl` still has 1 line.
`system4/forks/seal-lot/scratchpad.jsonl` and `forks/press-fixture/scratchpad.jsonl` hold different notes.

**4.3 SQL slice and hot-state budget.**
`system4/run_shift.log`, run `2026-04-01_C_20261111T134109Z`:

- The slice printed as `SQL slice (detected_at >= 2026-04-01T00:00:00Z AND shift = 'C'): shift C:
  17 new defects (17 of 40)`. `WarmStore.query_slice()` runs that `WHERE` clause, so the prompt held
  17 rows (2,324 chars) instead of the full history (5,335 chars if all 40 rows were sent).
- `system4/hot_state_size.txt` shows `data/hot_state.json` at **1,312 bytes** against the
  5,120-byte budget. `save_hot()` caps the hot state at 5 clusters, a 400-character handoff and 3
  actions, then trims further if needed.
- The full report (7,618 bytes, `system4/cold/2026-04-01_C_20261111T134109Z.json`) went to the cold
  tier, which is never loaded into a prompt.

---

## Part 2 - Cross-project synthesis

**5. The three layers, by file.**

| Layer | What it means | Where it lives |
|---|---|---|
| Model | The single request/response with Claude | `claims_intake/loop.py` line 72: `response = client.messages.create(model=model, ..., messages=working_messages)`. This is the one call to Claude, and it returns `stop_reason` and content. The client is built by `make_client()` in `claims_intake/client.py`. Also `shift_monitor/analysis.py`, `LiveAnalyzer.analyze()` |
| Harness | What wraps the model inside one task: loop, tools, guards, configuration | `claims_intake/loop.py`, `run()`: the `stop_reason` loop, tool execution and `budget.check()`. It is called per claim from `_run_one()` in `claims_intake/run.py`. It carried `claim_02_stolen_bike` through 6 turns in run `20261111_163300`. For Claude Code: System 3's `CLAUDE.md`, `.claude/rules/`, `.claude/skills/impact-explorer/SKILL.md` and `.claude/settings.json` |
| Orchestration | What spans sessions: state tiers, recovery, forks | `shift_monitor/shift.py`, `run_shift()` (fresh session per shift, checkpoints), `state.py` (hot tier, `decide_recovery`), `warm.py` (SQL slice), `fork.py`. Seen in `system4/shift_scratchpad.jsonl`, one line per session |

**6. Deterministic enforcement vs prompt-based guidance.**

- **System 3, the clearest pair.** The impact-explorer skill's body *asks* "Do not propose or make
  edits", which is prompt guidance the model could ignore. Its `allowed-tools: Read, Grep, Glob`
  makes edits *impossible*, which is deterministic enforcement. The validator checks this
  (`system3/validator.log`), and `test_forked_skill_with_write_tool` fails if a write tool is added.
  Likewise, `.claude/settings.json` denies `Read(./.env)` instead of only asking in `security.md`.
- **System 1.** Termination is enforced in code, not left to the model's wording. `run()` in
  `claims_intake/loop.py` stops only when `response.stop_reason == "end_turn"` (line 103). Any
  unexpected `stop_reason` raises `UnexpectedStopReason` (line 131). Each iteration's
  `budget.check()` (line 70) bounds cost however the model behaves. Nothing the model writes
  ("I'm done") can end or extend the loop.
- **System 1, seen in my run.** Finishing each claim with a terminal tool call
  (`route_to_adjuster`) is something the model is *guided* to do. Run `20261111_163300` shows that
  guidance alone is not enough: in 4 of 8 claims (01, 03, 06, 07), Haiku returned `end_turn` after
  one tool turn without ever calling a terminal tool. The *deterministic* backstop caught all 4 and
  escalated them. `escalations.jsonl` records `"model ended its turn without a terminal action
  (deterministic backstop)"`. Prompt guidance shaped what the model tried; code guaranteed the
  outcome.
- In System 4, `check_analysis()` rejects any cluster that cites a defect outside the 17-row slice.

**7. Context management: within one conversation vs across sessions.**

| | System 2: one conversation | System 4: across sessions |
|---|---|---|
| The problem | A single conversation grows too long | Many sessions must share what matters, and nothing carries over unless it is written down |
| How it is solved | Restructure what goes into *one* prompt | Decide what survives *between* prompts |
| Numbers | 2,123 raw tokens down to 884 assembled (58.4% smaller) | 17 of 40 rows sent (2,324 vs 5,335 prompt chars). Carried state: a 1,312-byte hot state (of 5,120 allowed), with the full 7,618-byte report in the cold tier |
| Rule for exact values | Case Facts is the verbatim source of truth for exact values | The hot state carries only the watermark, cluster counts and handoff; detail stays in the cold tier and warm SQL |
| What the evidence shows | The control drop from 6/6 to 1/6 shows what the verbatim facts buy | The watermark `2026-04-30T22:47:00Z` in `hot_state.json` is what lets the next shift query only newer rows |

Both systems follow the same principle: keep exact, decision-critical facts in a small, protected
place and compress or move everything else. The difference is where the boundary sits. System 2
compresses *inside* a context window. System 4 moves data *out of* the window into tiers, so each
fresh session starts small.

**8. A behaviour a test suite guarantees that a single run does not reveal.**
`test_no_integer_literal_iteration_cap_in_loop` (System 1, `system1/tests.log`) guarantees that
`run()` contains no hard-coded turn limit.

A single run cannot show this. In run `20261111_163300` the longest claim (`claim_02_stolen_bike`)
took 6 turns. A loop with a hidden `range(10)` cap would have produced exactly the same 8 outcomes
and the same traces. The flaw would only appear on a future claim needing more than 10 turns, which
would then be cut off silently. The run can only show that no claim *hit* a cap, not that no cap
*exists*. The test checks the code itself, so it holds for every future claim.

The same applies to the `UnexpectedStopReason` path (`loop.py` line 131). All 8 traces in this run
ended with `end_turn`, so the run never exercised it. In System 4, `test_stale_crash_restarts_fresh`
covers the fresh-start path, which the recovery demo (resume only) never showed.

---

## Part 3 - Optional stand-out work

- **Exercised the fork path end to end.** See 4.2: two competing hypotheses in isolated forks
  (`system4/forks.log`). The evidence favours the seal-lot hypothesis for shift C, but the March
  shift A and B leaks keep fixture drift open.
- **Broke a system on purpose.** The System 2 control variant (Case Facts removed) dropped from 6/6 to 1/6.
  In System 1, `claim_06_low_confidence_escalation` is the deliberately low-confidence claim. In
  run `20261111_163300` the model recorded 4 facts, then stopped without classifying or routing it.
  The deterministic backstop escalated it for human review instead of letting it guess a queue
  (`escalations.jsonl`). The system degraded safely, but the safety came from code, not from
  the model choosing to escalate.
- **Crash recovery.** `system4/recovery_demo.log` shows a simulated crash after the `analyzed`
  stage and a resume on the next run.
- **Not done.** The Haiku vs `claude-sonnet-4-6` model comparison for System 1.
