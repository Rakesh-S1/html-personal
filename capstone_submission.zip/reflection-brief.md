# Reflection brief - Harness Engineering with Claude and Claude Code

**Name:** Rakesh
**Date:** 2026-11-11
**Run mode and model(s):** Offline. No `ANTHROPIC_API_KEY` was set for these runs, so System 1 used
the scripted stand-in model (`run.json`: `"mode": "offline-scripted"`). System 2 used the chars/4
token estimate, extractive summaries and an answerability check (`budget.json`: `"token_counter":
"heuristic-chars/4"`). System 4 replayed the recorded response, which is an authored fixture (see
its `_provenance` field). System 3 needs no key. Every log header in `system1/` to `system4/`
states its mode. Re-running with a key via `scripts/run_capstone.py` replaces these numbers with
live ones; the answers below then need their numbers updated.

Evidence folders: `system1/` `system2/` `system3/` `system4/` (next to this file).

---

## Part 1 - System by system

### System 1 - Agentic loop

**1.1 Where is loop termination decided?**
In `claims_intake/loop.py`, in two functions:

- `next_action(stop_reason)` (line 67) is the only place that turns a `stop_reason` into control flow:
  - `tool_use` returns `execute_tools`: run every `tool_use` block, send all results back, call the model again.
  - `end_turn` returns `finish`: leave the loop.
  - `pause_turn` returns `resume`: call again with no new user message.
  - Anything else (`max_tokens`, `refusal`, unknown) returns `abort`.
- `run_claim()` (line 83) runs the loop. After it, a guard (line 127) checks `ctx.decided`. If the
  model stopped without calling `route_claim` or `escalate_claim`, or hit the `MAX_TURNS = 10`
  safety cap, the claim is escalated in code with category `loop_guard`.

In run `20261111T134106Z` no claim needed that guard. Every row in `system1/runs_20261111T134106Z/escalations.jsonl` has `"forced_by_loop": false`.

**1.2 One anti-pattern the loop avoids.**
It never decides to stop by reading the assistant's text, for example looking for "done" or
"final answer". Only `stop_reason` counts. The evidence is in the CLM-1003 trace
(`system1/runs_20261111T134106Z/traces/CLM-1003.json`). Every turn has a text block like "Routing 1
sub-issue(s)." or "Escalating CLM-1003 (high_value).", and the loop still continued on turns 1-4
because each had `stop_reason: tool_use`. It stopped on turn 5 only because that turn returned
`end_turn`. The test `test_text_saying_done_does_not_stop_the_loop` in `system1/tests.log` pins
this: a reply saying "Done. Final answer." with `stop_reason: tool_use` still ran 3 turns.

A second anti-pattern it avoids is splitting parallel tool results. Line 106 sends all results in one user
message. In the CLM-1007 trace, turn 1 called `lookup_policy` and `classify_claim` together, turn 2
ran two `check_coverage` calls (one per sub-issue), and turn 3 made two `route_claim` calls.

**1.3 Run summary and trace.**
From `system1/runs_20261111T134106Z/summary.md`: 8 claims processed, 4 routed, 4 escalated, 3-5 turns
per claim (mean 4.00). Every claim ended in a routing decision or an escalation:

| Claim | Outcome |
|---|---|
| CLM-1001 | auto_physical_damage |
| CLM-1002 | property_claims |
| CLM-1003 | escalated high_value |
| CLM-1004 | escalated coverage, policy lapsed |
| CLM-1005 | travel_claims |
| CLM-1006 | escalated missing_information, no policy_id |
| CLM-1007 | decomposed into 2 sub-issues: property_claims + theft_unit |
| CLM-1008 | escalated fraud_review |

Trace `traces/CLM-1003.json`, turn by turn:

| Turn | stop_reason | Action | Tools called | Tool error? |
|---|---|---|---|---|
| 1 | tool_use | execute_tools | lookup_policy, classify_claim | no, no |
| 2 | tool_use | execute_tools | check_coverage | no |
| 3 | tool_use | execute_tools | route_claim | **yes**: $38,000 exceeds the $25,000 limit |
| 4 | tool_use | execute_tools | escalate_claim | no |
| 5 | end_turn | finish | none | none |

### System 2 - Context strategy

**2.1 What was summarised, what was kept verbatim, and why.**
Run `20261111T134107Z`, from `system2/runs_20261111T134107Z/budget.json`: raw baseline **2,123 tokens**
(37 messages), assembled context **884 tokens**, a **58.4% reduction**, against a ceiling of 1,061.

| Section | Tokens | Position | What it holds |
|---|---|---|---|
| Case Facts | 365 | Top | Kept **verbatim**: every sentence that carries an exact value. Order IDs (RS-40418, RS-40977, RS-41203, RS-41560), amounts ($25.00, $18.40), reference IDs (RF-7781, SC-3390, LP-2209), tracking number 1Z999AA10123456784, the full address with ZIP 78704, and 1,250 points |
| Summaries | 333 | Middle | One line per resolved issue. Exact values are replaced by `[see Case Facts]` |
| Recent window | 186 | Bottom | The last 6 messages, **verbatim** |

Why this split:

- Exact values are what a support answer gets wrong, and a paraphrase can silently change them.
  Keeping them verbatim in one block also gives a single source of truth: the summaries never repeat a value that could drift.
- The narrative ("customer's blender arrived cracked, replacement shipped") can be compressed without loss.
- The recent window stays verbatim because it holds the open request (gift wrap on RS-41560).
- Position matters. Facts go first and recent turns go last, so nothing critical sits in the
  middle, where long contexts are least reliable. `eval.jsonl` records where each answer was
  found. Every fact answer for Q1-Q5 sits in `case_facts`, between 9.1% (the tracking number) and
  40.1% (LP-2209) into the context. Q6's "gift wrap" sits in `recent_window` at 87.5%.

**2.2 Control variant.**
`eval.jsonl` scored **6/6**. `eval_control.jsonl` (Case Facts removed, 519 tokens) scored **1/6**.

- Q1-Q5 regressed. Their values existed only in the Case Facts block, because the summaries deliberately strip them.
- Q4 partly survived. "221 Lakeview Dr" appears in the recent window (message m34), but ZIP 78704 does not.
- Q6 (the open gift-wrap request) still passed because it lives in the verbatim recent window.

The extra 365 tokens of Case Facts are therefore what make 5 of the 6 questions answerable.

### System 3 - Claude Code configuration

**3.1 Why a path-scoped rule rather than a directory-level CLAUDE.md.**
API handlers, tests and migrations exist in every service, not in one directory.

- `.claude/rules/api-handlers.md` declares `paths: "services/*/api/**/*.py"`. In `system3/validator.log`
  that one glob matches 2 files, in both `services/orders` and `services/payments`. It will also
  cover any future service with no extra file.
- A directory-level `CLAUDE.md` would have to be copied into every service and kept in sync. It
  would also load for every file in that directory, not just handlers.
- `tests.md` makes the same point across surfaces. One rule spans Python (`services/*/tests/**/*.py`,
  2 files) and React (`apps/web/src/**/*.test.tsx`, 1 file).
- Directory `CLAUDE.md` files (`apps/web/CLAUDE.md`, `services/orders/CLAUDE.md`) are kept for
  what is truly local, such as how to run that app.
- Path-scoped rules load only when a matching file is in play, which keeps the always-on context
  small. The root `CLAUDE.md` holds only the 3 `@` imports (`@.claude/standards/api.md`, `testing.md`, `security.md`) plus workflow notes.

**3.2 Why the skill runs in a forked context.**
`.claude/skills/impact-explorer/SKILL.md` declares `context: fork` and `allowed-tools: Read, Grep, Glob`.
The validator log shows `skill impact-explorer: context=fork allowed-tools=Read, Grep, Glob`.

- Mapping the impact of a change means reading many files. In a fork those reads stay in the
  sub-context, and only the report of at most 30 lines returns. The main conversation, which holds
  the plan, does not fill up with file contents.
- The read-only tool set means exploration cannot change the repo.
- The validator enforces this. `test_forked_skill_with_write_tool` in `system3/tests.log` shows that
  adding `Edit, Bash` makes validation fail.

### System 4 - Layer 3 orchestrator

**4.1 Resume vs fresh, and the staleness threshold.**
`shift_monitor/state.py::decide_recovery()` (line 106) reads `data/checkpoint.json`, which
`run_shift()` writes after the `sliced` and `analyzed` stages. It decides:

- **resume**: a checkpoint exists, it belongs to the same shift, and it is at most
  `STALENESS_THRESHOLD = timedelta(minutes=30)` old (line 16).
- **fresh**: anything else. A stale checkpoint is deleted and the slice is pulled again, because
  new defects may have landed and an old analysis would be wrong.

`system4/recovery_demo.log` shows both paths:

- The first run used `--crash-after analyzed` and exited with code 3, keeping the checkpoint.
- The next run printed `Recovery: resume (checkpoint at stage 'analyzed' is 0 min old (<= threshold))`.
  It reused the saved analysis instead of calling the model again, and still reported 17 of 40.
- The tests cover the other side: `test_stale_crash_restarts_fresh` (2 hours old gives fresh, and
  the model is called once) and `test_checkpoint_at_exact_threshold_is_resumed`.

**4.2 How a fork stays isolated.**
`shift_monitor/fork.py` isolates forks in three ways:

- `create_fork()` copies the hot state into `data/forks/<name>/` and gives the fork its own `scratchpad.jsonl`.
- `query_fork()` opens SQLite with `mode=ro`, so a fork cannot write to the warm tier.
- Every fork write goes under `data/forks/<name>/`.

In `system4/forks.log` I forked two competing hypotheses about the L2/S4 seal leaks:

| Fork | Query | Matches | Finding |
|---|---|---|---|
| `seal-lot` | S4, SEAL_LEAK, shift C | 8 | 7 fall after Apr 22 |
| `press-fixture` | S4, SEAL_LEAK, all shifts | 10 | D-007 (shift A) and D-014 (shift B) also leaked in March |

Both `isolation` reports show `"main_unchanged": true`: the main `hot_state.json` hash equals the
hash recorded when each fork was taken. The main `shift_scratchpad.jsonl` still has 1 line.
`system4/forks/seal-lot/scratchpad.jsonl` and `forks/press-fixture/scratchpad.jsonl` hold different notes.

**4.3 SQL slice and hot-state budget.**
`system4/run_shift.log`, run `2026-04-01_C_20261111T134109Z`:

- The slice printed as `SQL slice (detected_at >= 2026-04-01T00:00:00Z AND shift = 'C'): shift C:
  17 new defects (17 of 40)`. `WarmStore.query_slice()` runs that `WHERE` clause, so the prompt held
  17 rows (2,324 chars) instead of the full history (5,335 chars if all 40 rows were sent).
- `system4/hot_state_size.txt` shows `data/hot_state.json` at **1,312 bytes** against the
  5,120-byte budget. `save_hot()` caps the hot state at 5 clusters, a 400-character handoff and 3
  actions, then trims further if needed.
- The full report (7,618 bytes, `system4/cold/2026-04-01_C_20261111T134109Z.json`) went to the cold
  tier, which is never loaded into a prompt.

---

## Part 2 - Cross-project synthesis

**5. The three layers, by file.**

| Layer | What it means | Where it lives |
|---|---|---|
| Model | The single request/response with Claude | `system1_claims_intake/claims_intake/client.py`, `LiveClient.create()` (one `messages.create` call that returns `stop_reason` and content). Also `shift_monitor/analysis.py`, `LiveAnalyzer.analyze()` |
| Harness | What wraps the model inside one task: loop, tools, guards, configuration | `claims_intake/loop.py` (`next_action`, `run_claim`) and `claims_intake/tools.py`, which carried CLM-1003 through 5 turns. For Claude Code: System 3's `CLAUDE.md`, `.claude/rules/`, `.claude/skills/impact-explorer/SKILL.md` and `.claude/settings.json` |
| Orchestration | What spans sessions: state tiers, recovery, forks | `shift_monitor/shift.py`, `run_shift()` (fresh session per shift, checkpoints), `state.py` (hot tier, `decide_recovery`), `warm.py` (SQL slice), `fork.py`. Seen in `system4/shift_scratchpad.jsonl`, one line per session |

**6. Deterministic enforcement vs prompt-based guidance.**

- **Prompt-based.** `SYSTEM_PROMPT` in `claims_intake/loop.py` (line 33) *tells* the model to
  escalate any sub-issue above $25,000. A model can ignore or misread that.
- **Deterministic.** `tools.route_claim()` (line 193) *refuses* any sub-issue whose amount exceeds
  `AUTO_APPROVAL_LIMIT`, whatever the model decided. In run `20261111T134106Z` the model attempted
  `route_claim` for CLM-1003 ($38,000). The tool returned an `is_error` result (trace turn 3), and
  the claim ended `escalated: high_value`. The guard, not the prompt, held the line.
- The same contrast appears in System 3. The impact-explorer skill's body *asks* "Do not propose or
  make edits" (guidance), while `allowed-tools: Read, Grep, Glob` makes edits impossible
  (enforcement). Likewise, `.claude/settings.json` denies `Read(./.env)` instead of only asking in
  `security.md`.
- In System 4, `check_analysis()` rejects any cluster that cites a defect outside the 17-row slice.

**7. Context management: within one conversation vs across sessions.**

| | System 2: one conversation | System 4: across sessions |
|---|---|---|
| The problem | A single conversation grows too long | Many sessions must share what matters, and nothing carries over unless it is written down |
| How it is solved | Restructure what goes into *one* prompt | Decide what survives *between* prompts |
| Numbers | 2,123 raw tokens down to 884 assembled (58.4% smaller) | 17 of 40 rows sent (2,324 vs 5,335 prompt chars). Carried state: a 1,312-byte hot state (of 5,120 allowed), with the full 7,618-byte report in the cold tier |
| Rule for exact values | Case Facts is the verbatim source of truth for exact values | The hot state carries only the watermark, cluster counts and handoff; detail stays in the cold tier and warm SQL |
| What the evidence shows | The control drop from 6/6 to 1/6 shows what the verbatim facts buy | The watermark `2026-04-30T22:47:00Z` in `hot_state.json` is what lets the next shift query only newer rows |

Both systems follow the same principle: keep exact, decision-critical facts in a small, protected
place and compress or move everything else. The difference is where the boundary sits. System 2
compresses *inside* a context window. System 4 moves data *out of* the window into tiers, so each
fresh session starts small.

**8. A behaviour a test suite guarantees that a single run does not reveal.**
`test_end_turn_without_decision_is_forced_to_escalate` (System 1, `system1/tests.log`) guarantees
that if the model ever ends its turn without routing or escalating, the claim is still escalated
(`loop_guard`) rather than silently dropped.

Run `20261111T134106Z` never exercised this path. All 8 claims made a real decision and
`escalations.jsonl` shows `"forced_by_loop": false` on every row. Inspecting that run could only
show the guard was *not needed*, not that it *works*. The same holds for
`test_turn_cap_is_a_safety_net_that_escalates` and, in System 4, `test_stale_crash_restarts_fresh`.
The recovery demo only showed the resume path.

---

## Part 3 - Optional stand-out work

- **Exercised the fork path end to end.** See 4.2: two competing hypotheses in isolated forks
  (`system4/forks.log`). The evidence favours the seal-lot hypothesis for shift C, but the March
  shift A and B leaks keep fixture drift open.
- **Broke a system on purpose.** The System 2 control variant (Case Facts removed) dropped from 6/6 to 1/6.
  In System 1, CLM-1006 is a deliberately ambiguous claim (no policy, "something happened last
  week"). It degraded safely to `missing_information` in 3 turns instead of guessing a queue.
- **Crash recovery.** `system4/recovery_demo.log` shows a simulated crash after the `analyzed`
  stage and a resume on the next run.
- **Not done (needs an API key).** The Haiku vs `claude-sonnet-4-6` comparison for System 1. The
  command is `python -m claims_intake.run --all --model claude-sonnet-4-6`.
