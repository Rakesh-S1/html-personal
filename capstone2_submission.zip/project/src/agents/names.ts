/**
 * Subagent names - the keys under which agents are registered with the SDK.
 * The orchestrator prompt refers to agents by these exact names.
 */
export const AGENT_NAMES = {
  codeQuality: 'code-quality-analyzer',
  testCoverage: 'test-coverage-analyzer',
  refactoring: 'refactoring-suggester'
} as const;

export type AgentName = typeof AGENT_NAMES[keyof typeof AGENT_NAMES];
