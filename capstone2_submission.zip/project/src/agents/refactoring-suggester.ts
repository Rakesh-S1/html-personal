import type { AgentDefinition } from '@anthropic-ai/claude-agent-sdk';
import { REFACTORING_SUGGESTER_PROMPT } from '../prompts/refactoring-suggester.prompt.js';
import { GITHUB_MCP_TOOLS } from '../config/mcp.config.js';

/**
 * Refactoring Suggester
 * Design patterns, modern language features, extract-function candidates, dead code.
 *
 * Tools (read-only):
 * - Read/Grep/Glob: inspect local files
 * - GitHub get_file_contents: read the PR's version of the file
 * - Skill: load refactoring-catalog / typescript-patterns / javascript-best-practices
 */
export const refactoringSuggester: AgentDefinition = {
  description:
    'Refactoring specialist. Use for every changed file in a pull request to suggest ' +
    'behaviour-preserving improvements: extract function/class, simplify conditionals, remove ' +
    'dead or duplicated code, modernize syntax and apply design patterns, each with before/after ' +
    'code. Does not report bugs. Returns a RefactoringSuggestion JSON object.',
  tools: [
    'Read',
    'Grep',
    'Glob',
    'Skill',
    GITHUB_MCP_TOOLS.getFileContents
  ],
  prompt: REFACTORING_SUGGESTER_PROMPT,
  model: 'inherit'
};
