import type { AgentDefinition } from '@anthropic-ai/claude-agent-sdk';
import { CODE_QUALITY_ANALYZER_PROMPT } from '../prompts/code-quality-analyzer.prompt.js';
import { ESLINT_MCP_TOOLS, GITHUB_MCP_TOOLS } from '../config/mcp.config.js';

/**
 * Code Quality Analyzer
 * Security vulnerabilities, performance issues, bug risks and maintainability.
 *
 * Tools (read-only):
 * - Read/Grep/Glob: inspect local files
 * - GitHub get_file_contents: read the PR's version of the file
 * - ESLint lint-files: real lint findings for local files
 * - Skill: load security-analysis / typescript-patterns / javascript-best-practices
 */
export const codeQualityAnalyzer: AgentDefinition = {
  description:
    'Code quality specialist. Use for every changed file in a pull request to find security ' +
    'vulnerabilities, performance problems, bug risks and maintainability issues, each with a ' +
    'line number, severity and concrete fix. Returns a CodeQualityResult JSON object.',
  tools: [
    'Read',
    'Grep',
    'Glob',
    'Skill',
    GITHUB_MCP_TOOLS.getFileContents,
    ESLINT_MCP_TOOLS.lintFiles
  ],
  prompt: CODE_QUALITY_ANALYZER_PROMPT,
  model: 'inherit'
};
