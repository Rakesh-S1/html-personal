import type { AgentDefinition } from '@anthropic-ai/claude-agent-sdk';
import { TEST_COVERAGE_ANALYZER_PROMPT } from '../prompts/test-coverage-analyzer.prompt.js';
import { GITHUB_MCP_TOOLS } from '../config/mcp.config.js';

/**
 * Test Coverage Analyzer
 * Finds untested functions, branches and edge cases and writes concrete tests for them.
 *
 * Tools (read-only):
 * - Read/Grep/Glob: inspect local files
 * - GitHub get_file_contents: read the source file, list directories, read test files
 * - Skill: load test-coverage-patterns / typescript-patterns
 */
export const testCoverageAnalyzer: AgentDefinition = {
  description:
    'Test coverage specialist. Use for every changed file in a pull request to find which ' +
    'functions, branches and edge cases have no tests, estimate coverage by comparing the source ' +
    'with its test files, and write concrete test cases with meaningful assertions. Returns a ' +
    'TestCoverageResult JSON object.',
  tools: [
    'Read',
    'Grep',
    'Glob',
    'Skill',
    GITHUB_MCP_TOOLS.getFileContents
  ],
  prompt: TEST_COVERAGE_ANALYZER_PROMPT,
  model: 'inherit'
};
