/**
 * Subagent exports
 */
import type { AgentDefinition } from '@anthropic-ai/claude-agent-sdk';
import { codeQualityAnalyzer } from './code-quality-analyzer.js';
import { testCoverageAnalyzer } from './test-coverage-analyzer.js';
import { refactoringSuggester } from './refactoring-suggester.js';
import { AGENT_NAMES } from './names.js';

export { codeQualityAnalyzer } from './code-quality-analyzer.js';
export { testCoverageAnalyzer } from './test-coverage-analyzer.js';
export { refactoringSuggester } from './refactoring-suggester.js';
export { AGENT_NAMES } from './names.js';
export type { AgentName } from './names.js';

/** All subagents keyed by name, in the shape the SDK's `agents` option expects. */
export const reviewAgents: Record<string, AgentDefinition> = {
  [AGENT_NAMES.codeQuality]: codeQualityAnalyzer,
  [AGENT_NAMES.testCoverage]: testCoverageAnalyzer,
  [AGENT_NAMES.refactoring]: refactoringSuggester
};
