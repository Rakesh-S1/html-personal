import { query as sdkQuery } from '@anthropic-ai/claude-agent-sdk';
import type { Options, SDKMessage } from '@anthropic-ai/claude-agent-sdk';
import { ReviewReportJSONSchema, ReviewReportSchema } from './types/report-types.js';
import type { ReviewReport } from './types/report-types.js';
import { reviewAgents, AGENT_NAMES } from './agents/index.js';
import { buildOrchestratorPrompt } from './prompts/index.js';
import { mcpServersConfig, MCP_ALLOWED_TOOLS } from './config/mcp.config.js';
import { RateLimiter } from './utils/rate-limiter.js';
import type { RateLimiterConfig } from './utils/rate-limiter.js';
import { ErrorCodes, ReviewError, withRetry, withTimeout } from './utils/error-handler.js';
import { logger, logReviewComplete, logReviewError, logReviewStart } from './utils/logger.js';

type FileReview = ReviewReport['fileReviews'][number];
type Recommendation = ReviewReport['recommendations'][number];

/** The subset of the SDK `query` function the orchestrator depends on (injectable for tests). */
export type QueryFn = (params: { prompt: string; options?: Options }) => AsyncIterable<SDKMessage>;

/**
 * Orchestrator configuration options
 */
export interface OrchestratorOptions {
  /** Model for the orchestrator; subagents inherit it. Defaults to ANTHROPIC_MODEL. */
  model?: string;
  /** Max agentic turns for the orchestrator session (subagents have their own loops). */
  maxTurns?: number;
  /** Folder containing .claude/skills/. Defaults to PROJECT_ROOT, then cwd. */
  projectRoot?: string;
  /** Hard limit for one review attempt. */
  timeoutMs?: number;
  /** Total attempts for a review (1 = no retry). */
  maxAttempts?: number;
  /** Base delay for exponential backoff between attempts. */
  retryDelayMs?: number;
  /** Max files sent to subagents per PR. */
  maxFiles?: number;
  /** Overrides for the API rate limiter. */
  rateLimits?: Partial<RateLimiterConfig>;
  /** Token estimate reserved per review in the rate limiter. */
  estimatedTokensPerReview?: number;
  /** Injected query function (tests); defaults to the Claude Agent SDK's query. */
  queryFn?: QueryFn;
}

/** One tool call seen during a run, for logging and the execution trace. */
export interface ToolCallTrace {
  agent: string;
  tool: string;
  detail?: string;
}

/** Diagnostics from the most recent review. */
export interface RunDiagnostics {
  subagentsInvoked: string[];
  toolCalls: ToolCallTrace[];
  numTurns?: number;
  costUsd?: number;
  permissionDenials: string[];
}

export const DEFAULT_ORCHESTRATOR_OPTIONS = {
  maxTurns: 40,
  timeoutMs: 20 * 60 * 1000,
  maxAttempts: 2,
  retryDelayMs: 5000,
  maxFiles: 10,
  estimatedTokensPerReview: 60_000
} as const;

/**
 * Tools the session may use. In 'dontAsk' mode anything not listed here is
 * refused without prompting, so this list is the complete allow-list for the
 * orchestrator AND its subagents:
 * - Task: spawns the subagents
 * - Skill + Read/Grep/Glob: used by subagents to load skills and read code
 * - the GitHub/ESLint MCP read tools, derived from the configured servers
 */
export const ORCHESTRATOR_ALLOWED_TOOLS: string[] = [
  'Task',
  'Skill',
  'Read',
  'Grep',
  'Glob',
  ...MCP_ALLOWED_TOOLS
];

/** Tools a code reviewer must never use, refused even if a prompt asks for them. */
export const ORCHESTRATOR_DISALLOWED_TOOLS: string[] = [
  'Bash', 'Write', 'Edit', 'MultiEdit', 'NotebookEdit', 'WebFetch', 'WebSearch'
];

const AGENT_VERSION = '1.0.0';
const FAILED_PREFIX = 'ANALYSIS FAILED';

/**
 * Main Code Review Orchestrator
 * Coordinates subagents to analyze pull requests and generate comprehensive reports
 */
export class CodeReviewOrchestrator {
  readonly model: string;
  readonly maxTurns: number;
  readonly projectRoot: string;
  readonly timeoutMs: number;
  readonly maxAttempts: number;
  readonly retryDelayMs: number;
  readonly maxFiles: number;
  readonly estimatedTokensPerReview: number;
  readonly rateLimiter: RateLimiter;
  private readonly queryFn: QueryFn;
  private diagnostics: RunDiagnostics = emptyDiagnostics();

  constructor(options: OrchestratorOptions = {}) {
    const model = options.model ?? process.env.ANTHROPIC_MODEL;
    if (!model) {
      throw new ReviewError(
        'No model configured: set ANTHROPIC_MODEL or pass options.model',
        ErrorCodes.INVALID_CONFIG
      );
    }
    this.model = model;
    this.maxTurns = options.maxTurns ?? DEFAULT_ORCHESTRATOR_OPTIONS.maxTurns;
    this.projectRoot = options.projectRoot ?? process.env.PROJECT_ROOT ?? process.cwd();
    this.timeoutMs = options.timeoutMs ?? DEFAULT_ORCHESTRATOR_OPTIONS.timeoutMs;
    this.maxAttempts = options.maxAttempts ?? DEFAULT_ORCHESTRATOR_OPTIONS.maxAttempts;
    this.retryDelayMs = options.retryDelayMs ?? DEFAULT_ORCHESTRATOR_OPTIONS.retryDelayMs;
    this.maxFiles = options.maxFiles ?? DEFAULT_ORCHESTRATOR_OPTIONS.maxFiles;
    this.estimatedTokensPerReview =
      options.estimatedTokensPerReview ?? DEFAULT_ORCHESTRATOR_OPTIONS.estimatedTokensPerReview;
    this.rateLimiter = new RateLimiter(options.rateLimits);
    this.queryFn = options.queryFn ?? (sdkQuery as QueryFn);
  }

  /** Diagnostics (subagents invoked, tool calls, cost) from the last review attempt. */
  getDiagnostics(): RunDiagnostics {
    return { ...this.diagnostics, toolCalls: [...this.diagnostics.toolCalls] };
  }

  /** The full SDK options used for a review - exposed so configuration can be tested. */
  buildQueryOptions(): Options {
    return {
      model: this.model,
      agents: reviewAgents,
      mcpServers: mcpServersConfig,
      allowedTools: ORCHESTRATOR_ALLOWED_TOOLS,
      disallowedTools: ORCHESTRATOR_DISALLOWED_TOOLS,
      // Unattended CI run: never prompt; anything outside allowedTools is refused.
      permissionMode: 'dontAsk',
      maxTurns: this.maxTurns,
      // Structured output: the final answer must match ReviewReportSchema (zod-to-json-schema).
      outputFormat: { type: 'json_schema', schema: stripSchemaKey(ReviewReportJSONSchema) },
      // Skills are discovered from <cwd>/.claude/skills when project settings are loaded.
      cwd: this.projectRoot,
      settingSources: ['project'],
      stderr: (data: string) => logger.debug('claude-code stderr', { data: data.trim() })
    };
  }

  /**
   * Review a pull request using parallel subagent analysis
   * @param owner - Repository owner
   * @param repo - Repository name
   * @param prNumber - Pull request number
   * @returns Complete review report
   */
  async reviewPullRequest(
    owner: string,
    repo: string,
    prNumber: number
  ): Promise<ReviewReport> {
    const startedAt = Date.now();
    logReviewStart(owner, repo, prNumber);

    try {
      const report = await withRetry(
        async () => {
          // Reserve rate-limit capacity for this attempt and always give it back.
          await this.rateLimiter.acquire(this.estimatedTokensPerReview);
          try {
            return await withTimeout(
              () => this.runReview(owner, repo, prNumber, startedAt),
              this.timeoutMs,
              `Review of ${owner}/${repo}#${prNumber} exceeded ${Math.round(this.timeoutMs / 1000)}s`
            );
          } finally {
            this.rateLimiter.release();
          }
        },
        this.maxAttempts,
        this.retryDelayMs
      );

      logReviewComplete(owner, repo, prNumber, report.summary.overallScore, report.metadata.duration);
      return report;
    } catch (error) {
      const err = error instanceof Error ? error : new Error(String(error));
      logReviewError(owner, repo, prNumber, err);
      throw error;
    }
  }

  /** One review attempt: run the SDK query, collect the structured output, validate and finalize it. */
  private async runReview(
    owner: string,
    repo: string,
    prNumber: number,
    startedAt: number
  ): Promise<ReviewReport> {
    this.diagnostics = emptyDiagnostics();
    const prompt = buildOrchestratorPrompt({ owner, repo, prNumber, maxFiles: this.maxFiles });

    let structuredOutput: unknown;
    let resultText: string | undefined;

    for await (const message of this.queryFn({ prompt, options: this.buildQueryOptions() })) {
      this.trackMessage(message);

      if (message.type === 'result') {
        this.diagnostics.numTurns = message.num_turns;
        this.diagnostics.costUsd = message.total_cost_usd;
        this.diagnostics.permissionDenials = message.permission_denials.map(d => d.tool_name);
        if (this.diagnostics.permissionDenials.length > 0) {
          logger.warn('Tools were refused by the permission allow-list', {
            tools: this.diagnostics.permissionDenials
          });
        }

        if (message.subtype !== 'success') {
          throw new ReviewError(
            `Orchestrator run ended with ${message.subtype}: ${message.errors.join('; ') || 'no details'}`,
            ErrorCodes.AGENT_FAILED,
            { subtype: message.subtype, numTurns: message.num_turns }
          );
        }
        structuredOutput = message.structured_output;
        resultText = message.result;
      }
    }

    const missing = Object.values(AGENT_NAMES).filter(n => !this.diagnostics.subagentsInvoked.includes(n));
    logger.info('Orchestrator run finished', {
      subagentsInvoked: this.diagnostics.subagentsInvoked,
      toolCalls: this.diagnostics.toolCalls.length,
      numTurns: this.diagnostics.numTurns,
      costUsd: this.diagnostics.costUsd
    });
    if (missing.length > 0) {
      logger.warn('Some subagents were never invoked', { missing });
    }

    const raw = parseReviewOutput(structuredOutput, resultText);
    return finalizeReport(raw, {
      owner,
      repo,
      prNumber,
      startedAt,
      model: this.model
    });
  }

  /** Record subagent spawns and tool calls from assistant messages. */
  private trackMessage(message: SDKMessage): void {
    if (message.type !== 'assistant') return;
    const agent = message.parent_tool_use_id ? 'subagent' : 'orchestrator';

    for (const block of message.message.content) {
      if (block.type !== 'tool_use') continue;
      const input = (block.input ?? {}) as Record<string, unknown>;

      if (block.name === 'Task') {
        const subagent = String(input.subagent_type ?? 'unknown');
        if (!this.diagnostics.subagentsInvoked.includes(subagent)) {
          this.diagnostics.subagentsInvoked.push(subagent);
        }
        this.diagnostics.toolCalls.push({ agent, tool: 'Task', detail: subagent });
        logger.info('Spawning subagent', { subagent, task: input.description });
      } else {
        const detail = typeof input.path === 'string' ? input.path
          : typeof input.skill === 'string' ? input.skill
          : typeof input.command === 'string' ? input.command
          : undefined;
        this.diagnostics.toolCalls.push({ agent, tool: block.name, detail });
        logger.debug('Tool call', { agent, tool: block.name, detail });
      }
    }
  }
}

function emptyDiagnostics(): RunDiagnostics {
  return { subagentsInvoked: [], toolCalls: [], permissionDenials: [] };
}

/** zod-to-json-schema adds a `$schema` URL; the API only needs the schema body. */
export function stripSchemaKey(schema: Record<string, unknown>): Record<string, unknown> {
  const { $schema: _ignored, ...rest } = schema;
  return rest;
}

/**
 * Validate the orchestrator's output against ReviewReportSchema.
 * Prefers the SDK's structured_output; falls back to JSON found in the result text.
 */
export function parseReviewOutput(structuredOutput: unknown, resultText?: string): ReviewReport {
  const candidates: unknown[] = [];
  if (structuredOutput !== undefined && structuredOutput !== null) candidates.push(structuredOutput);
  const fromText = extractJson(resultText);
  if (fromText !== undefined) candidates.push(fromText);

  let lastIssues = 'no structured output was returned';
  for (const candidate of candidates) {
    const parsed = ReviewReportSchema.safeParse(candidate);
    if (parsed.success) return parsed.data;
    lastIssues = parsed.error.issues
      .slice(0, 5)
      .map(i => `${i.path.join('.') || '(root)'}: ${i.message}`)
      .join('; ');
  }

  throw new ReviewError(
    `Orchestrator output did not match the ReviewReport schema: ${lastIssues}`,
    ErrorCodes.STRUCTURED_OUTPUT_FAILED
  );
}

/** Pull a JSON object out of free text (bare, or inside a ```json fence). */
export function extractJson(text?: string): unknown {
  if (!text) return undefined;
  const fenced = /```(?:json)?\s*([\s\S]*?)```/.exec(text);
  const body = fenced?.[1] ?? text;
  const start = body.indexOf('{');
  const end = body.lastIndexOf('}');
  if (start === -1 || end <= start) return undefined;
  try {
    return JSON.parse(body.slice(start, end + 1));
  } catch {
    return undefined;
  }
}

interface FinalizeContext {
  owner: string;
  repo: string;
  prNumber: number;
  startedAt: number;
  model: string;
  now?: number;
}

/**
 * Deterministic post-processing of the model's report:
 * - identity and metadata come from the harness, not the model
 * - summary numbers are recomputed from the findings
 * - a report always carries recommendations, and failed agent sections are flagged
 */
export function finalizeReport(raw: ReviewReport, ctx: FinalizeContext): ReviewReport {
  const fileReviews: FileReview[] = raw.fileReviews.map(review => ({
    ...review,
    codeQuality: { ...review.codeQuality, file: review.file },
    testCoverage: { ...review.testCoverage, file: review.file },
    refactorings: { ...review.refactorings, file: review.file }
  }));

  const recommendations: Recommendation[] = raw.recommendations.length > 0
    ? [...raw.recommendations]
    : deriveRecommendations(fileReviews);

  for (const failure of findFailedSections(fileReviews)) {
    const alreadyFlagged = recommendations.some(
      r => r.description.includes(FAILED_PREFIX) && r.files.includes(failure.file)
    );
    if (!alreadyFlagged) {
      recommendations.push({
        priority: 'high',
        category: 'Review incomplete',
        description: `${FAILED_PREFIX}: the ${failure.section} analysis could not be completed; review this part manually.`,
        files: [failure.file]
      });
    }
  }

  const now = ctx.now ?? Date.now();
  return {
    pullRequest: { owner: ctx.owner, repo: ctx.repo, number: ctx.prNumber },
    fileReviews,
    summary: computeSummary(fileReviews),
    recommendations,
    metadata: {
      analyzedAt: new Date(ctx.startedAt).toISOString(),
      duration: Math.max(0, now - ctx.startedAt),
      agentVersions: {
        ...raw.metadata.agentVersions,
        orchestrator: AGENT_VERSION,
        [AGENT_NAMES.codeQuality]: AGENT_VERSION,
        [AGENT_NAMES.testCoverage]: AGENT_VERSION,
        [AGENT_NAMES.refactoring]: AGENT_VERSION,
        model: ctx.model
      }
    }
  };
}

/**
 * Summary numbers, computed in code from the findings so they are always consistent.
 * File score = 70% code-quality score + 30% estimated test coverage; overall = mean over files.
 */
export function computeSummary(fileReviews: FileReview[]): ReviewReport['summary'] {
  const fileScores = fileReviews.map(
    r => 0.7 * r.codeQuality.overallScore + 0.3 * r.testCoverage.coverageEstimate
  );
  const overallScore = fileScores.length
    ? Math.round(fileScores.reduce((a, b) => a + b, 0) / fileScores.length)
    : 0;

  return {
    totalFiles: fileReviews.length,
    overallScore: clamp(overallScore, 0, 100),
    criticalIssues: fileReviews.reduce(
      (n, r) => n + r.codeQuality.issues.filter(i => i.severity === 'critical').length, 0
    ),
    highPriorityTests: fileReviews.reduce(
      (n, r) => n + r.testCoverage.untestedPaths.filter(p => p.priority === 'critical' || p.priority === 'high').length, 0
    ),
    refactoringOpportunities: fileReviews.reduce((n, r) => n + r.refactorings.suggestions.length, 0)
  };
}

/** Fallback recommendations built from the findings when the model returned none. */
export function deriveRecommendations(fileReviews: FileReview[]): Recommendation[] {
  const recs: Recommendation[] = [];
  for (const r of fileReviews) {
    for (const issue of r.codeQuality.issues) {
      if (issue.severity === 'critical' || issue.severity === 'high') {
        recs.push({
          priority: issue.severity,
          category: issue.category,
          description: `Line ${issue.line}: ${issue.description} Fix: ${issue.suggestion}`,
          files: [r.file]
        });
      }
    }
    const urgentTests = r.testCoverage.untestedPaths.filter(p => p.priority === 'critical' || p.priority === 'high');
    if (urgentTests.length > 0) {
      recs.push({
        priority: urgentTests.some(p => p.priority === 'critical') ? 'critical' : 'high',
        category: 'Testing',
        description: `Add tests for ${urgentTests.map(p => p.location).join(', ')}.`,
        files: [r.file]
      });
    }
    const bigRefactors = r.refactorings.suggestions.filter(s => s.impact === 'high');
    if (bigRefactors.length > 0) {
      recs.push({
        priority: 'medium',
        category: 'Refactoring',
        description: bigRefactors.map(s => `${s.type} at ${s.location}: ${s.description}`).join(' '),
        files: [r.file]
      });
    }
  }
  return recs;
}

/** Sections whose summary marks a failed subagent (see orchestrator prompt, step 3). */
export function findFailedSections(fileReviews: FileReview[]): Array<{ file: string; section: string }> {
  const failed: Array<{ file: string; section: string }> = [];
  for (const r of fileReviews) {
    if (r.codeQuality.summary.startsWith(FAILED_PREFIX)) failed.push({ file: r.file, section: 'code quality' });
    if (r.testCoverage.summary.startsWith(FAILED_PREFIX)) failed.push({ file: r.file, section: 'test coverage' });
    if (r.refactorings.summary.startsWith(FAILED_PREFIX)) failed.push({ file: r.file, section: 'refactoring' });
  }
  return failed;
}

function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}
