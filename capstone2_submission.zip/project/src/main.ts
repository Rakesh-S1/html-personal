import * as dotenv from 'dotenv';
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { CodeReviewOrchestrator } from './orchestrator.js';
import { ReportGenerator, reportBaseName } from './utils/report-generator.js';
import { ErrorCodes, isReviewError } from './utils/error-handler.js';
import { logger } from './utils/logger.js';
import { parseCliArgs, resolveProjectRoot, validateAuth, validateModel } from './config/env.js';

// Load environment variables
dotenv.config();

/** Print friendly error lines and exit (no stack traces for expected problems). */
function fail(lines: string[], exitCode = 1): never {
  for (const line of lines) console.error(line);
  process.exit(exitCode);
}

/** Turn any error into a short, actionable message for the user. */
function describeError(error: unknown): string[] {
  if (isReviewError(error)) {
    switch (error.code) {
      case ErrorCodes.AGENT_TIMEOUT:
        return [`❌ The review timed out (${error.message}).`, '   Try again, or review a smaller PR.'];
      case ErrorCodes.STRUCTURED_OUTPUT_FAILED:
        return [`❌ The agents' report did not match the expected format: ${error.message}`,
          '   Re-run the review; see logs/combined.log for the full trace.'];
      case ErrorCodes.RETRY_EXHAUSTED:
        return [`❌ The review failed after retrying: ${error.message}`,
          '   Check your API key, model name and network, then try again. Details: logs/error.log'];
      case ErrorCodes.INVALID_CONFIG:
        return [`❌ Configuration problem: ${error.message}`];
      default:
        return [`❌ ${error.message} [${error.code}]`];
    }
  }
  const message = error instanceof Error ? error.message : String(error);
  if (/401|authentication|api key/i.test(message)) {
    return ['❌ Authentication with the Claude API failed.', '   Check ANTHROPIC_API_KEY (and ANTHROPIC_BASE_URL on Vocareum).'];
  }
  if (/404|not found/i.test(message)) {
    return ['❌ The repository or pull request was not found.', '   Check owner, repo and PR number (and GITHUB_TOKEN for private repos).'];
  }
  return [`❌ Unexpected error: ${message}`, '   See logs/error.log for details.'];
}

/**
 * Main entry point for the Claude Multi-Agent Code Review System
 * Usage: npm run dev <owner> <repo> <pr-number>
 *
 * Integration test (real PR): npm run dev -- octocat Hello-World 1
 * Final deliverables:         npm run dev -- udacity cd14715-simple-todo-app <1|2|3>
 */
async function main(): Promise<void> {
  // 1. Command-line arguments: argv[0] is node, argv[1] is the script
  const args = parseCliArgs(process.argv.slice(2));
  if (!args.ok) fail(args.errors.map((e, i) => (i === 0 ? `❌ ${e}` : e)));
  const { owner, repo, prNumber } = args.value;

  // 2. Authentication: Anthropic API key OR AWS Bedrock credentials
  const auth = validateAuth(process.env);
  if (!auth.ok) fail(auth.errors.map((e, i) => (i === 0 ? `❌ ${e}` : e)));
  console.log(auth.value === 'bedrock'
    ? '🔐 Using AWS Bedrock authentication'
    : '🔐 Using Anthropic API authentication');

  // 3. Model (required for both auth methods)
  const model = validateModel(process.env);
  if (!model.ok) fail(model.errors.map((e, i) => (i === 0 ? `❌ ${e}` : e)));

  if (!process.env.GITHUB_TOKEN) {
    console.log('ℹ️  GITHUB_TOKEN not set - public repositories still work, with lower GitHub rate limits.');
  }

  const projectRoot = resolveProjectRoot(process.env, process.cwd());
  console.log(`🔍 Reviewing ${owner}/${repo}#${prNumber} with ${model.value}`);

  try {
    // 4. Run the multi-agent review
    const orchestrator = new CodeReviewOrchestrator({ model: model.value, projectRoot });
    const report = await orchestrator.reviewPullRequest(owner, repo, prNumber);

    const diagnostics = orchestrator.getDiagnostics();
    console.log(`🤖 Subagents invoked: ${diagnostics.subagentsInvoked.join(', ') || 'none'}` +
      (diagnostics.costUsd !== undefined ? ` • cost ≈ $${diagnostics.costUsd.toFixed(2)}` : ''));

    // 5. Write all three report formats
    const generator = new ReportGenerator();
    const reportsDir = path.resolve(projectRoot, 'reports');
    await mkdir(reportsDir, { recursive: true });
    const base = path.join(reportsDir, reportBaseName(report));

    const outputs: Array<[string, string]> = [
      [`${base}.json`, generator.generateJSONReport(report)],
      [`${base}.md`, generator.generateMarkdownReport(report)],
      [`${base}.html`, generator.generateHTMLReport(report)]
    ];
    for (const [file, content] of outputs) {
      await writeFile(file, content, 'utf-8');
    }

    const { summary } = report;
    console.log(`\n✅ Review complete: score ${summary.overallScore}/100, ${summary.totalFiles} file(s), ` +
      `${summary.criticalIssues} critical issue(s), ${summary.highPriorityTests} high-priority test gap(s), ` +
      `${summary.refactoringOpportunities} refactoring(s)`);
    console.log('📄 Reports saved:');
    for (const [file] of outputs) console.log(`   ${path.relative(process.cwd(), file)}`);
  } catch (error) {
    logger.error('Review failed', { error: error instanceof Error ? error.message : String(error) });
    fail(describeError(error));
  }
}

main().catch(error => {
  fail(describeError(error));
});
