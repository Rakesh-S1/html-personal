/**
 * Shared prompt fragments used by all three subagent prompts.
 */
import { GITHUB_MCP_TOOLS } from '../config/mcp.config.js';

/** Pretty JSON Schema text for embedding in a prompt (drops the `$schema` URL noise). */
export function schemaText(schema: Record<string, unknown>): string {
  const { $schema: _ignored, ...rest } = schema;
  return JSON.stringify(rest, null, 2);
}

/** How every subagent reads the file it was given. */
export const READING_THE_FILE = `## Reading the file
The orchestrator's task message gives you: owner, repo, the PR head branch/ref, the file path and the PR diff (patch) for that file.
1. Fetch the full file at the PR head with \`${GITHUB_MCP_TOOLS.getFileContents}\` (owner, repo, path, branch = the head ref).
2. Use the patch to know which lines the PR added or changed. Focus on those lines, but read the whole file for context.
3. Line numbers you report are line numbers in the NEW version of the file (the "+" side of the diff).
4. If the fetch fails, analyze the patch you were given instead and say so in your summary. Never invent code you have not seen.`;

/** Rules for the final answer every subagent must follow. */
export const OUTPUT_RULES = `## Output rules (strict)
- Your final message must be ONLY one JSON object - no prose before or after, no markdown fences.
- It must validate against the JSON Schema below: every required field present, enum values spelled exactly, numbers as numbers.
- "file" must be the exact path you were asked to analyze.
- Be specific: cite real identifiers and line numbers from the file. Generic advice ("add more tests", "improve naming") is not acceptable.
- If you genuinely find nothing, return empty arrays and say why in "summary".`;
