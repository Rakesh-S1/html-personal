import { GITHUB_MCP_TOOLS } from '../config/mcp.config.js';
import { AGENT_NAMES } from '../agents/names.js';

export interface OrchestratorPromptInput {
  owner: string;
  repo: string;
  prNumber: number;
  /** Upper bound on files sent to subagents, to keep cost predictable. */
  maxFiles?: number;
}

const { codeQuality, testCoverage, refactoring } = AGENT_NAMES;

/**
 * Prompt for the main orchestrator agent.
 * It must: (1) fetch PR data via GitHub MCP, (2) explicitly invoke all three
 * subagents for every reviewable file, (3) aggregate everything into ReviewReport.
 */
export function buildOrchestratorPrompt({ owner, repo, prNumber, maxFiles = 10 }: OrchestratorPromptInput): string {
  return `You are the orchestrator of an automated, multi-agent code review. Review pull request #${prNumber} in ${owner}/${repo}.
You coordinate; the three specialist subagents do the analysis. Do not analyze the code yourself.

## Step 1 - Fetch the pull request (GitHub MCP)
1. Call \`${GITHUB_MCP_TOOLS.getPullRequest}\` with owner="${owner}", repo="${repo}", pull_number=${prNumber}. Note the title, state and the head ref (head.ref) and head sha.
2. Call \`${GITHUB_MCP_TOOLS.getPullRequestFiles}\` with the same arguments to get every changed file with its status and patch.
3. Reviewable files: source/test code that was added or modified (skip removed files, lock files, images, generated or minified files). Review at most ${maxFiles} files, largest changes first.
If the PR cannot be fetched, stop and return a report with an empty fileReviews array and a critical recommendation explaining the failure.

## Step 2 - Run all three subagents on every reviewable file (Task tool)
For EACH reviewable file, explicitly invoke all three agents with the Task tool. Launch the three Task calls for a file in the same turn so they run in parallel (they are independent), and you may launch several files at once:
- Use the ${codeQuality} agent to analyze <file> for security, performance and maintainability issues.
- Use the ${testCoverage} agent to analyze <file> for missing tests and coverage gaps.
- Use the ${refactoring} agent to analyze <file> for refactoring and modernization opportunities.
Every Task prompt must include: owner="${owner}", repo="${repo}", the head ref, the exact file path, the file's status and its full patch from step 1.
Each agent replies with a single JSON object for that file. Use it as-is: do not rewrite, shorten or invent its findings.

## Step 3 - Handle failures
If a subagent fails, times out or returns something that is not valid JSON, retry that one agent once. If it fails again, still produce the report: put a valid empty result for that section (empty arrays, coverageEstimate 0, overallScore 0 for code quality) whose summary starts with "ANALYSIS FAILED:" plus the reason, and add a "high" recommendation saying that part of the review must be done manually. One failed agent must never stop the whole report.

## Step 4 - Aggregate into the ReviewReport
Return the final answer as structured output matching the ReviewReport schema:
- pullRequest: { owner: "${owner}", repo: "${repo}", number: ${prNumber} }
- fileReviews: one entry per reviewed file: { file, codeQuality, testCoverage, refactorings }, each section being exactly what the matching agent returned.
- summary: totalFiles, overallScore, criticalIssues (count of critical-severity issues), highPriorityTests (untested paths with critical or high priority), refactoringOpportunities (total suggestions). The harness recomputes these numbers from fileReviews, but fill them in consistently.
- recommendations: 3-8 prioritized, deduplicated actions across all files and all three agents. Each has priority (critical | high | medium | low), a short category (e.g. "Security", "Testing", "Refactoring", "Performance"), a specific description that names the function or line, and the files it applies to. Put critical security and untested payment/auth logic first.
- metadata: analyzedAt (ISO timestamp), duration (0 is fine; the harness measures it), agentVersions: { "orchestrator": "1.0.0", "${codeQuality}": "1.0.0", "${testCoverage}": "1.0.0", "${refactoring}": "1.0.0" }.`;
}
