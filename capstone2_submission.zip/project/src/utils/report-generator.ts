import { ReviewReport } from '../types/report-types.js';

type FileReview = ReviewReport['fileReviews'][number];
type Issue = FileReview['codeQuality']['issues'][number];

const SEVERITY_ORDER: Record<Issue['severity'], number> = {
  critical: 0, high: 1, medium: 2, low: 3, info: 4
};
const PRIORITY_ORDER: Record<'critical' | 'high' | 'medium' | 'low', number> = {
  critical: 0, high: 1, medium: 2, low: 3
};

/** Escape text for safe inclusion in HTML (findings often contain `<T>`, `<div>`, `&&`). */
export function escapeHtml(value: unknown): string {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/** Markdown code fence that can't be closed early by backticks inside the code. */
function fence(code: string, lang = 'ts'): string {
  const marker = code.includes('```') ? '~~~~' : '```';
  return `${marker}${lang}\n${code.replace(/\s+$/, '')}\n${marker}`;
}

/** Keep table cells on one line and stop `|` from splitting columns. */
function cell(text: string): string {
  return text.replace(/\r?\n/g, ' ').replace(/\|/g, '\\|');
}

/** Base filename used for all three formats, e.g. `udacity_cd14715-simple-todo-app_1`. */
export function reportBaseName(report: ReviewReport): string {
  const { owner, repo, number } = report.pullRequest;
  return `${owner}_${repo}_${number}`;
}

/**
 * Report Generator
 * Converts ReviewReport to various output formats (Markdown, HTML, JSON)
 */
export class ReportGenerator {
  /**
   * Generate a Markdown report for PR comments
   */
  generateMarkdownReport(report: ReviewReport): string {
    const { pullRequest, summary, recommendations, fileReviews, metadata } = report;
    const sortedRecs = [...recommendations].sort(
      (a, b) => PRIORITY_ORDER[a.priority] - PRIORITY_ORDER[b.priority]
    );

    const formattedRecs = sortedRecs.map((rec, idx) => {
      const emoji = { critical: '🚨', high: '⚠️', medium: '📝', low: '💡' }[rec.priority];
      return `${idx + 1}. ${emoji} **[${rec.priority.toUpperCase()}] ${rec.category}**: ${rec.description}\n` +
        `   - Files: ${rec.files.map(f => `\`${f}\``).join(', ') || 'n/a'}`;
    }).join('\n');

    const formattedFiles = fileReviews.map(review => {
      const { file, codeQuality, testCoverage, refactorings } = review;
      const issues = [...codeQuality.issues].sort(
        (a, b) => SEVERITY_ORDER[a.severity] - SEVERITY_ORDER[b.severity] || a.line - b.line
      );

      const issueTable = issues.length
        ? '| Line | Severity | Category | Issue | Suggestion |\n|---:|---|---|---|---|\n' +
          issues.map(i =>
            `| ${i.line} | \`${i.severity}\` | ${i.category} | ${cell(i.description)} | ${cell(i.suggestion)} |`
          ).join('\n')
        : 'None found.';

      const testList = testCoverage.untestedPaths.length
        ? testCoverage.untestedPaths.map(p =>
            `- **\`${p.location}\`** (${p.type}, \`${p.priority}\` priority): ${p.reasoning}\n\n` +
            fence(p.suggestedTest)
          ).join('\n\n')
        : 'None found.';

      const refactorList = refactorings.suggestions.length
        ? refactorings.suggestions.map(s =>
            `- **${s.type}** at \`${s.location}\` (impact: \`${s.impact}\`): ${s.description}\n\n` +
            `  Before:\n\n${fence(s.before)}\n\n  After:\n\n${fence(s.after)}\n\n  *Benefits:* ${s.benefits}`
          ).join('\n\n')
        : 'None found.';

      return `### 📄 \`${file}\`

**Quality Score:** ${codeQuality.overallScore}/100 | **Coverage estimate:** ~${testCoverage.coverageEstimate}% | ` +
        `**Has tests:** ${testCoverage.hasTests ? `yes (${testCoverage.testFiles.map(t => `\`${t}\``).join(', ')})` : 'no'}

#### Code Quality — ${codeQuality.issues.length} issue(s)
${codeQuality.summary}

${issueTable}

#### Test Gaps — ${testCoverage.untestedPaths.length}
${testCoverage.summary}

${testList}

#### Refactoring Opportunities — ${refactorings.suggestions.length}
${refactorings.summary}

${refactorList}`;
    }).join('\n\n---\n\n');

    return `# 🔍 Code Review Report: ${pullRequest.owner}/${pullRequest.repo} #${pullRequest.number}

## Summary

| Metric | Value |
|--------|-------|
| **Overall Score** | ${summary.overallScore}/100 |
| **Files Reviewed** | ${summary.totalFiles} |
| **Critical Issues** | ${summary.criticalIssues} |
| **High Priority Tests** | ${summary.highPriorityTests} |
| **Refactoring Opportunities** | ${summary.refactoringOpportunities} |

## 🎯 Recommendations

${formattedRecs || 'No recommendations at this time.'}

## 📁 File Details

${formattedFiles || 'No files were reviewed.'}

---

*Generated at ${metadata.analyzedAt} • Duration: ${metadata.duration}ms • ` +
      `Agents: ${Object.entries(metadata.agentVersions).map(([k, v]) => `${k}=${v}`).join(', ')}*
`;
  }

  /**
   * Generate an HTML report for web display
   */
  generateHTMLReport(report: ReviewReport): string {
    const { pullRequest, summary, recommendations, metadata, fileReviews } = report;
    const e = escapeHtml;
    const sortedRecs = [...recommendations].sort(
      (a, b) => PRIORITY_ORDER[a.priority] - PRIORITY_ORDER[b.priority]
    );

    const recList = sortedRecs.map(r => `
      <li class="rec-${e(r.priority)}">
        <span class="priority">[${e(r.priority.toUpperCase())}]</span>
        <strong>${e(r.category)}</strong>: ${e(r.description)}
        <br><small>Files: ${r.files.map(f => `<code>${e(f)}</code>`).join(', ') || 'n/a'}</small>
      </li>`).join('');

    const fileSections = fileReviews.map(review => {
      const { file, codeQuality, testCoverage, refactorings } = review;
      const issues = [...codeQuality.issues].sort(
        (a, b) => SEVERITY_ORDER[a.severity] - SEVERITY_ORDER[b.severity] || a.line - b.line
      );
      const issueRows = issues.map(i => `
            <tr>
              <td class="num">${e(i.line)}</td>
              <td><span class="badge sev-${e(i.severity)}">${e(i.severity)}</span></td>
              <td>${e(i.category)}</td>
              <td>${e(i.description)}</td>
              <td>${e(i.suggestion)}</td>
            </tr>`).join('');

      const tests = testCoverage.untestedPaths.map(p => `
          <div class="item">
            <div><code>${e(p.location)}</code> <span class="badge sev-${e(p.priority)}">${e(p.priority)}</span>
              <span class="muted">${e(p.type)}</span></div>
            <p>${e(p.reasoning)}</p>
            <pre><code>${e(p.suggestedTest)}</code></pre>
          </div>`).join('');

      const refactors = refactorings.suggestions.map(s => `
          <div class="item">
            <div><strong>${e(s.type)}</strong> at <code>${e(s.location)}</code>
              <span class="badge imp-${e(s.impact)}">impact: ${e(s.impact)}</span></div>
            <p>${e(s.description)}</p>
            <div class="ba">
              <div><div class="muted">Before</div><pre><code>${e(s.before)}</code></pre></div>
              <div><div class="muted">After</div><pre><code>${e(s.after)}</code></pre></div>
            </div>
            <p class="muted">Benefits: ${e(s.benefits)}</p>
          </div>`).join('');

      return `
    <section class="file">
      <h3><code>${e(file)}</code></h3>
      <p class="muted">Quality ${e(codeQuality.overallScore)}/100 · Coverage ~${e(testCoverage.coverageEstimate)}% ·
        Tests: ${testCoverage.hasTests ? e(testCoverage.testFiles.join(', ')) : 'none found'}</p>

      <h4>Code quality (${codeQuality.issues.length})</h4>
      <p>${e(codeQuality.summary)}</p>
      ${issues.length ? `<div class="scroll"><table>
          <thead><tr><th>Line</th><th>Severity</th><th>Category</th><th>Issue</th><th>Suggestion</th></tr></thead>
          <tbody>${issueRows}</tbody></table></div>` : '<p class="muted">None found.</p>'}

      <h4>Test gaps (${testCoverage.untestedPaths.length})</h4>
      <p>${e(testCoverage.summary)}</p>
      ${tests || '<p class="muted">None found.</p>'}

      <h4>Refactoring opportunities (${refactorings.suggestions.length})</h4>
      <p>${e(refactorings.summary)}</p>
      ${refactors || '<p class="muted">None found.</p>'}
    </section>`;
    }).join('');

    return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Code Review: ${e(pullRequest.owner)}/${e(pullRequest.repo)} #${e(pullRequest.number)}</title>
  <style>
    * { box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      max-width: 1100px;
      margin: 0 auto;
      padding: 24px 16px;
      background: #f8f9fa;
      color: #212529;
      line-height: 1.5;
    }
    h1 { color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 12px; font-size: 1.6em; }
    h3 { margin-top: 0; overflow-wrap: anywhere; }
    .summary {
      background: white;
      padding: 24px;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
      margin: 24px 0;
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
      gap: 16px;
    }
    .metric { text-align: center; }
    .metric-value { font-size: 2em; font-weight: bold; color: #3498db; }
    .metric-label { color: #6c757d; font-size: 0.9em; }
    ul.recs { list-style: none; padding: 0; }
    ul.recs li { padding: 12px; margin: 8px 0; border-radius: 4px; background: white; }
    .rec-critical { border-left: 4px solid #e74c3c; }
    .rec-high { border-left: 4px solid #f39c12; }
    .rec-medium { border-left: 4px solid #3498db; }
    .rec-low { border-left: 4px solid #27ae60; }
    .priority { font-weight: bold; margin-right: 8px; }
    .rec-critical .priority { color: #e74c3c; }
    .rec-high .priority { color: #f39c12; }
    .rec-medium .priority { color: #3498db; }
    .rec-low .priority { color: #27ae60; }
    .file { background: white; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); padding: 20px; margin: 24px 0; }
    .muted { color: #6c757d; font-size: 0.9em; }
    .scroll { overflow-x: auto; }
    table { border-collapse: collapse; width: 100%; font-size: 0.92em; }
    th, td { border-bottom: 1px solid #e9ecef; padding: 6px 8px; text-align: left; vertical-align: top; }
    td.num { text-align: right; font-variant-numeric: tabular-nums; }
    .badge { display: inline-block; padding: 1px 8px; border-radius: 10px; font-size: 0.8em; font-weight: 600; background: #e9ecef; }
    .sev-critical { background: #fdecea; color: #b02a1a; }
    .sev-high { background: #fff3e0; color: #9a5b00; }
    .sev-medium { background: #e7f1fb; color: #1d5f99; }
    .sev-low, .sev-info { background: #eaf6ee; color: #1e6b3a; }
    .imp-high { background: #fdecea; color: #b02a1a; }
    .imp-medium { background: #e7f1fb; color: #1d5f99; }
    .imp-low { background: #eaf6ee; color: #1e6b3a; }
    .item { border-top: 1px solid #e9ecef; padding: 10px 0; }
    pre { background: #f4f6f8; padding: 10px; border-radius: 6px; overflow-x: auto; font-size: 0.85em; margin: 6px 0; }
    code { font-family: ui-monospace, 'Cascadia Code', Consolas, monospace; }
    .ba { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 12px; }
    footer { text-align: center; color: #6c757d; margin-top: 32px; font-size: 0.9em; }
  </style>
</head>
<body>
  <h1>🔍 Code Review Report: ${e(pullRequest.owner)}/${e(pullRequest.repo)} #${e(pullRequest.number)}</h1>

  <div class="summary">
    <div class="metric">
      <div class="metric-value">${e(summary.overallScore)}</div>
      <div class="metric-label">Overall Score</div>
    </div>
    <div class="metric">
      <div class="metric-value">${e(summary.totalFiles)}</div>
      <div class="metric-label">Files Reviewed</div>
    </div>
    <div class="metric">
      <div class="metric-value">${e(summary.criticalIssues)}</div>
      <div class="metric-label">Critical Issues</div>
    </div>
    <div class="metric">
      <div class="metric-value">${e(summary.highPriorityTests)}</div>
      <div class="metric-label">Tests Needed</div>
    </div>
    <div class="metric">
      <div class="metric-value">${e(summary.refactoringOpportunities)}</div>
      <div class="metric-label">Refactorings</div>
    </div>
  </div>

  <h2>🎯 Recommendations</h2>
  <ul class="recs">${recList || '<li>No recommendations at this time.</li>'}</ul>

  <h2>📁 File Details</h2>
  ${fileSections || '<p class="muted">No files were reviewed.</p>'}

  <footer>
    Generated at ${e(metadata.analyzedAt)} • Duration: ${e(metadata.duration)}ms
  </footer>
</body>
</html>`;
  }

  /**
   * Generate formatted JSON report
   */
  generateJSONReport(report: ReviewReport): string {
    return JSON.stringify(report, null, 2);
  }
}
