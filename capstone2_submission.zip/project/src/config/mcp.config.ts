/**
 * Model Context Protocol (MCP) server configurations
 *
 * Required MCP Servers:
 * 1. GitHub - For PR/repo operations
 * 2. ESLint - For code linting and style analysis
 *
 * Documentation:
 * - MCP Protocol: https://modelcontextprotocol.io
 * - GitHub MCP: https://github.com/github/github-mcp-server
 * - ESLint MCP: https://eslint.org/docs/latest/use/mcp
 */
import type { McpStdioServerConfig } from '@anthropic-ai/claude-agent-sdk';

export const mcpServersConfig: Record<'github' | 'eslint', McpStdioServerConfig> = {
  /**
   * GitHub MCP Server
   * Provides tools for GitHub API operations (pull requests, file contents).
   *
   * GITHUB_TOKEN is optional: public repositories work without it, but a token
   * gives higher rate limits and private-repo access. The server expects the
   * variable to be called GITHUB_PERSONAL_ACCESS_TOKEN, so we map our
   * GITHUB_TOKEN onto that name. The token is read from the environment only;
   * it is never hard-coded.
   */
  github: {
    type: 'stdio',
    command: 'npx',
    args: ['-y', '@modelcontextprotocol/server-github'],
    env: { GITHUB_PERSONAL_ACCESS_TOKEN: process.env.GITHUB_TOKEN || '' }
  },

  /**
   * ESLint MCP Server
   * Provides tools for linting and code quality analysis. No authentication.
   */
  eslint: {
    type: 'stdio',
    command: 'npx',
    args: ['-y', '@eslint/mcp@latest'],
    env: {}
  }
};

/**
 * MCP tools are exposed to the agent as `mcp__<server>__<tool>`.
 * Only read-oriented tools are listed: the reviewer never writes to GitHub.
 */
export const GITHUB_MCP_TOOLS = {
  getPullRequest: 'mcp__github__get_pull_request',
  getPullRequestFiles: 'mcp__github__get_pull_request_files',
  getFileContents: 'mcp__github__get_file_contents'
} as const;

export const ESLINT_MCP_TOOLS = {
  lintFiles: 'mcp__eslint__lint-files'
} as const;

/** Every MCP tool the review session may call, derived from the servers above. */
export const MCP_ALLOWED_TOOLS: string[] = [
  ...Object.values(GITHUB_MCP_TOOLS),
  ...Object.values(ESLINT_MCP_TOOLS)
];
