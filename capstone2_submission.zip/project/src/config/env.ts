/**
 * Startup validation for command-line arguments and environment variables.
 *
 * Each function is pure (takes argv/env, returns a result) so it can be unit
 * tested; src/main.ts turns failures into friendly messages and an exit code.
 * Secrets are only ever read from process.env - nothing is hard-coded.
 */

export interface CliArgs {
  owner: string;
  repo: string;
  prNumber: number;
}

export type Result<T> = { ok: true; value: T } | { ok: false; errors: string[] };

export const USAGE = 'Usage: npm run dev -- <owner> <repo> <pr-number>\n' +
  '  e.g. npm run dev -- udacity cd14715-simple-todo-app 1';

/** Validate `<owner> <repo> <pr-number>` (the values after `node script`). */
export function parseCliArgs(args: string[]): Result<CliArgs> {
  const [owner, repo, prStr] = args;
  if (!owner || !repo || !prStr) {
    return { ok: false, errors: ['Missing arguments: owner, repo and PR number are all required.', USAGE] };
  }
  // parseInt plus a digits-only check, so "12abc", "1.5" and "-3" are all rejected.
  const prNumber = parseInt(prStr, 10);
  if (!/^\d+$/.test(prStr.trim()) || Number.isNaN(prNumber) || prNumber <= 0) {
    return { ok: false, errors: [`PR number must be a positive integer, got "${prStr}".`, USAGE] };
  }
  return { ok: true, value: { owner, repo, prNumber } };
}

export type AuthMethod = 'anthropic' | 'bedrock';

/** Either ANTHROPIC_API_KEY, or AWS credentials + region for Bedrock. */
export function validateAuth(env: NodeJS.ProcessEnv): Result<AuthMethod> {
  if (env.ANTHROPIC_API_KEY) {
    return { ok: true, value: 'anthropic' };
  }
  const hasAwsKeys = Boolean(env.AWS_ACCESS_KEY_ID && env.AWS_SECRET_ACCESS_KEY);
  if (hasAwsKeys && env.AWS_REGION) {
    return { ok: true, value: 'bedrock' };
  }
  if (hasAwsKeys) {
    return { ok: false, errors: ['AWS credentials found but AWS_REGION is not set (e.g. AWS_REGION=us-east-1).'] };
  }
  return {
    ok: false,
    errors: [
      'Authentication required. Set ONE of:',
      '  - ANTHROPIC_API_KEY (already set in the Vocareum workspace), or',
      '  - AWS_ACCESS_KEY_ID + AWS_SECRET_ACCESS_KEY + AWS_REGION (AWS Bedrock)'
    ]
  };
}

/** ANTHROPIC_MODEL is required for both auth methods. */
export function validateModel(env: NodeJS.ProcessEnv): Result<string> {
  const model = env.ANTHROPIC_MODEL?.trim();
  if (!model) {
    return {
      ok: false,
      errors: [
        'ANTHROPIC_MODEL is not set. Add it to .env, for example:',
        '  - Anthropic API: ANTHROPIC_MODEL=claude-sonnet-4-5-20250929',
        '  - AWS Bedrock:   ANTHROPIC_MODEL=us.anthropic.claude-sonnet-4-5-20250929-v1:0'
      ]
    };
  }
  return { ok: true, value: model };
}

/** PROJECT_ROOT must point at the folder holding .claude/skills/. Falls back to cwd. */
export function resolveProjectRoot(env: NodeJS.ProcessEnv, cwd: string): string {
  return env.PROJECT_ROOT?.trim() || cwd;
}
