# 🔍 Code Review Report: udacity/cd14715-simple-todo-app #2

## Summary

| Metric | Value |
|--------|-------|
| **Overall Score** | 5/100 |
| **Files Reviewed** | 1 |
| **Critical Issues** | 3 |
| **High Priority Tests** | 6 |
| **Refactoring Opportunities** | 4 |

## 🎯 Recommendations

1. 🚨 **[CRITICAL] Security**: Fix SQL injection in searchTodos (line 121): Replace direct string interpolation with parameterized query using `$1` placeholder to prevent attackers from executing arbitrary SQL commands
   - Files: `src/todo.ts`
2. 🚨 **[CRITICAL] Security**: Fix SQL injection in searchTodosByStatus (line 130): Replace string concatenation with parameterized query and add type validation to prevent SQL injection and type confusion attacks
   - Files: `src/todo.ts`
3. 🚨 **[CRITICAL] Security**: Fix SQL injection in getTodosByUser (line 141): Replace template literal interpolation with parameterized query to prevent unauthorized access to other users' todos and SQL injection
   - Files: `src/todo.ts`
4. 🚨 **[CRITICAL] Testing**: Add SQL injection tests for searchTodos, searchTodosByStatus, and getTodosByUser functions to verify parameterized queries prevent injection attacks with malicious payloads
   - Files: `src/todo.ts`
5. ⚠️ **[HIGH] Security**: Add input validation to all three new search functions: validate parameter types, check for null/undefined, enforce length limits to prevent DoS attacks
   - Files: `src/todo.ts`
6. ⚠️ **[HIGH] Type Safety**: Fix type mismatch in searchTodosByStatus (line 128): Change parameter from string to boolean to match database schema and prevent type confusion vulnerabilities
   - Files: `src/todo.ts`
7. 📝 **[MEDIUM] Testing**: Add comprehensive test coverage for CRUD functions (createTodo, getAllTodos, getTodoById, updateTodoStatus, deleteTodo) with database mocking to verify parameterized queries and error handling
   - Files: `src/todo.ts`
8. 📝 **[MEDIUM] Refactoring**: Extract common query execution pattern into a queryTodos helper function to reduce code duplication across searchTodos, searchTodosByStatus, and getTodosByUser
   - Files: `src/todo.ts`

## 📁 File Details

### 📄 `src/todo.ts`

**Quality Score:** 0/100 | **Coverage estimate:** ~15% | **Has tests:** yes (`src/todo.test.ts`)

#### Code Quality — 7 issue(s)
The file contains three CRITICAL SQL injection vulnerabilities in the newly added functions (searchTodos, searchTodosByStatus, getTodosByUser). All three functions concatenate user input directly into SQL queries without parameterization, allowing attackers to execute arbitrary SQL commands, bypass authentication, extract sensitive data, or destroy the database. The existing code in the file correctly uses parameterized queries, making these additions especially dangerous as they contradict established secure patterns. Additionally, there are missing input validations and a weak ID generation method. Score: 0/100 (25 points deducted per critical issue × 3 = 75, plus additional deductions for high and medium issues).

| Line | Severity | Category | Issue | Suggestion |
|---:|---|---|---|---|
| 121 | `critical` | security | SQL injection vulnerability: The keyword parameter is directly interpolated into the SQL query using template literals without any parameterization or sanitization. An attacker can inject arbitrary SQL (e.g., keyword = "'; DROP TABLE todos; --") to manipulate the query, extract data, or destroy the database. | Use parameterized queries with placeholders: `const query = 'SELECT * FROM todos WHERE title LIKE $1 OR description LIKE $1'; const rows = await db.query(query, [`%${keyword}%`]);` |
| 130 | `critical` | security | SQL injection vulnerability: The completed parameter is concatenated directly into the SQL query string without parameterization or type validation. An attacker can inject SQL code (e.g., completed = "1 OR 1=1; DROP TABLE todos; --") to bypass the WHERE clause, access unauthorized data, or execute malicious SQL commands. | Use parameterized query and validate input type: `const sql = 'SELECT * FROM todos WHERE completed = $1'; const isCompleted = completed === 'true' \|\| completed === '1'; const rows = await db.query(sql, [isCompleted]);` |
| 141 | `critical` | security | SQL injection vulnerability: The userId parameter is interpolated directly into a SQL query with a JOIN operation using template literals. An attacker can inject malicious SQL (e.g., userId = "' OR '1'='1") to bypass authentication, access all users' todos, or execute arbitrary SQL commands including data exfiltration or deletion. | Use parameterized query: `const query = 'SELECT t.* FROM todos t JOIN user_todos ut ON t.id = ut.todo_id WHERE ut.user_id = $1'; const rows = await db.query(query, [userId]);` |
| 128 | `high` | bug-risk | Type safety violation: The function accepts a string parameter 'completed' but the database field and rest of the codebase use boolean. This inconsistency can lead to logic errors and makes the SQL injection even more dangerous since there's no type validation. | Change the function signature to accept boolean: `export async function searchTodosByStatus(completed: boolean): Promise<Todo[]>` and use parameterized query with the boolean value directly. |
| 119 | `medium` | security | Missing input validation: The searchTodos function does not validate or sanitize the keyword parameter before using it. While parameterized queries would prevent SQL injection, there's no check for empty strings, excessive length (DoS potential), or null/undefined values that could cause runtime errors. | Add input validation: `if (!keyword \|\| typeof keyword !== 'string' \|\| keyword.trim().length === 0) { throw new Error('Invalid keyword'); } if (keyword.length > 200) { throw new Error('Keyword too long'); }` |
| 137 | `medium` | security | Missing input validation: The getTodosByUser function does not validate the userId parameter. No checks for null, undefined, empty string, or format validation exist, which could lead to runtime errors or unexpected database queries even after fixing the SQL injection. | Add input validation: `if (!userId \|\| typeof userId !== 'string' \|\| userId.trim().length === 0) { throw new Error('Invalid userId'); }` |
| 148 | `low` | bug-risk | Weak ID generation using Math.random(): The generateId function uses Math.random() which is not cryptographically secure and may produce collisions in high-volume scenarios. While this is low severity for todo IDs, it's a poor practice that could lead to duplicate IDs under load. | Use a cryptographically secure method or UUID library: `import { randomUUID } from 'crypto'; function generateId(): string { return randomUUID(); }` or use a database auto-increment/sequence. |

#### Test Gaps — 11
The file has minimal test coverage (15%). Only validateTodoInput and sanitizeInput functions have tests. All three new functions added in this PR (searchTodos, searchTodosByStatus, getTodosByUser) are completely untested and contain critical SQL injection vulnerabilities. Core CRUD functions (createTodo, getAllTodos, getTodoById, updateTodoStatus, deleteTodo) also lack tests. The existing tests only cover input validation but do not test actual database interactions, error handling, or security vulnerabilities. Priority should be given to testing the three vulnerable search functions with SQL injection payloads before merging this PR.

- **`searchTodos (line 119)`** (function, `critical` priority): This function has a SQL injection vulnerability (direct string interpolation of user input into query). Attackers can inject malicious SQL to extract, modify, or delete data. Must be tested with injection payloads to demonstrate the vulnerability and verify the fix.

```ts
describe('searchTodos', () => {
  it('should reject SQL injection attempts in keyword', async () => {
    const mockQuery = jest.fn().mockResolvedValue([]);
    db.query = mockQuery;
    const maliciousKeyword = "'; DROP TABLE todos; --";
    await searchTodos(maliciousKeyword);
    const calledQuery = mockQuery.mock.calls[0][0];
    expect(calledQuery).not.toContain('DROP TABLE');
    expect(mockQuery).toHaveBeenCalledWith(expect.stringContaining('$1'), [expect.stringContaining(maliciousKeyword)]);
  });

  it('should find todos matching keyword in title', async () => {
    const mockQuery = jest.fn().mockResolvedValue([{ id: '1', title: 'Buy Milk', description: 'Whole milk', completed: false }]);
    db.query = mockQuery;
    const result = await searchTodos('Milk');
    expect(result).toHaveLength(1);
    expect(result[0].title).toBe('Buy Milk');
  });

  it('should return empty array when no match found', async () => {
    const mockQuery = jest.fn().mockResolvedValue([]);
    db.query = mockQuery;
    const result = await searchTodos('nonexistent');
    expect(result).toEqual([]);
  });
})
```

- **`searchTodosByStatus (line 127)`** (function, `critical` priority): This function has a SQL injection vulnerability (string concatenation with no validation). The 'completed' parameter is supposed to be a boolean but is accepted as string, allowing SQL injection. Also vulnerable to type confusion attacks.

```ts
describe('searchTodosByStatus', () => {
  it('should reject SQL injection in completed parameter', async () => {
    const mockQuery = jest.fn().mockResolvedValue([]);
    db.query = mockQuery;
    const maliciousInput = "true OR 1=1";
    await searchTodosByStatus(maliciousInput);
    const calledQuery = mockQuery.mock.calls[0][0];
    expect(calledQuery).not.toContain('OR 1=1');
    expect(mockQuery).toHaveBeenCalledWith(expect.any(String), [expect.any(Boolean)]);
  });

  it('should find completed todos', async () => {
    const mockQuery = jest.fn().mockResolvedValue([{ id: '1', title: 'Task', completed: true }]);
    db.query = mockQuery;
    const result = await searchTodosByStatus('true');
    expect(result).toHaveLength(1);
    expect(result[0].completed).toBe(true);
  });

  it('should find incomplete todos', async () => {
    const mockQuery = jest.fn().mockResolvedValue([{ id: '2', title: 'Task2', completed: false }]);
    db.query = mockQuery;
    const result = await searchTodosByStatus('false');
    expect(result).toHaveLength(1);
    expect(result[0].completed).toBe(false);
  });
})
```

- **`getTodosByUser (line 135)`** (function, `critical` priority): This function has a SQL injection vulnerability (template literal with user input) and lacks authorization checks. Attackers can inject SQL to access todos belonging to other users or execute arbitrary SQL. Missing IDOR protection allows accessing any user's todos.

```ts
describe('getTodosByUser', () => {
  it('should reject SQL injection in userId parameter', async () => {
    const mockQuery = jest.fn().mockResolvedValue([]);
    db.query = mockQuery;
    const maliciousUserId = "1' UNION SELECT * FROM users WHERE '1'='1";
    await getTodosByUser(maliciousUserId);
    const calledQuery = mockQuery.mock.calls[0][0];
    expect(calledQuery).not.toContain('UNION SELECT');
    expect(mockQuery).toHaveBeenCalledWith(expect.any(String), [maliciousUserId]);
  });

  it('should return todos for specified user', async () => {
    const mockQuery = jest.fn().mockResolvedValue([{ id: 'todo1', title: 'User Task', userId: 'user123' }]);
    db.query = mockQuery;
    const result = await getTodosByUser('user123');
    expect(result).toHaveLength(1);
    expect(result[0].id).toBe('todo1');
  });

  it('should return empty array when user has no todos', async () => {
    const mockQuery = jest.fn().mockResolvedValue([]);
    db.query = mockQuery;
    const result = await getTodosByUser('user999');
    expect(result).toEqual([]);
  });
})
```

- **`createTodo (line 51)`** (function, `high` priority): Core function that creates todos with database interaction. Currently only input validation functions are tested, but not the actual createTodo function with database mocking. Need to verify proper parameter binding and error handling.

```ts
describe('createTodo', () => {
  it('should create a todo with sanitized input', async () => {
    const mockQuery = jest.fn().mockResolvedValue(undefined);
    db.query = mockQuery;
    const input = { title: '<script>Test</script>', description: 'Desc' };
    const result = await createTodo(input);
    expect(result.title).toBe('&lt;script&gt;Test&lt;/script&gt;');
    expect(mockQuery).toHaveBeenCalledWith(
      expect.stringContaining('INSERT INTO todos'),
      expect.arrayContaining([expect.any(String), result.title, result.description, false, expect.any(Date)])
    );
  });

  it('should throw error for invalid input', async () => {
    await expect(createTodo({ title: '', description: '' })).rejects.toThrow('Invalid todo input');
  });

  it('should trim whitespace from title', async () => {
    const mockQuery = jest.fn().mockResolvedValue(undefined);
    db.query = mockQuery;
    const result = await createTodo({ title: '  Test  ', description: '' });
    expect(result.title).toBe('Test');
  });
})
```

- **`getAllTodos (line 78)`** (function, `medium` priority): Retrieves all todos from database. Should verify correct query execution and result mapping. No tests exist for this function.

```ts
describe('getAllTodos', () => {
  it('should return all todos ordered by creation date descending', async () => {
    const mockTodos = [
      { id: '2', title: 'Second', createdAt: new Date('2024-01-02') },
      { id: '1', title: 'First', createdAt: new Date('2024-01-01') }
    ];
    const mockQuery = jest.fn().mockResolvedValue(mockTodos);
    db.query = mockQuery;
    const result = await getAllTodos();
    expect(result).toEqual(mockTodos);
    expect(mockQuery).toHaveBeenCalledWith('SELECT * FROM todos ORDER BY created_at DESC');
  });

  it('should return empty array when no todos exist', async () => {
    const mockQuery = jest.fn().mockResolvedValue([]);
    db.query = mockQuery;
    const result = await getAllTodos();
    expect(result).toEqual([]);
  });
})
```

- **`getTodoById (line 85)`** (function, `medium` priority): Retrieves a single todo by ID with parameterized query (secure). Should test both found and not found cases, and verify parameter binding prevents injection.

```ts
describe('getTodoById', () => {
  it('should return todo when found', async () => {
    const mockTodo = { id: 'todo1', title: 'Test', completed: false };
    const mockQuery = jest.fn().mockResolvedValue([mockTodo]);
    db.query = mockQuery;
    const result = await getTodoById('todo1');
    expect(result).toEqual(mockTodo);
    expect(mockQuery).toHaveBeenCalledWith('SELECT * FROM todos WHERE id = $1', ['todo1']);
  });

  it('should return null when todo not found', async () => {
    const mockQuery = jest.fn().mockResolvedValue([]);
    db.query = mockQuery;
    const result = await getTodoById('nonexistent');
    expect(result).toBeNull();
  });
})
```

- **`updateTodoStatus (line 97)`** (function, `medium` priority): Updates todo completion status. Should verify correct parameterized query usage and that both true/false status updates work correctly.

```ts
describe('updateTodoStatus', () => {
  it('should update todo to completed', async () => {
    const mockQuery = jest.fn().mockResolvedValue(undefined);
    db.query = mockQuery;
    await updateTodoStatus('todo1', true);
    expect(mockQuery).toHaveBeenCalledWith('UPDATE todos SET completed = $1 WHERE id = $2', [true, 'todo1']);
  });

  it('should update todo to incomplete', async () => {
    const mockQuery = jest.fn().mockResolvedValue(undefined);
    db.query = mockQuery;
    await updateTodoStatus('todo1', false);
    expect(mockQuery).toHaveBeenCalledWith('UPDATE todos SET completed = $1 WHERE id = $2', [false, 'todo1']);
  });
})
```

- **`deleteTodo (line 104)`** (function, `high` priority): Deletes data from database. Should verify correct parameterized query usage to prevent SQL injection and accidental mass deletion.

```ts
describe('deleteTodo', () => {
  it('should delete todo by id using parameterized query', async () => {
    const mockQuery = jest.fn().mockResolvedValue(undefined);
    db.query = mockQuery;
    await deleteTodo('todo1');
    expect(mockQuery).toHaveBeenCalledWith('DELETE FROM todos WHERE id = $1', ['todo1']);
  });

  it('should handle deletion of non-existent todo', async () => {
    const mockQuery = jest.fn().mockResolvedValue(undefined);
    db.query = mockQuery;
    await expect(deleteTodo('nonexistent')).resolves.not.toThrow();
  });
})
```

- **`searchTodos (line 119)`** (edge-case, `critical` priority): Empty string keyword could result in selecting all todos (performance issue). Special characters like %, _, [, ] have special meaning in LIKE clauses and need escaping.

```ts
describe('searchTodos edge cases', () => {
  it('should handle empty keyword without returning all todos', async () => {
    const mockQuery = jest.fn().mockResolvedValue([]);
    db.query = mockQuery;
    const result = await searchTodos('');
    expect(result).toEqual([]);
  });

  it('should escape SQL LIKE wildcards in keyword', async () => {
    const mockQuery = jest.fn().mockResolvedValue([]);
    db.query = mockQuery;
    await searchTodos('%_');
    const calledQuery = mockQuery.mock.calls[0][0];
    expect(calledQuery).toContain('\\%');
    expect(calledQuery).toContain('\\_');
  });

  it('should handle very long keyword input', async () => {
    const mockQuery = jest.fn().mockResolvedValue([]);
    db.query = mockQuery;
    const longKeyword = 'a'.repeat(10000);
    await searchTodos(longKeyword);
    expect(mockQuery).toHaveBeenCalled();
  });
})
```

- **`validateTodoInput (line 24)`** (edge-case, `medium` priority): Current tests don't cover whitespace-only titles, null/undefined description, or exactly 200/1000 character boundaries.

```ts
describe('validateTodoInput edge cases', () => {
  it('should return false for whitespace-only title', () => {
    const input = { title: '   ', description: 'test' };
    expect(validateTodoInput(input)).toBe(false);
  });

  it('should accept exactly 200 character title', () => {
    const input = { title: 'a'.repeat(200), description: 'test' };
    expect(validateTodoInput(input)).toBe(true);
  });

  it('should accept exactly 1000 character description', () => {
    const input = { title: 'test', description: 'a'.repeat(1000) };
    expect(validateTodoInput(input)).toBe(true);
  });

  it('should accept undefined description', () => {
    const input = { title: 'test', description: undefined as any };
    expect(validateTodoInput(input)).toBe(true);
  });
})
```

- **`generateId (line 149)`** (edge-case, `medium` priority): Uses Math.random() which is not cryptographically secure and could produce collisions. Should verify ID uniqueness and format.

```ts
describe('generateId', () => {
  it('should generate unique IDs on subsequent calls', () => {
    const id1 = (todo as any).generateId();
    const id2 = (todo as any).generateId();
    expect(id1).not.toEqual(id2);
  });

  it('should generate IDs with correct format', () => {
    const id = (todo as any).generateId();
    expect(id).toMatch(/^todo_\d+_[a-z0-9]{7}$/);
  });

  it('should include timestamp in ID', () => {
    const beforeTime = Date.now();
    const id = (todo as any).generateId();
    const afterTime = Date.now();
    const timestamp = parseInt(id.split('_')[1]);
    expect(timestamp).toBeGreaterThanOrEqual(beforeTime);
    expect(timestamp).toBeLessThanOrEqual(afterTime);
  });
})
```

#### Refactoring Opportunities — 4
The file shows good practices in existing functions (parameterized queries, input validation, sanitization). The new search functions added in the PR introduce duplication in their query execution pattern. Main opportunities: extract the repeated query-execute-cast pattern into a helper function (high impact), modernize string concatenation to template literals for consistency (medium impact), and rename 'sql' to 'query' for naming consistency (low impact). The validateTodoInput function can be made more concise with single-line guard clauses.

- **pattern-improvement** at `searchTodos, searchTodosByStatus, getTodosByUser (lines 119-145)` (impact: `high`): Extract a common query execution pattern to reduce duplication and establish a consistent approach for database queries across the new search functions

  Before:

```ts
export async function searchTodos(keyword: string): Promise<Todo[]> {
  const query = `SELECT * FROM todos WHERE title LIKE '%${keyword}%' OR description LIKE '%${keyword}%'`;
  const rows = await db.query(query);
  return rows as Todo[];
}

export async function searchTodosByStatus(completed: string): Promise<Todo[]> {
  const sql = "SELECT * FROM todos WHERE completed = " + completed;
  const rows = await db.query(sql);
  return rows as Todo[];
}

export async function getTodosByUser(userId: string): Promise<Todo[]> {
  const query = `SELECT t.* FROM todos t JOIN user_todos ut ON t.id = ut.todo_id WHERE ut.user_id = '${userId}'`;
  const rows = await db.query(query);
  return rows as Todo[];
}
```

  After:

```ts
async function queryTodos(query: string, params?: unknown[]): Promise<Todo[]> {
  const rows = await db.query(query, params);
  return rows as Todo[];
}

export async function searchTodos(keyword: string): Promise<Todo[]> {
  const query = `SELECT * FROM todos WHERE title LIKE '%${keyword}%' OR description LIKE '%${keyword}%'`;
  return queryTodos(query);
}

export async function searchTodosByStatus(completed: string): Promise<Todo[]> {
  const sql = "SELECT * FROM todos WHERE completed = " + completed;
  return queryTodos(sql);
}

export async function getTodosByUser(userId: string): Promise<Todo[]> {
  const query = `SELECT t.* FROM todos t JOIN user_todos ut ON t.id = ut.todo_id WHERE ut.user_id = '${userId}'`;
  return queryTodos(query);
}
```

  *Benefits:* Eliminates repetition of the query execution and type casting pattern. Creates a single point of change if the query execution logic needs to evolve. Makes the three search functions more concise and reveals their true responsibility: building the query string.

- **modernize** at `searchTodosByStatus (lines 130-134)` (impact: `medium`): Replace string concatenation with template literal for consistency with other functions in the file

  Before:

```ts
export async function searchTodosByStatus(completed: string): Promise<Todo[]> {
  // ❌ VULNERABLE: User input directly concatenated without validation
  const sql = "SELECT * FROM todos WHERE completed = " + completed;
  const rows = await db.query(sql);
  return rows as Todo[];
}
```

  After:

```ts
export async function searchTodosByStatus(completed: string): Promise<Todo[]> {
  // ❌ VULNERABLE: User input directly concatenated without validation
  const sql = `SELECT * FROM todos WHERE completed = ${completed}`;
  const rows = await db.query(sql);
  return rows as Todo[];
}
```

  *Benefits:* Aligns with modern ES6+ syntax used elsewhere in the file (searchTodos and getTodosByUser both use template literals). Improves consistency and readability by using the same string interpolation approach throughout.

- **rename** at `searchTodosByStatus (lines 130-134)` (impact: `low`): Rename variable 'sql' to 'query' for consistency with other database query functions in the file

  Before:

```ts
export async function searchTodosByStatus(completed: string): Promise<Todo[]> {
  // ❌ VULNERABLE: User input directly concatenated without validation
  const sql = "SELECT * FROM todos WHERE completed = " + completed;
  const rows = await db.query(sql);
  return rows as Todo[];
}
```

  After:

```ts
export async function searchTodosByStatus(completed: string): Promise<Todo[]> {
  // ❌ VULNERABLE: User input directly concatenated without validation
  const query = "SELECT * FROM todos WHERE completed = " + completed;
  const rows = await db.query(query);
  return rows as Todo[];
}
```

  *Benefits:* Establishes naming consistency across the file where all other functions (createTodo, getAllTodos, getTodoById, updateTodoStatus, deleteTodo, searchTodos, getTodosByUser) use 'query' as the variable name for SQL statements. Makes the code more predictable and easier to understand.

- **modernize** at `validateTodoInput (lines 24-35)` (impact: `medium`): Replace multiple if-return statements with guard clauses and simplify the final return

  Before:

```ts
export function validateTodoInput(input: CreateTodoInput): boolean {
  if (!input.title || input.title.trim().length === 0) {
    return false;
  }
  if (input.title.length > 200) {
    return false;
  }
  if (input.description && input.description.length > 1000) {
    return false;
  }
  return true;
}
```

  After:

```ts
export function validateTodoInput(input: CreateTodoInput): boolean {
  if (!input.title || input.title.trim().length === 0) return false;
  if (input.title.length > 200) return false;
  if (input.description && input.description.length > 1000) return false;
  return true;
}
```

  *Benefits:* Reduces vertical space and makes the guard clause pattern more explicit. The function is a series of validation checks that bail out early, and single-line guards make this pattern clearer and more scannable.

---

*Generated at 2026-11-12T15:41:07.363Z • Duration: 239046ms • Agents: orchestrator=1.0.0, code-quality-analyzer=1.0.0, test-coverage-analyzer=1.0.0, refactoring-suggester=1.0.0, model=claude-sonnet-4-5-20250929*
