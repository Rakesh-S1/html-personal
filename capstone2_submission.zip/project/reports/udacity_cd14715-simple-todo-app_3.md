# 🔍 Code Review Report: udacity/cd14715-simple-todo-app #3

## Summary

| Metric | Value |
|--------|-------|
| **Overall Score** | 11/100 |
| **Files Reviewed** | 1 |
| **Critical Issues** | 4 |
| **High Priority Tests** | 13 |
| **Refactoring Opportunities** | 6 |

## 🎯 Recommendations

1. 🚨 **[CRITICAL] Security - PCI Compliance**: Replace raw card data handling with PCI-compliant tokenization. The PaymentDetails interface exposes CVV and full card numbers which violates PCI-DSS requirements. Implement Stripe, Adyen, or similar payment provider that handles tokenization client-side.
   - Files: `src/premium.ts`
2. 🚨 **[CRITICAL] Security - Payment Validation**: Remove client-supplied payment.amount from PaymentDetails interface (line 33). All pricing must be calculated server-side only to prevent manipulation. Never trust client input for financial calculations.
   - Files: `src/premium.ts`
3. 🚨 **[CRITICAL] Testing - Payment Processing**: Add comprehensive test suite for all payment and subscription functions. Zero test coverage on critical business logic including processPremiumPayment, validatePaymentDetails, calculateSubscriptionPrice, chargeCard, upgradeUserSubscription, hasFeatureAccess, and getUserSubscription.
   - Files: `src/premium.ts`
4. 🚨 **[CRITICAL] Testing - Authorization Logic**: Test hasFeatureAccess authorization logic (line 148) with edge cases including expired subscriptions, malformed JSON, missing features, and boundary conditions. Authorization bugs could grant unauthorized access or deny paying customers.
   - Files: `src/premium.ts`
5. ⚠️ **[HIGH] Security - Input Validation**: Add input validation for userId and feature parameters in all exported functions (lines 149, 140). Validate type, length (max 100 chars), and format (alphanumeric + hyphens/underscores) to prevent IDOR attacks and DoS via long strings.
   - Files: `src/premium.ts`
6. ⚠️ **[HIGH] Security - Card Validation**: Implement Luhn algorithm for card number validation (line 62). Current validation only checks length, allowing any 16-digit string. Also support multiple card lengths (Amex: 15, Visa: 16, others: 13-19).
   - Files: `src/premium.ts`
7. ⚠️ **[HIGH] Bug Risk - Error Handling**: Add try-catch blocks around JSON.parse calls (lines 165, 188) to prevent application crashes from malformed database data. Return safe defaults (false/null) instead of throwing unhandled exceptions.
   - Files: `src/premium.ts`
8. ⚠️ **[HIGH] Bug Risk - Financial Calculations**: Replace floating-point arithmetic with integer-based money calculations (line 94). Use cents for all calculations to avoid rounding errors: PRICING = {premium: 999, enterprise: 4999}, then convert to dollars only for display.
   - Files: `src/premium.ts`
9. ⚠️ **[HIGH] Bug Risk - Transaction Integrity**: Wrap processPremiumPayment in database transaction (line 52) to prevent race condition where chargeCard succeeds but upgradeUserSubscription fails, leaving user charged without subscription. Use BEGIN/COMMIT/ROLLBACK.
   - Files: `src/premium.ts`
10. 📝 **[MEDIUM] Bug Risk - Date Handling**: Fix credit card expiry validation (line 80-81): use end-of-month instead of beginning, add proper century logic for Y2.1K compliance, and always specify radix in parseInt. Current logic incorrectly rejects valid cards.
   - Files: `src/premium.ts`
11. 📝 **[MEDIUM] Refactoring - Type Safety**: Extract TIER_FEATURES lookup table with const assertion (line 133) and create SubscriptionTier/PaidTier type aliases for better type safety and maintainability.
   - Files: `src/premium.ts`
12. 📝 **[MEDIUM] Refactoring - Code Organization**: Extract validation functions (isExpiryDateValid, isSubscriptionActive) and move pricing constants (PRICING, TAX_RATE, PROCESSING_FEE) to module level for reusability and testability.
   - Files: `src/premium.ts`

## 📁 File Details

### 📄 `src/premium.ts`

**Quality Score:** 15/100 | **Coverage estimate:** ~0% | **Has tests:** no

#### Code Quality — 24 issue(s)
This file has CRITICAL security violations that make it unsuitable for production: (1) CVV and full card numbers are stored in interfaces, passed to functions, and risk exposure through logging - this violates PCI-DSS and could result in massive fines and data breach; (2) client-supplied payment amounts are trusted; (3) no input validation on user IDs enabling IDOR attacks; (4) floating-point money arithmetic causing financial errors; (5) missing error handling on JSON.parse causing crashes; (6) weak card validation without Luhn algorithm; (7) date handling bugs causing incorrect expiry checks; (8) race conditions between charging and upgrading users; (9) inconsistent error handling. The code must not be merged until payment handling is replaced with a PCI-compliant tokenization provider (Stripe/Adyen), all sensitive data handling is removed, input validation is added, money calculations use integers, and proper transaction boundaries are implemented. Score: 15/100 (4 critical × 25 + 3 high × 12 + 7 medium × 5 - capped at 0, but showing 15 issues found).

| Line | Severity | Category | Issue | Suggestion |
|---:|---|---|---|---|
| 17 | `critical` | security | PaymentDetails interface includes CVV field. PCI-DSS explicitly forbids storing, logging, or retaining CVV/CVC after authorization. This interface allows CVV to be passed to multiple functions and potentially stored or logged. | Remove CVV from the interface entirely. Use a payment provider token (Stripe, Adyen) instead of handling raw card data. If you must process cards, CVV should only exist in a single function scope and never stored: `type PaymentToken = { token: string; amount: number; }` and use a payment gateway SDK. |
| 17 | `critical` | security | Full card number (PAN) stored in PaymentDetails interface as plain string. This creates risk of exposure through logging, error messages, or accidental storage. PCI compliance requires card data to be tokenized. | Replace raw card handling with tokenization. Use payment provider tokens: `interface PaymentDetails { paymentToken: string; amount: number; }`. The card data should be tokenized client-side using Stripe.js or similar before reaching your server. |
| 114 | `critical` | security | The entire PaymentDetails object (containing cardNumber and CVV) is passed to chargeCard function. If this function or any error handling logs the payment object, sensitive card data will be exposed. | Never pass full payment objects. Extract only non-sensitive data: `async function chargeCard(lastFour: string, amount: number): Promise<boolean>`. Calculate lastFour before calling: `const lastFour = payment.cardNumber.slice(-4); const success = await chargeCard(lastFour, amount);` |
| 123 | `critical` | security | Error logging with `console.error('Payment failed:', error)` could expose sensitive payment data if the error object contains payment details from the calling context or if error stack traces reveal card data. | Log only safe, non-sensitive error information: `console.error('Payment failed:', { code: error.code, message: error.message, lastFour });`. Never log full error objects in payment flows. |
| 33 | `high` | security | Client-supplied payment.amount is trusted for validation. An attacker could send `payment.amount = 999999` while actually being charged the correct amount, or manipulate business logic. Payment amounts must be calculated server-side only. | Remove amount from PaymentDetails interface and never trust client input for pricing: `export interface PaymentDetails { cardNumber: string; expiryDate: string; cvv: string; }` Then in processPremiumPayment: `const amount = calculateSubscriptionPrice(tier);` and pass only the server-calculated amount to chargeCard. |
| 45 | `high` | bug-risk | Inconsistent error handling: validation failures throw errors (line 34, 41) but payment failures return false (line 47). This creates two different error-handling paths for callers and can lead to unhandled errors or incorrect business logic. | Use consistent error handling. Either throw for all errors: `if (!paymentSuccessful) { throw new Error('Payment processing failed'); }` or return result objects: `return { success: false, error: 'Payment processing failed' };` Choose one pattern and apply throughout. |
| 62 | `high` | security | Card validation only checks length (16 digits) without Luhn algorithm. This accepts invalid card numbers and provides weak validation. Attackers could bypass with any 16-digit string. | Implement Luhn algorithm validation: `function luhnCheck(num: string): boolean { let sum = 0; let isEven = false; for (let i = num.length - 1; i >= 0; i--) { let digit = parseInt(num[i], 10); if (isEven) { digit *= 2; if (digit > 9) digit -= 9; } sum += digit; isEven = !isEven; } return sum % 10 === 0; }` Then add: `if (!luhnCheck(cardNumber)) return false;` |
| 94 | `high` | bug-risk | Floating-point arithmetic used for money calculations (9.99 * 0.08). Floating-point math can introduce rounding errors: e.g., 0.1 + 0.2 = 0.30000000000000004. This can cause incorrect charges and financial discrepancies. | Use integer arithmetic (cents) for all money calculations: `const PRICING = { premium: 999, enterprise: 4999 }; // cents` then `const basePrice = PRICING[tier]; const tax = Math.round(basePrice * 0.08); const fee = Math.round(basePrice * 0.029); return (basePrice + tax + fee) / 100; // convert to dollars for display` |
| 149 | `high` | security | userId parameter is not validated before use in SQL query. While parameterized queries prevent SQL injection, there's no validation for type, format, or length. An attacker could pass empty strings, extremely long strings (DoS), or attempt IDOR attacks. | Add input validation: `if (!userId \|\| typeof userId !== 'string' \|\| userId.length > 100 \|\| !/^[a-zA-Z0-9-_]+$/.test(userId)) { throw new Error('Invalid userId'); }`. Apply this validation at the top of all exported functions. |
| 165 | `high` | bug-risk | JSON.parse(subscription.features) called without try-catch error handling. If database contains malformed JSON, the application will crash with an unhandled exception, causing service disruption. | Wrap in try-catch with safe fallback: `let features: string[]; try { features = JSON.parse(subscription.features); } catch { console.error('Invalid features JSON for user', userId); return false; }` Also validate the result is an array. |
| 188 | `high` | bug-risk | JSON.parse(row.features) called without try-catch error handling. Malformed JSON in database will crash the application. This is a critical code path for subscription verification. | Add error handling: `let features: string[]; try { features = JSON.parse(row.features); if (!Array.isArray(features)) throw new Error('Invalid format'); } catch (e) { console.error('Corrupted subscription data for user', userId); return null; }` |
| 65 | `medium` | bug-risk | Card number validation checks `length !== 16` but some valid cards (Amex) have 15 digits, others have 19. This incorrectly rejects valid payment methods and limits business functionality. | Accept valid card lengths: `if (cardNumber.length < 13 \|\| cardNumber.length > 19) { return false; }` and validate the specific length against the card type (determined by BIN/IIN prefix). |
| 80 | `medium` | bug-risk | Date expiry check creates Date with `parseInt(month) - 1` for month but doesn't set day. This defaults to day 1, meaning cards expire at the beginning of the month instead of end-of-month, incorrectly rejecting valid cards. | Set expiry to end of month: `const expiryDateObj = new Date(2000 + parseInt(year, 10), parseInt(month, 10), 0); // day 0 = last day of previous month` or `const expiryDateObj = new Date(2000 + parseInt(year, 10), parseInt(month, 10)); expiryDateObj.setMonth(expiryDateObj.getMonth() + 1); expiryDateObj.setDate(0);` |
| 81 | `medium` | bug-risk | Date calculation `2000 + parseInt(year)` assumes two-digit year format and will break after 2099 (e.g., year '00' in 2100 becomes 2000, appearing expired). This is a Y2.1K bug in credit card validation. | Use proper century logic: `const currentYear = new Date().getFullYear(); const century = Math.floor(currentYear / 100) * 100; const fullYear = century + parseInt(year, 10); const expiryDateObj = new Date(fullYear, parseInt(month, 10) - 1);` or better, accept four-digit years. |
| 81 | `medium` | bug-risk | parseInt called without radix parameter. While '10' is the default for numeric strings, this is fragile if input contains leading zeros (e.g., '08' might be interpreted differently in older environments). | Always specify radix: `const expiryDateObj = new Date(2000 + parseInt(year, 10), parseInt(month, 10) - 1);` |
| 140 | `medium` | security | No input validation on userId parameter in upgradeUserSubscription. Missing bounds checking (length, format) allows potential DoS via extremely long strings or SQL query abuse. | Add validation at function entry: `if (!userId \|\| typeof userId !== 'string' \|\| userId.length === 0 \|\| userId.length > 100) { throw new Error('Invalid userId'); }` |
| 149 | `medium` | security | No validation on feature parameter in hasFeatureAccess. An attacker could pass extremely long strings, objects, or malicious input attempting DoS or injection if the feature name is ever used in dynamic queries elsewhere. | Validate feature parameter: `if (!feature \|\| typeof feature !== 'string' \|\| feature.length > 50 \|\| !/^[a-z_]+$/.test(feature)) { throw new Error('Invalid feature name'); }` |
| 152 | `medium` | bug-risk | hasFeatureAccess checks `rows.length === 0` but rows could be undefined if db.query fails or returns unexpected data. No type safety on database query results. | Add defensive checks: `if (!rows \|\| !Array.isArray(rows) \|\| rows.length === 0) { return false; }` and define a proper type for the query result. |
| 177 | `medium` | security | getUserSubscription uses SELECT * which retrieves all columns. This violates the principle of least privilege and could expose sensitive data or internal fields not intended for the application layer. | Select only needed columns: `const query = 'SELECT user_id, tier, valid_until, features FROM subscriptions WHERE user_id = $1';` This limits exposure and improves performance. |
| 52 | `low` | bug-risk | processPremiumPayment has a race condition: if upgradeUserSubscription (line 52) fails after chargeCard succeeds (line 45), the user is charged but not upgraded. No transaction boundary or compensation logic. | Wrap in database transaction: `const client = await db.getClient(); try { await client.query('BEGIN'); await chargeCard(...); await upgradeUserSubscription(...); await client.query('COMMIT'); } catch (e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }` |
| 97 | `low` | maintainability | Magic numbers 0.08 (8% tax) and 0.029 (2.9% processing fee) are hardcoded without explanation. Tax rates vary by jurisdiction and this code assumes a single rate. | Extract to configuration with documentation: `const TAX_RATES = { US_DEFAULT: 0.08 }; // 8% - should be determined by user location` and add a comment: `// TODO: implement location-based tax calculation` |
| 117 | `low` | bug-risk | chargeCard returns false on database error but doesn't roll back any state. If called in a transaction context, the payment could be lost. No idempotency key or transaction ID. | Add transaction support and idempotency: `async function chargeCard(payment: PaymentDetails, amount: number, idempotencyKey: string): Promise<boolean>` and check for duplicate idempotencyKey before processing. |
| 133 | `low` | maintainability | Feature arrays for 'premium' and 'enterprise' tiers are duplicated with shared features. This violates DRY principle and makes it easy to miss features when updating tiers. | Define features as constants: `const COMMON_FEATURES = ['unlimited_todos', 'priority_support', 'custom_themes']; const ENTERPRISE_FEATURES = [...COMMON_FEATURES, 'api_access', 'team_collaboration']; const features = tier === 'premium' ? COMMON_FEATURES : ENTERPRISE_FEATURES;` |
| 159 | `low` | bug-risk | Date comparison `validUntil < new Date()` doesn't account for timezone differences. If server timezone differs from user timezone, subscriptions could appear expired when they're not, or vice versa. | Use UTC for all date comparisons: `const validUntil = new Date(subscription.valid_until); const now = new Date(); if (validUntil.getTime() < now.getTime()) { return false; }` or store dates as UTC timestamps. |

#### Test Gaps — 14
The file src/premium.ts has ZERO test coverage. This is a critical security and business risk as the file handles payment processing, subscription management, and feature authorization. All 3 exported functions (processPremiumPayment, hasFeatureAccess, getUserSubscription) and 4 internal functions (validatePaymentDetails, calculateSubscriptionPrice, chargeCard, upgradeUserSubscription) are completely untested. Key risks include: incorrect payment validation allowing invalid cards, pricing calculation errors causing revenue loss, payment processing failures without proper error handling, subscription upgrades granting wrong features or expiry dates, and authorization checks allowing unauthorized feature access. The code also has multiple edge cases around date handling, floating-point arithmetic, JSON parsing, and database errors that could cause runtime failures in production. Immediate comprehensive test coverage is required before this code can safely handle real payments.

- **`processPremiumPayment (line 27)`** (function, `critical` priority): Orchestrates the entire payment flow including validation, pricing calculation, charging the card, and upgrading subscriptions. A bug here could result in charging users incorrectly, granting subscriptions without payment, or data corruption.

```ts
describe('processPremiumPayment', () => {
  const mockDb = { query: jest.fn() };
  jest.mock('./database', () => ({ db: mockDb }));

  it('successfully processes a valid premium payment', async () => {
    mockDb.query.mockResolvedValueOnce([]).mockResolvedValueOnce([]);
    const payment = { cardNumber: '1234567890123456', expiryDate: '12/30', cvv: '123', amount: 11.09 };
    const result = await processPremiumPayment('user123', payment, 'premium');
    expect(result).toBe(true);
    expect(mockDb.query).toHaveBeenCalledWith(
      expect.stringContaining('INSERT INTO payments'),
      expect.arrayContaining(['3456', expect.any(Number), 'completed'])
    );
  });

  it('throws error for invalid payment details', async () => {
    const payment = { cardNumber: '123', expiryDate: '12/30', cvv: '123', amount: 11.09 };
    await expect(processPremiumPayment('user123', payment, 'premium')).rejects.toThrow('Invalid payment details');
  });

  it('throws error when payment amount is insufficient', async () => {
    const payment = { cardNumber: '1234567890123456', expiryDate: '12/30', cvv: '123', amount: 5.00 };
    await expect(processPremiumPayment('user123', payment, 'premium')).rejects.toThrow('Insufficient payment amount');
  });

  it('returns false when card charging fails', async () => {
    mockDb.query.mockRejectedValueOnce(new Error('Payment gateway error'));
    const payment = { cardNumber: '1234567890123456', expiryDate: '12/30', cvv: '123', amount: 11.09 };
    const result = await processPremiumPayment('user123', payment, 'premium');
    expect(result).toBe(false);
  });
});
```

- **`validatePaymentDetails (line 61)`** (function, `critical` priority): Validates credit card information before processing payments. Weak validation could allow invalid cards through, causing payment failures or security issues. The expiry date logic is complex and prone to off-by-one errors.

```ts
describe('validatePaymentDetails', () => {
  it('accepts valid 16-digit card with 3-digit CVV', () => {
    const payment = { cardNumber: '1234567890123456', expiryDate: '12/30', cvv: '123', amount: 10 };
    expect(validatePaymentDetails(payment)).toBe(true);
  });

  it('accepts 4-digit CVV for Amex cards', () => {
    const payment = { cardNumber: '1234567890123456', expiryDate: '12/30', cvv: '1234', amount: 10 };
    expect(validatePaymentDetails(payment)).toBe(true);
  });

  it('rejects card number with wrong length', () => {
    const payment = { cardNumber: '123456789012345', expiryDate: '12/30', cvv: '123', amount: 10 };
    expect(validatePaymentDetails(payment)).toBe(false);
  });

  it('rejects CVV with invalid length', () => {
    const payment = { cardNumber: '1234567890123456', expiryDate: '12/30', cvv: '12', amount: 10 };
    expect(validatePaymentDetails(payment)).toBe(false);
  });

  it('rejects invalid expiry date format', () => {
    const payment = { cardNumber: '1234567890123456', expiryDate: '13/30', cvv: '123', amount: 10 };
    expect(validatePaymentDetails(payment)).toBe(false);
  });

  it('rejects expired card', () => {
    const payment = { cardNumber: '1234567890123456', expiryDate: '01/20', cvv: '123', amount: 10 };
    expect(validatePaymentDetails(payment)).toBe(false);
  });
});
```

- **`calculateSubscriptionPrice (line 94)`** (function, `critical` priority): Calculates the final charge amount including tax and processing fees. Incorrect pricing could result in undercharging or overcharging customers, leading to revenue loss or customer complaints and potential legal issues.

```ts
describe('calculateSubscriptionPrice', () => {
  it('calculates correct price for premium tier', () => {
    const price = calculateSubscriptionPrice('premium');
    expect(price).toBeCloseTo(10.88, 2);
  });

  it('calculates correct price for enterprise tier', () => {
    const price = calculateSubscriptionPrice('enterprise');
    expect(price).toBeCloseTo(54.44, 2);
  });

  it('includes 8% tax in calculation', () => {
    const premiumBase = 9.99;
    const expected = premiumBase + (premiumBase * 0.08) + (premiumBase * 0.029);
    expect(calculateSubscriptionPrice('premium')).toBeCloseTo(expected, 2);
  });
});
```

- **`chargeCard (line 114)`** (function, `critical` priority): Executes the actual payment transaction and records it in the database. Failures here could result in charging customers without recording the transaction, or database errors causing lost payment records.

```ts
describe('chargeCard', () => {
  const mockDb = { query: jest.fn() };
  jest.mock('./database', () => ({ db: mockDb }));

  it('inserts payment record and returns true on success', async () => {
    mockDb.query.mockResolvedValueOnce([]);
    const payment = { cardNumber: '1234567890123456', expiryDate: '12/30', cvv: '123', amount: 10 };
    const result = await chargeCard(payment, 10.88);
    expect(result).toBe(true);
    expect(mockDb.query).toHaveBeenCalledWith(
      'INSERT INTO payments (card_last_four, amount, status) VALUES ($1, $2, $3)',
      ['3456', 10.88, 'completed']
    );
  });

  it('returns false when database insertion fails', async () => {
    mockDb.query.mockRejectedValueOnce(new Error('Database error'));
    const payment = { cardNumber: '1234567890123456', expiryDate: '12/30', cvv: '123', amount: 10 };
    const result = await chargeCard(payment, 10.88);
    expect(result).toBe(false);
  });

  it('stores only last four digits of card number', async () => {
    mockDb.query.mockResolvedValueOnce([]);
    const payment = { cardNumber: '9876543210987654', expiryDate: '12/30', cvv: '123', amount: 10 };
    await chargeCard(payment, 10.88);
    expect(mockDb.query).toHaveBeenCalledWith(
      expect.any(String),
      expect.arrayContaining(['7654', expect.any(Number), expect.any(String)])
    );
  });
});
```

- **`upgradeUserSubscription (line 131)`** (function, `critical` priority): Grants subscription access and determines which features a user receives. Bugs could grant wrong features, incorrect expiry dates, or fail to upgrade users who paid. The tier-based feature logic needs thorough testing.

```ts
describe('upgradeUserSubscription', () => {
  const mockDb = { query: jest.fn() };
  jest.mock('./database', () => ({ db: mockDb }));

  it('grants correct features for premium tier', async () => {
    mockDb.query.mockResolvedValueOnce([]);
    await upgradeUserSubscription('user123', 'premium');
    expect(mockDb.query).toHaveBeenCalledWith(
      expect.stringContaining('INSERT INTO subscriptions'),
      expect.arrayContaining([
        'user123',
        'premium',
        expect.any(Date),
        JSON.stringify(['unlimited_todos', 'priority_support', 'custom_themes'])
      ])
    );
  });

  it('grants correct features for enterprise tier', async () => {
    mockDb.query.mockResolvedValueOnce([]);
    await upgradeUserSubscription('user456', 'enterprise');
    expect(mockDb.query).toHaveBeenCalledWith(
      expect.any(String),
      expect.arrayContaining([
        'user456',
        'enterprise',
        expect.any(Date),
        JSON.stringify(['unlimited_todos', 'priority_support', 'custom_themes', 'api_access', 'team_collaboration'])
      ])
    );
  });

  it('sets subscription valid for one year', async () => {
    mockDb.query.mockResolvedValueOnce([]);
    const beforeCall = new Date();
    await upgradeUserSubscription('user123', 'premium');
    const [[, , , validUntil]] = mockDb.query.mock.calls[0];
    const oneYearLater = new Date(beforeCall);
    oneYearLater.setFullYear(oneYearLater.getFullYear() + 1);
    expect(validUntil.getFullYear()).toBe(oneYearLater.getFullYear());
  });
});
```

- **`hasFeatureAccess (line 148)`** (function, `critical` priority): Controls authorization to premium features. Incorrect logic could grant free users premium access (revenue loss) or deny paying users access (breach of contract). The expiry date check and JSON parsing are error-prone.

```ts
describe('hasFeatureAccess', () => {
  const mockDb = { query: jest.fn() };
  jest.mock('./database', () => ({ db: mockDb }));

  it('returns true when user has valid subscription with feature', async () => {
    const futureDate = new Date();
    futureDate.setFullYear(futureDate.getFullYear() + 1);
    mockDb.query.mockResolvedValueOnce([{
      features: JSON.stringify(['unlimited_todos', 'priority_support']),
      valid_until: futureDate.toISOString()
    }]);
    const result = await hasFeatureAccess('user123', 'unlimited_todos');
    expect(result).toBe(true);
  });

  it('returns false when user has no subscription', async () => {
    mockDb.query.mockResolvedValueOnce([]);
    const result = await hasFeatureAccess('user123', 'unlimited_todos');
    expect(result).toBe(false);
  });

  it('returns false when subscription is expired', async () => {
    const pastDate = new Date('2020-01-01');
    mockDb.query.mockResolvedValueOnce([{
      features: JSON.stringify(['unlimited_todos']),
      valid_until: pastDate.toISOString()
    }]);
    const result = await hasFeatureAccess('user123', 'unlimited_todos');
    expect(result).toBe(false);
  });

  it('returns false when feature is not included', async () => {
    const futureDate = new Date();
    futureDate.setFullYear(futureDate.getFullYear() + 1);
    mockDb.query.mockResolvedValueOnce([{
      features: JSON.stringify(['priority_support']),
      valid_until: futureDate.toISOString()
    }]);
    const result = await hasFeatureAccess('user123', 'api_access');
    expect(result).toBe(false);
  });
});
```

- **`getUserSubscription (line 173)`** (function, `high` priority): Retrieves and transforms subscription data from the database. Incorrect mapping between database columns and the Subscription interface could cause runtime errors or return wrong data to users.

```ts
describe('getUserSubscription', () => {
  const mockDb = { query: jest.fn() };
  jest.mock('./database', () => ({ db: mockDb }));

  it('returns subscription when user has one', async () => {
    const validUntil = new Date('2027-01-01');
    mockDb.query.mockResolvedValueOnce([{
      user_id: 'user123',
      tier: 'premium',
      valid_until: validUntil.toISOString(),
      features: JSON.stringify(['unlimited_todos', 'priority_support'])
    }]);
    const result = await getUserSubscription('user123');
    expect(result).toEqual({
      userId: 'user123',
      tier: 'premium',
      validUntil: validUntil,
      features: ['unlimited_todos', 'priority_support']
    });
  });

  it('returns null when user has no subscription', async () => {
    mockDb.query.mockResolvedValueOnce([]);
    const result = await getUserSubscription('user123');
    expect(result).toBeNull();
  });

  it('correctly parses features JSON array', async () => {
    const validUntil = new Date('2027-01-01');
    mockDb.query.mockResolvedValueOnce([{
      user_id: 'user456',
      tier: 'enterprise',
      valid_until: validUntil.toISOString(),
      features: JSON.stringify(['unlimited_todos', 'priority_support', 'custom_themes', 'api_access', 'team_collaboration'])
    }]);
    const result = await getUserSubscription('user456');
    expect(result.features).toHaveLength(5);
    expect(result.features).toContain('api_access');
  });
});
```

- **`validatePaymentDetails expiry date boundary (line 80)`** (edge-case, `critical` priority): The expiry date check compares month precision but cards typically expire at the end of the month. A card expiring '11/26' checked on November 1st, 2026 might be incorrectly rejected if the current date object includes the day.

```ts
describe('validatePaymentDetails edge cases', () => {
  it('accepts card expiring in current month', () => {
    jest.useFakeTimers();
    jest.setSystemTime(new Date('2026-11-15'));
    const payment = { cardNumber: '1234567890123456', expiryDate: '11/26', cvv: '123', amount: 10 };
    expect(validatePaymentDetails(payment)).toBe(true);
    jest.useRealTimers();
  });

  it('rejects card expiring in previous month', () => {
    jest.useFakeTimers();
    jest.setSystemTime(new Date('2026-12-01'));
    const payment = { cardNumber: '1234567890123456', expiryDate: '11/26', cvv: '123', amount: 10 };
    expect(validatePaymentDetails(payment)).toBe(false);
    jest.useRealTimers();
  });
});
```

- **`chargeCard with short card numbers (line 117)`** (edge-case, `high` priority): The function uses slice(-4) to extract the last four digits. If validatePaymentDetails has a bug and allows a card number shorter than 4 digits, slice could return the entire number, exposing more than intended.

```ts
describe('chargeCard edge cases', () => {
  const mockDb = { query: jest.fn() };
  jest.mock('./database', () => ({ db: mockDb }));

  it('handles card numbers exactly 4 digits long', async () => {
    mockDb.query.mockResolvedValueOnce([]);
    const payment = { cardNumber: '1234', expiryDate: '12/30', cvv: '123', amount: 10 };
    await chargeCard(payment, 10.88);
    expect(mockDb.query).toHaveBeenCalledWith(
      expect.any(String),
      expect.arrayContaining(['1234', expect.any(Number), expect.any(String)])
    );
  });
});
```

- **`hasFeatureAccess with malformed JSON (line 165)`** (edge-case, `high` priority): If database data is corrupted or manually edited, JSON.parse could throw an exception, causing the authorization check to crash rather than safely denying access.

```ts
describe('hasFeatureAccess edge cases', () => {
  const mockDb = { query: jest.fn() };
  jest.mock('./database', () => ({ db: mockDb }));

  it('handles malformed JSON in features field', async () => {
    const futureDate = new Date();
    futureDate.setFullYear(futureDate.getFullYear() + 1);
    mockDb.query.mockResolvedValueOnce([{
      features: 'invalid json',
      valid_until: futureDate.toISOString()
    }]);
    await expect(hasFeatureAccess('user123', 'unlimited_todos')).rejects.toThrow();
  });
});
```

- **`processPremiumPayment with exact payment amount (line 40)`** (edge-case, `medium` priority): The code checks if payment.amount < amount, which should accept exact matches. However, floating-point precision issues with the calculated price could cause unexpected rejections.

```ts
describe('processPremiumPayment edge cases', () => {
  const mockDb = { query: jest.fn() };
  jest.mock('./database', () => ({ db: mockDb }));

  it('accepts payment with exact calculated amount', async () => {
    mockDb.query.mockResolvedValueOnce([]).mockResolvedValueOnce([]);
    const exactAmount = 10.88991;
    const payment = { cardNumber: '1234567890123456', expiryDate: '12/30', cvv: '123', amount: exactAmount };
    const result = await processPremiumPayment('user123', payment, 'premium');
    expect(result).toBe(true);
  });
});
```

- **`processPremiumPayment validation failure branch (line 33)`** (branch, `critical` priority): When validatePaymentDetails returns false, an error is thrown. This branch must be tested to ensure proper error messages and that no payment or subscription changes occur.

```ts
describe('processPremiumPayment validation branches', () => {
  it('throws descriptive error when validation fails', async () => {
    const payment = { cardNumber: 'invalid', expiryDate: '12/30', cvv: '123', amount: 20 };
    await expect(processPremiumPayment('user123', payment, 'premium')).rejects.toThrow('Invalid payment details');
  });
});
```

- **`processPremiumPayment insufficient amount branch (line 40)`** (branch, `critical` priority): When payment amount is less than the calculated price, an error should be thrown to prevent undercharging. This must be tested for both tiers.

```ts
describe('processPremiumPayment amount validation', () => {
  it('throws error for insufficient premium payment', async () => {
    const payment = { cardNumber: '1234567890123456', expiryDate: '12/30', cvv: '123', amount: 5.00 };
    await expect(processPremiumPayment('user123', payment, 'premium')).rejects.toThrow('Insufficient payment amount');
  });

  it('throws error for insufficient enterprise payment', async () => {
    const payment = { cardNumber: '1234567890123456', expiryDate: '12/30', cvv: '123', amount: 30.00 };
    await expect(processPremiumPayment('user123', payment, 'enterprise')).rejects.toThrow('Insufficient payment amount');
  });
});
```

- **`upgradeUserSubscription tier-based features (line 133)`** (branch, `critical` priority): Different features are granted based on tier. Both branches must be tested to ensure premium users don't get enterprise features and vice versa.

```ts
describe('upgradeUserSubscription tier branches', () => {
  const mockDb = { query: jest.fn() };
  jest.mock('./database', () => ({ db: mockDb }));

  it('does not grant api_access to premium users', async () => {
    mockDb.query.mockResolvedValueOnce([]);
    await upgradeUserSubscription('user123', 'premium');
    const features = JSON.parse(mockDb.query.mock.calls[0][1][3]);
    expect(features).not.toContain('api_access');
    expect(features).not.toContain('team_collaboration');
  });

  it('grants all features to enterprise users', async () => {
    mockDb.query.mockResolvedValueOnce([]);
    await upgradeUserSubscription('user456', 'enterprise');
    const features = JSON.parse(mockDb.query.mock.calls[0][1][3]);
    expect(features).toContain('api_access');
    expect(features).toContain('team_collaboration');
  });
});
```

#### Refactoring Opportunities — 6
The file has several high-value refactoring opportunities focused on type safety and maintainability. Key improvements include: (1) extracting feature-to-tier mapping into a const-asserted lookup table for type safety and centralization, (2) simplifying validation logic with guard clauses, (3) extracting subscription validity checking into a reusable function to reduce duplication, (4) moving pricing constants to module level for reusability, (5) creating type aliases for subscription tiers to improve type safety, and (6) extracting expiry date validation for better testability. These refactorings preserve behavior while making the code more maintainable, testable, and type-safe.

- **pattern-improvement** at `upgradeUserSubscription (lines 130-143)` (impact: `high`): Replace inline feature list logic with a lookup table using const assertion to make feature sets type-safe, centralized, and easier to maintain

  Before:

```ts
async function upgradeUserSubscription(userId: string, tier: 'premium' | 'enterprise'): Promise<void> {
  const features = tier === 'premium'
    ? ['unlimited_todos', 'priority_support', 'custom_themes']
    : ['unlimited_todos', 'priority_support', 'custom_themes', 'api_access', 'team_collaboration'];

  const validUntil = new Date();
  validUntil.setFullYear(validUntil.getFullYear() + 1);

  const query = 'INSERT INTO subscriptions (user_id, tier, valid_until, features) VALUES ($1, $2, $3, $4) ON CONFLICT (user_id) DO UPDATE SET tier = $2, valid_until = $3, features = $4';

  await db.query(query, [userId, tier, validUntil, JSON.stringify(features)]);
}
```

  After:

```ts
const TIER_FEATURES = {
  premium: ['unlimited_todos', 'priority_support', 'custom_themes'],
  enterprise: ['unlimited_todos', 'priority_support', 'custom_themes', 'api_access', 'team_collaboration']
} as const;

async function upgradeUserSubscription(userId: string, tier: 'premium' | 'enterprise'): Promise<void> {
  const features = TIER_FEATURES[tier];

  const validUntil = new Date();
  validUntil.setFullYear(validUntil.getFullYear() + 1);

  const query = 'INSERT INTO subscriptions (user_id, tier, valid_until, features) VALUES ($1, $2, $3, $4) ON CONFLICT (user_id) DO UPDATE SET tier = $2, valid_until = $3, features = $4';

  await db.query(query, [userId, tier, validUntil, JSON.stringify(features)]);
}
```

  *Benefits:* Eliminates ternary operator, centralizes feature definitions for reuse, makes it trivial to add new tiers, and const assertion provides compile-time type safety for feature strings

- **simplify** at `validatePaymentDetails (lines 60-87)` (impact: `medium`): Replace multiple early-return checks with guard clauses that use combined conditions and eliminate redundant final return

  Before:

```ts
function validatePaymentDetails(payment: PaymentDetails): boolean {
  const { cardNumber, expiryDate, cvv } = payment;

  // Check card number length
  if (cardNumber.length !== 16) {
    return false;
  }

  // Check CVV length
  if (cvv.length !== 3 && cvv.length !== 4) {
    return false;
  }

  // Validate expiry date format (MM/YY)
  const expiryRegex = /^(0[1-9]|1[0-2])\/\d{2}$/;
  if (!expiryRegex.test(expiryDate)) {
    return false;
  }

  // Check if card is expired
  const [month, year] = expiryDate.split('/');
  const expiryDateObj = new Date(2000 + parseInt(year), parseInt(month) - 1);

  if (expiryDateObj < new Date()) {
    return false;
  }

  return true;
}
```

  After:

```ts
function validatePaymentDetails(payment: PaymentDetails): boolean {
  const { cardNumber, expiryDate, cvv } = payment;

  if (cardNumber.length !== 16) return false;
  if (cvv.length !== 3 && cvv.length !== 4) return false;

  const expiryRegex = /^(0[1-9]|1[0-2])\/\d{2}$/;
  if (!expiryRegex.test(expiryDate)) return false;

  const [month, year] = expiryDate.split('/');
  const expiryDateObj = new Date(2000 + parseInt(year), parseInt(month) - 1);

  return expiryDateObj >= new Date();
}
```

  *Benefits:* Reduces vertical space, removes redundant final return true, and inverts the last condition to return the boolean expression directly, making the logic more compact and readable

- **extract-function** at `validatePaymentDetails (lines 77-83)` (impact: `medium`): Extract expiry date validation logic into a separate function to improve testability and reusability

  Before:

```ts
  // Validate expiry date format (MM/YY)
  const expiryRegex = /^(0[1-9]|1[0-2])\/\d{2}$/;
  if (!expiryRegex.test(expiryDate)) {
    return false;
  }

  // Check if card is expired
  const [month, year] = expiryDate.split('/');
  const expiryDateObj = new Date(2000 + parseInt(year), parseInt(month) - 1);

  if (expiryDateObj < new Date()) {
    return false;
  }
```

  After:

```ts
function isExpiryDateValid(expiryDate: string): boolean {
  const expiryRegex = /^(0[1-9]|1[0-2])\/\d{2}$/;
  if (!expiryRegex.test(expiryDate)) return false;

  const [month, year] = expiryDate.split('/');
  const expiryDateObj = new Date(2000 + parseInt(year), parseInt(month) - 1);
  
  return expiryDateObj >= new Date();
}

function validatePaymentDetails(payment: PaymentDetails): boolean {
  const { cardNumber, expiryDate, cvv } = payment;

  if (cardNumber.length !== 16) return false;
  if (cvv.length !== 3 && cvv.length !== 4) return false;
  if (!isExpiryDateValid(expiryDate)) return false;

  return true;
}
```

  *Benefits:* Separates expiry validation concern, making it independently testable, reusable for other payment contexts, and clearer in the parent function

- **modernize** at `calculateSubscriptionPrice (lines 93-107)` (impact: `medium`): Use const assertion on PRICING object to get precise literal types and move constants to module level for reusability

  Before:

```ts
function calculateSubscriptionPrice(tier: 'premium' | 'enterprise'): number {
  const PRICING = {
    premium: 9.99,
    enterprise: 49.99
  };

  const basePrice = PRICING[tier];
  const TAX_RATE = 0.08;
  const PROCESSING_FEE = 0.029;

  const tax = basePrice * TAX_RATE;
  const fee = basePrice * PROCESSING_FEE;

  return basePrice + tax + fee;
}
```

  After:

```ts
const PRICING = {
  premium: 9.99,
  enterprise: 49.99
} as const;

const TAX_RATE = 0.08;
const PROCESSING_FEE = 0.029;

function calculateSubscriptionPrice(tier: 'premium' | 'enterprise'): number {
  const basePrice = PRICING[tier];
  const tax = basePrice * TAX_RATE;
  const fee = basePrice * PROCESSING_FEE;

  return basePrice + tax + fee;
}
```

  *Benefits:* Makes pricing constants accessible for other functions (like displaying prices to users), const assertion provides type safety, and groups related configuration at module level for better maintainability

- **extract-function** at `hasFeatureAccess (lines 148-165)` (impact: `high`): Extract subscription validity check into a reusable function to reduce duplication and improve testability of date comparison logic

  Before:

```ts
export async function hasFeatureAccess(userId: string, feature: string): Promise<boolean> {
  const query = 'SELECT features, valid_until FROM subscriptions WHERE user_id = $1';
  const rows = await db.query(query, [userId]);

  if (rows.length === 0) {
    return false;
  }

  const subscription = rows[0];
  const validUntil = new Date(subscription.valid_until);

  // Check if subscription is still valid
  if (validUntil < new Date()) {
    return false;
  }

  // Check if feature is included
  const features = JSON.parse(subscription.features);
  return features.includes(feature);
}
```

  After:

```ts
function isSubscriptionActive(validUntil: Date): boolean {
  return validUntil >= new Date();
}

export async function hasFeatureAccess(userId: string, feature: string): Promise<boolean> {
  const query = 'SELECT features, valid_until FROM subscriptions WHERE user_id = $1';
  const rows = await db.query(query, [userId]);

  if (rows.length === 0) return false;

  const subscription = rows[0];
  const validUntil = new Date(subscription.valid_until);

  if (!isSubscriptionActive(validUntil)) return false;

  const features = JSON.parse(subscription.features);
  return features.includes(feature);
}
```

  *Benefits:* Extracts date comparison logic into a named, testable function with clear intent, eliminates magic comparison direction, and can be reused in other subscription-related functions

- **pattern-improvement** at `Module level (lines 8-21)` (impact: `medium`): Create a SubscriptionTier type alias and use it consistently throughout the module to improve type safety and reduce duplication

  Before:

```ts
export interface Subscription {
  userId: string;
  tier: 'free' | 'premium' | 'enterprise';
  validUntil: Date;
  features: string[];
}

export interface PaymentDetails {
  cardNumber: string;
  expiryDate: string;
  cvv: string;
  amount: number;
}
```

  After:

```ts
export type SubscriptionTier = 'free' | 'premium' | 'enterprise';
export type PaidTier = 'premium' | 'enterprise';

export interface Subscription {
  userId: string;
  tier: SubscriptionTier;
  validUntil: Date;
  features: readonly string[];
}

export interface PaymentDetails {
  cardNumber: string;
  expiryDate: string;
  cvv: string;
  amount: number;
}
```

  *Benefits:* Creates reusable type aliases that make function signatures clearer, introduces PaidTier for payment functions (more precise than repeating the union), and marks features as readonly to prevent accidental mutation

---

*Generated at 2026-11-12T16:26:27.185Z • Duration: 431573ms • Agents: orchestrator=1.0.0, code-quality-analyzer=1.0.0, test-coverage-analyzer=1.0.0, refactoring-suggester=1.0.0, model=claude-sonnet-4-5-20250929*
