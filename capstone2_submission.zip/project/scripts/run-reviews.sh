#!/usr/bin/env bash
# One-command run for the Vocareum workspace:
#   install -> build -> unit tests -> integration test (octocat/Hello-World#1)
#   -> review udacity/cd14715-simple-todo-app PRs 1, 2, 3 -> check the 9 reports
#   -> package the submission zip.
#
# Usage (from the project folder):   bash scripts/run-reviews.sh
# Options (environment variables):
#   SKIP_INTEGRATION=1   skip the octocat/Hello-World integration run
#   PRS="2 3"            only (re)run these PR numbers
set -u
cd "$(dirname "$0")/.."
ROOT="$(pwd)"
EVIDENCE="$ROOT/evidence"
mkdir -p "$EVIDENCE" "$ROOT/reports"

step() { printf '\n==== %s ====\n' "$*"; }

# ---------- 1. Environment ----------
step "Environment"
if [ ! -f .env ]; then
  cp .env.example .env
  echo "Created .env from .env.example"
fi
# PROJECT_ROOT must be this folder (it holds .claude/skills/)
if grep -q '^PROJECT_ROOT=' .env; then
  sed -i "s#^PROJECT_ROOT=.*#PROJECT_ROOT=$ROOT#" .env
else
  echo "PROJECT_ROOT=$ROOT" >> .env
fi
grep -q '^ANTHROPIC_MODEL=' .env || echo "ANTHROPIC_MODEL=claude-sonnet-4-5-20250929" >> .env
set -a; . ./.env; set +a

if [ -z "${ANTHROPIC_API_KEY:-}" ]; then
  echo "ANTHROPIC_API_KEY is not set in this terminal."
  echo "On Vocareum it is pre-configured; open a new terminal from the Cloud Console and try again."
  exit 1
fi
echo "API key: set (${#ANTHROPIC_API_KEY} chars) | base URL: ${ANTHROPIC_BASE_URL:-default} | model: $ANTHROPIC_MODEL"
echo "PROJECT_ROOT=$PROJECT_ROOT | GITHUB_TOKEN: $([ -n "${GITHUB_TOKEN:-}" ] && echo set || echo 'not set (public repos only)')"
node --version

# ---------- 2. Install, build, test ----------
step "npm install"
npm install --no-audit --no-fund 2>&1 | tail -3

step "npm run build"
npm run build 2>&1 | tee "$EVIDENCE/build.log" | tail -3
[ "${PIPESTATUS[0]}" -eq 0 ] || { echo "Build failed - see evidence/build.log"; exit 1; }

step "npm test"
npm test -- --reporter=verbose 2>&1 | tee "$EVIDENCE/tests.log" | tail -6
[ "${PIPESTATUS[0]}" -eq 0 ] || { echo "Tests failed - see evidence/tests.log"; exit 1; }

# ---------- 3. Integration test against a real PR ----------
if [ "${SKIP_INTEGRATION:-0}" != "1" ] && [ -z "${PRS:-}" ]; then
  step "Integration test: octocat/Hello-World#1"
  npm run dev -- octocat Hello-World 1 2>&1 | tee "$EVIDENCE/integration-octocat-Hello-World-1.log"
  # Keep the integration reports as evidence, out of the 9 deliverables
  mv -f reports/octocat_Hello-World_1.* "$EVIDENCE/" 2>/dev/null || true
fi

# ---------- 4. The three required PRs ----------
for pr in ${PRS:-1 2 3}; do
  step "Review udacity/cd14715-simple-todo-app#$pr"
  npm run dev -- udacity cd14715-simple-todo-app "$pr" 2>&1 | tee "$EVIDENCE/review-pr-$pr.log"
done

# ---------- 5. Check the deliverables ----------
step "Checking reports/"
node - <<'NODE'
const fs = require('fs');
let ok = true;
for (const pr of [1, 2, 3]) {
  for (const ext of ['json', 'md', 'html']) {
    const f = `reports/udacity_cd14715-simple-todo-app_${pr}.${ext}`;
    if (!fs.existsSync(f)) { console.log(`MISSING  ${f}`); ok = false; continue; }
    const text = fs.readFileSync(f, 'utf8');
    let note = `${text.length} bytes`;
    if (ext === 'json') {
      try {
        const r = JSON.parse(text);
        const issues = r.fileReviews.reduce((n, x) => n + x.codeQuality.issues.length, 0);
        const tests = r.fileReviews.reduce((n, x) => n + x.testCoverage.untestedPaths.length, 0);
        const refs = r.fileReviews.reduce((n, x) => n + x.refactorings.suggestions.length, 0);
        note += ` | files ${r.summary.totalFiles}, score ${r.summary.overallScore}, issues ${issues}, test gaps ${tests}, refactorings ${refs}, recs ${r.recommendations.length}`;
        if (r.fileReviews.length === 0) { note += '  <-- NO FILE REVIEWS'; ok = false; }
      } catch (e) { note += '  <-- INVALID JSON'; ok = false; }
    }
    // A missing field shows up as a template gap ("Line undefined", ">undefined<", "undefined/100").
    // The word itself is fine inside findings and suggested test code (e.g. mockResolvedValue(undefined)).
    if (/(Line |>|\| |~|\*\* )undefined\b|\bundefined(\/100|%|<\/)|"(file|summary|description)": ?""/.test(text)) {
      note += '  <-- empty or undefined placeholder'; ok = false;
    }
    console.log(`OK       ${f}  (${note})`);
  }
}
console.log(ok ? '\nAll 9 reports present and populated.' : '\nSome reports need attention (see above).');
process.exitCode = ok ? 0 : 1;
NODE
CHECK=$?

# ---------- 6. Package the submission ----------
step "Packaging submission zip"
OUT="$(dirname "$ROOT")/capstone2_submission.zip"
if ! command -v python3 >/dev/null 2>&1; then
  OUT="$(dirname "$ROOT")/capstone2_submission.tar.gz"
  tar czf "$OUT" --exclude=node_modules --exclude=dist --exclude=logs --exclude=.temp --exclude=.env \
    -C "$(dirname "$ROOT")" "$(basename "$ROOT")"
  echo "python3 not found - packaged as $OUT"
else
python3 - "$ROOT" "$OUT" <<'PY'
import os, sys, zipfile
root, out = sys.argv[1], sys.argv[2]
skip_dirs = {'node_modules', 'dist', 'logs', '.temp', '.git', 'coverage'}
skip_files = {'.env'}
n = 0
with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
    for dp, dns, fns in os.walk(root):
        dns[:] = sorted(d for d in dns if d not in skip_dirs)
        for f in sorted(fns):
            if f in skip_files or f.endswith('.zip'):
                continue
            p = os.path.join(dp, f)
            z.write(p, os.path.join('project', os.path.relpath(p, root)))
            n += 1
print(f"{n} files -> {out} ({os.path.getsize(out):,} bytes)")
PY
fi

echo
[ $CHECK -eq 0 ] && echo "Done. Download $(basename "$OUT") from $(dirname "$ROOT") and send it back for a final check." \
                 || echo "Finished with problems - see the report check above and evidence/*.log."
