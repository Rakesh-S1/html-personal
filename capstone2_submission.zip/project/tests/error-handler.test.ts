import { describe, it, expect, vi, afterEach } from 'vitest';
import {
  ErrorCodes,
  ReviewError,
  formatError,
  isReviewError,
  withRetry,
  withTimeout
} from '../src/utils/error-handler.js';

afterEach(() => {
  vi.useRealTimers();
  vi.restoreAllMocks();
});

/** Resolve to the rejection reason of a promise that is expected to fail. */
function rejectionOf(promise: Promise<unknown>): Promise<ReviewError> {
  return promise.then(
    () => { throw new Error('expected the promise to reject'); },
    (e: unknown) => e as ReviewError
  );
}

describe('withRetry', () => {
  it('returns the result without retrying when the first call succeeds', async () => {
    const fn = vi.fn().mockResolvedValue('ok');
    await expect(withRetry(fn, 3, 1)).resolves.toBe('ok');
    expect(fn).toHaveBeenCalledTimes(1);
  });

  it('retries transient failures and returns the eventual success', async () => {
    const fn = vi.fn()
      .mockRejectedValueOnce(new Error('503'))
      .mockRejectedValueOnce(new Error('503'))
      .mockResolvedValue('recovered');
    await expect(withRetry(fn, 3, 1)).resolves.toBe('recovered');
    expect(fn).toHaveBeenCalledTimes(3);
  });

  it('throws RETRY_EXHAUSTED with the last error after maxRetries attempts', async () => {
    const fn = vi.fn().mockRejectedValue(new Error('still down'));
    const error = await rejectionOf(withRetry(fn, 3, 1));
    expect(isReviewError(error)).toBe(true);
    expect(error.code).toBe(ErrorCodes.RETRY_EXHAUSTED);
    expect(error.message).toContain('still down');
    expect(error.metadata).toMatchObject({ attempts: 3 });
    expect(fn).toHaveBeenCalledTimes(3);
  });

  it('waits with exponential backoff plus jitter between attempts', async () => {
    vi.useFakeTimers();
    vi.spyOn(Math, 'random').mockReturnValue(0.5); // jitter = 50ms
    const fn = vi.fn().mockRejectedValue(new Error('fail'));

    const promise = rejectionOf(withRetry(fn, 3, 1000));
    await vi.advanceTimersByTimeAsync(0);
    expect(fn).toHaveBeenCalledTimes(1);

    await vi.advanceTimersByTimeAsync(1049); // first wait is 1000 + 50
    expect(fn).toHaveBeenCalledTimes(1);
    await vi.advanceTimersByTimeAsync(1);
    expect(fn).toHaveBeenCalledTimes(2);

    await vi.advanceTimersByTimeAsync(2049); // second wait is 2000 + 50
    expect(fn).toHaveBeenCalledTimes(2);
    await vi.advanceTimersByTimeAsync(1);
    expect(fn).toHaveBeenCalledTimes(3);

    const error = await promise;
    expect(error.code).toBe(ErrorCodes.RETRY_EXHAUSTED);
  });
});

describe('withTimeout', () => {
  it('returns the result when the operation finishes in time', async () => {
    await expect(withTimeout(async () => 42, 1000)).resolves.toBe(42);
  });

  it('rejects with AGENT_TIMEOUT and the timeout in metadata when too slow', async () => {
    vi.useFakeTimers();
    const slow = () => new Promise<string>(resolve => setTimeout(() => resolve('late'), 10_000));
    const promise = rejectionOf(withTimeout(slow, 500, 'Agent took too long'));
    await vi.advanceTimersByTimeAsync(500);
    const error = await promise;
    expect(error).toBeInstanceOf(ReviewError);
    expect(error.code).toBe(ErrorCodes.AGENT_TIMEOUT);
    expect(error.message).toBe('Agent took too long');
    expect(error.metadata).toEqual({ timeoutMs: 500 });
  });

  it('passes through errors from the operation itself', async () => {
    await expect(withTimeout(async () => { throw new Error('boom'); }, 1000)).rejects.toThrow('boom');
  });
});

describe('formatError', () => {
  it('includes the code for ReviewErrors', () => {
    expect(formatError(new ReviewError('PR missing', ErrorCodes.PR_NOT_FOUND))).toBe('[PR_NOT_FOUND] PR missing');
  });

  it('handles plain errors and non-errors', () => {
    expect(formatError(new Error('x'))).toBe('x');
    expect(formatError('text')).toBe('text');
  });
});
