import { describe, it, expect } from 'vitest';
import { existsSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { parseCliArgs, resolveProjectRoot, validateAuth, validateModel } from '../src/config/env.js';
import { mcpServersConfig, MCP_ALLOWED_TOOLS } from '../src/config/mcp.config.js';
import { reviewAgents, AGENT_NAMES } from '../src/agents/index.js';
import {
  CODE_QUALITY_ANALYZER_PROMPT,
  TEST_COVERAGE_ANALYZER_PROMPT,
  REFACTORING_SUGGESTER_PROMPT,
  buildOrchestratorPrompt
} from '../src/prompts/index.js';

describe('CLI argument validation', () => {
  it('parses owner, repo and PR number', () => {
    expect(parseCliArgs(['udacity', 'cd14715-simple-todo-app', '2'])).toEqual({
      ok: true, value: { owner: 'udacity', repo: 'cd14715-simple-todo-app', prNumber: 2 }
    });
  });

  it.each([[[]], [['udacity']], [['udacity', 'repo']]])('rejects missing arguments %j', args => {
    const r = parseCliArgs(args);
    expect(r.ok).toBe(false);
    if (!r.ok) expect(r.errors.join('\n')).toContain('Usage:');
  });

  it.each(['0', '-1', 'abc', '1.5', '12abc'])('rejects PR number "%s"', pr => {
    const r = parseCliArgs(['o', 'r', pr]);
    expect(r.ok).toBe(false);
    if (!r.ok) expect(r.errors[0]).toContain('positive integer');
  });
});

describe('Environment validation', () => {
  it('accepts an Anthropic API key', () => {
    expect(validateAuth({ ANTHROPIC_API_KEY: 'x' })).toEqual({ ok: true, value: 'anthropic' });
  });

  it('accepts complete AWS Bedrock credentials', () => {
    expect(validateAuth({ AWS_ACCESS_KEY_ID: 'a', AWS_SECRET_ACCESS_KEY: 'b', AWS_REGION: 'us-east-1' }))
      .toEqual({ ok: true, value: 'bedrock' });
  });

  it('asks for AWS_REGION when only AWS keys are set', () => {
    const r = validateAuth({ AWS_ACCESS_KEY_ID: 'a', AWS_SECRET_ACCESS_KEY: 'b' });
    expect(r.ok).toBe(false);
    if (!r.ok) expect(r.errors[0]).toContain('AWS_REGION');
  });

  it('explains both options when no credentials are set', () => {
    const r = validateAuth({});
    expect(r.ok).toBe(false);
    if (!r.ok) expect(r.errors.join('\n')).toMatch(/ANTHROPIC_API_KEY[\s\S]*AWS_ACCESS_KEY_ID/);
  });

  it('requires ANTHROPIC_MODEL and shows both formats', () => {
    expect(validateModel({ ANTHROPIC_MODEL: 'claude-sonnet-4-5-20250929' })).toEqual({ ok: true, value: 'claude-sonnet-4-5-20250929' });
    const r = validateModel({ ANTHROPIC_MODEL: '  ' });
    expect(r.ok).toBe(false);
    if (!r.ok) expect(r.errors.join('\n')).toMatch(/claude-sonnet-4-5-20250929[\s\S]*us\.anthropic/);
  });

  it('falls back to cwd when PROJECT_ROOT is unset', () => {
    expect(resolveProjectRoot({}, '/work')).toBe('/work');
    expect(resolveProjectRoot({ PROJECT_ROOT: '/proj' }, '/work')).toBe('/proj');
  });
});

describe('MCP configuration', () => {
  it('configures GitHub over stdio via npx, mapping GITHUB_TOKEN', () => {
    expect(mcpServersConfig.github).toMatchObject({
      type: 'stdio', command: 'npx', args: ['-y', '@modelcontextprotocol/server-github']
    });
    expect(Object.keys(mcpServersConfig.github.env ?? {})).toEqual(['GITHUB_PERSONAL_ACCESS_TOKEN']);
  });

  it('configures ESLint over stdio via npx without auth', () => {
    expect(mcpServersConfig.eslint).toEqual({ type: 'stdio', command: 'npx', args: ['-y', '@eslint/mcp@latest'], env: {} });
  });

  it('only allows read-oriented MCP tools', () => {
    expect(MCP_ALLOWED_TOOLS.every(t => t.startsWith('mcp__github__get_') || t.startsWith('mcp__eslint__'))).toBe(true);
  });

  it('contains no hard-coded secrets in source files', () => {
    const files = ['src/config/mcp.config.ts', 'src/main.ts', 'src/orchestrator.ts', 'src/config/env.ts'];
    for (const f of files) {
      const text = readFileSync(path.resolve(f), 'utf-8');
      expect(text).not.toMatch(/sk-ant-[A-Za-z0-9]|ghp_[A-Za-z0-9]{20}|voc-[0-9a-f]{10}/);
    }
  });
});

describe('Subagent definitions', () => {
  it('defines three distinct agents', () => {
    expect(Object.keys(reviewAgents)).toEqual(Object.values(AGENT_NAMES));
    const prompts = new Set(Object.values(reviewAgents).map(a => a.prompt));
    expect(prompts.size).toBe(3);
  });

  it.each(Object.entries(reviewAgents))('%s inherits the model, has a description and the Skill tool', (_name, agent) => {
    expect(agent.model).toBe('inherit');
    expect(agent.description.length).toBeGreaterThan(60);
    expect(agent.tools).toContain('Skill');
    expect(agent.tools).toContain('mcp__github__get_file_contents');
    expect(agent.tools).not.toContain('Bash');
    expect(agent.tools).not.toContain('Write');
  });
});

describe('Prompts and skills', () => {
  it('each subagent prompt states its focus and its output schema', () => {
    expect(CODE_QUALITY_ANALYZER_PROMPT).toMatch(/security/i);
    expect(CODE_QUALITY_ANALYZER_PROMPT).toMatch(/performance/i);
    expect(TEST_COVERAGE_ANALYZER_PROMPT).toMatch(/assertions/i);
    expect(TEST_COVERAGE_ANALYZER_PROMPT).toMatch(/untestedPaths/);
    expect(REFACTORING_SUGGESTER_PROMPT).toMatch(/before/);
    for (const p of [CODE_QUALITY_ANALYZER_PROMPT, TEST_COVERAGE_ANALYZER_PROMPT, REFACTORING_SUGGESTER_PROMPT]) {
      expect(p).toContain('JSON Schema for your answer');
      expect(p).toContain('"required"');
      expect(p).toMatch(/invoke Skill "/);
    }
  });

  it('every skill a prompt invokes exists in .claude/skills/', () => {
    const all = [CODE_QUALITY_ANALYZER_PROMPT, TEST_COVERAGE_ANALYZER_PROMPT, REFACTORING_SUGGESTER_PROMPT].join('\n');
    const skills = [...all.matchAll(/Skill "([a-z-]+)"/g)].map(m => m[1]!);
    expect(skills.length).toBeGreaterThan(0);
    for (const s of new Set(skills)) {
      expect(existsSync(path.resolve('.claude/skills', s, 'SKILL.md')), s).toBe(true);
    }
  });

  it('orchestrator prompt fetches the PR first, then explicitly invokes each agent', () => {
    const p = buildOrchestratorPrompt({ owner: 'o', repo: 'r', prNumber: 5 });
    const fetchAt = p.indexOf('mcp__github__get_pull_request_files');
    const invokeAt = p.indexOf('Use the code-quality-analyzer agent');
    expect(fetchAt).toBeGreaterThan(-1);
    expect(invokeAt).toBeGreaterThan(fetchAt);
    expect(p).toContain('Use the test-coverage-analyzer agent');
    expect(p).toContain('Use the refactoring-suggester agent');
    expect(p).toContain('ReviewReport');
  });
});
