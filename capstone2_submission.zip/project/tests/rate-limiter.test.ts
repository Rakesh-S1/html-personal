import { describe, it, expect, vi, afterEach } from 'vitest';
import { DEFAULT_RATE_LIMITS, RateLimiter, withRateLimit } from '../src/utils/rate-limiter.js';

afterEach(() => {
  vi.useRealTimers();
});

describe('RateLimiter', () => {
  it('uses defaults and merges overrides', () => {
    expect(new RateLimiter().getConfig()).toEqual(DEFAULT_RATE_LIMITS);
    expect(new RateLimiter({ maxConcurrent: 2 }).getConfig()).toEqual({ ...DEFAULT_RATE_LIMITS, maxConcurrent: 2 });
  });

  it('records requests and tokens in the window on acquire', async () => {
    const limiter = new RateLimiter();
    await limiter.acquire(500);
    await limiter.acquire(700);
    expect(limiter.getStatus()).toMatchObject({ activeRequests: 2, requestsInWindow: 2, tokensInWindow: 1200 });
  });

  it('canProceed respects the concurrency limit', async () => {
    const limiter = new RateLimiter({ maxConcurrent: 1 });
    expect(limiter.canProceed(10)).toBe(true);
    await limiter.acquire(10);
    expect(limiter.canProceed(10)).toBe(false);
    limiter.release();
    expect(limiter.canProceed(10)).toBe(true);
  });

  it('canProceed respects requests per minute', async () => {
    const limiter = new RateLimiter({ maxRequestsPerMinute: 2, maxConcurrent: 10 });
    await limiter.acquire(1);
    await limiter.acquire(1);
    expect(limiter.canProceed(1)).toBe(false);
  });

  it('canProceed respects tokens per minute', async () => {
    const limiter = new RateLimiter({ maxTokensPerMinute: 1000 });
    await limiter.acquire(800);
    limiter.release();
    expect(limiter.canProceed(200)).toBe(true);
    expect(limiter.canProceed(201)).toBe(false);
  });

  it('release() updates the last request with the actual token count', async () => {
    const limiter = new RateLimiter();
    await limiter.acquire(1000);
    limiter.release(250);
    expect(limiter.getStatus().tokensInWindow).toBe(250);
  });

  it('prunes records older than 60 seconds (sliding window)', async () => {
    vi.useFakeTimers();
    const limiter = new RateLimiter({ maxRequestsPerMinute: 1 });
    await limiter.acquire(100);
    limiter.release();
    expect(limiter.canProceed(100)).toBe(false);

    vi.advanceTimersByTime(60_001);
    expect(limiter.canProceed(100)).toBe(true);
    expect(limiter.getStatus().requestsInWindow).toBe(0);
  });

  it('acquire waits for a concurrent slot until release() is called', async () => {
    const limiter = new RateLimiter({ maxConcurrent: 1 });
    await limiter.acquire(1);

    let second = false;
    const pending = limiter.acquire(1).then(() => { second = true; });
    await Promise.resolve();
    expect(second).toBe(false);

    limiter.release();
    await pending;
    expect(second).toBe(true);
    expect(limiter.getStatus().activeRequests).toBe(1);
  });

  it('acquire waits for the window to slide when requests per minute are used up', async () => {
    vi.useFakeTimers();
    const limiter = new RateLimiter({ maxRequestsPerMinute: 1 });
    await limiter.acquire(1);
    limiter.release();

    let done = false;
    const pending = limiter.acquire(1).then(() => { done = true; });
    await vi.advanceTimersByTimeAsync(30_000);
    expect(done).toBe(false);
    await vi.advanceTimersByTimeAsync(31_000);
    await pending;
    expect(done).toBe(true);
  });

  it('withRateLimit releases the slot even when the operation fails', async () => {
    const limiter = new RateLimiter({ maxConcurrent: 1 });
    await expect(withRateLimit(limiter, async () => { throw new Error('fail'); })).rejects.toThrow('fail');
    expect(limiter.getStatus().activeRequests).toBe(0);
    await expect(withRateLimit(limiter, async () => 'ok')).resolves.toBe('ok');
  });
});
