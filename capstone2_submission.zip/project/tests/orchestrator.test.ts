import { describe, it, expect, vi } from 'vitest';
import type { Options, SDKMessage } from '@anthropic-ai/claude-agent-sdk';
import {
  CodeReviewOrchestrator,
  ORCHESTRATOR_ALLOWED_TOOLS,
  computeSummary,
  extractJson,
  finalizeReport,
  parseReviewOutput
} from '../src/orchestrator.js';
import type { QueryFn } from '../src/orchestrator.js';
import { AGENT_NAMES } from '../src/agents/index.js';
import { GITHUB_MCP_TOOLS } from '../src/config/mcp.config.js';
import { ErrorCodes } from '../src/utils/error-handler.js';
import { ReviewReportSchema } from '../src/types/index.js';
import { validReport } from './fixtures.js';
import { logger } from '../src/utils/logger.js';

// Keep mocked runs out of the console and out of logs/combined.log (real runs only).
logger.silent = !process.env.RUN_INTEGRATION;

/**
 * Tests for CodeReviewOrchestrator
 *
 * The Claude Agent SDK `query` function is replaced with a scripted fake that
 * emits the same message types the real SDK streams (assistant tool_use blocks,
 * then a result message), so no API key or network is needed.
 */

const toolUse = (name: string, input: Record<string, unknown>, parent: string | null = null): SDKMessage => ({
  type: 'assistant',
  parent_tool_use_id: parent,
  uuid: '00000000-0000-0000-0000-000000000000',
  session_id: 'test',
  message: { content: [{ type: 'tool_use', id: `toolu_${name}`, name, input }] }
} as unknown as SDKMessage);

const success = (structured_output: unknown, result = ''): SDKMessage => ({
  type: 'result',
  subtype: 'success',
  is_error: false,
  num_turns: 6,
  total_cost_usd: 0.42,
  duration_ms: 1000,
  duration_api_ms: 900,
  result,
  structured_output,
  permission_denials: [],
  usage: {},
  modelUsage: {},
  uuid: '00000000-0000-0000-0000-000000000001',
  session_id: 'test'
} as unknown as SDKMessage);

/** A successful scripted run: fetch PR, spawn three subagents, return the report. */
function scriptedRun(output: unknown = validReport()): SDKMessage[] {
  return [
    toolUse(GITHUB_MCP_TOOLS.getPullRequest, { owner: 'udacity', repo: 'cd14715-simple-todo-app', pull_number: 3 }),
    toolUse(GITHUB_MCP_TOOLS.getPullRequestFiles, { owner: 'udacity', repo: 'cd14715-simple-todo-app', pull_number: 3 }),
    toolUse('Task', { subagent_type: AGENT_NAMES.codeQuality, description: 'Quality: src/premium.ts' }),
    toolUse('Task', { subagent_type: AGENT_NAMES.testCoverage, description: 'Coverage: src/premium.ts' }),
    toolUse('Task', { subagent_type: AGENT_NAMES.refactoring, description: 'Refactor: src/premium.ts' }),
    toolUse('Skill', { skill: 'security-analysis' }, 'toolu_Task'),
    success(output)
  ];
}

function fakeQuery(runs: SDKMessage[][]): QueryFn & { calls: Array<{ prompt: string; options?: Options }> } {
  const calls: Array<{ prompt: string; options?: Options }> = [];
  const fn = ((params: { prompt: string; options?: Options }): AsyncIterable<SDKMessage> => {
    calls.push(params);
    const messages = runs[Math.min(calls.length - 1, runs.length - 1)] ?? [];
    return (async function* () { for (const m of messages) yield m; })();
  }) as QueryFn & { calls: typeof calls };
  fn.calls = calls;
  return fn;
}

// Small token reservation so back-to-back attempts in a test don't wait for the 60s window.
const baseOptions = { model: 'claude-test-model', projectRoot: '/tmp/project', retryDelayMs: 1, estimatedTokensPerReview: 1000 };

describe('CodeReviewOrchestrator', () => {
  describe('Configuration', () => {
    it('should initialize with default options', () => {
      const o = new CodeReviewOrchestrator({ model: 'claude-test-model' });
      expect(o.model).toBe('claude-test-model');
      expect(o.maxTurns).toBe(40);
      expect(o.maxAttempts).toBe(2);
      expect(o.rateLimiter.getConfig().maxConcurrent).toBe(5);
    });

    it('should read the model from ANTHROPIC_MODEL and refuse to start without one', () => {
      vi.stubEnv('ANTHROPIC_MODEL', 'claude-from-env');
      expect(new CodeReviewOrchestrator().model).toBe('claude-from-env');
      vi.stubEnv('ANTHROPIC_MODEL', '');
      expect(() => new CodeReviewOrchestrator()).toThrow(/ANTHROPIC_MODEL/);
      vi.unstubAllEnvs();
    });

    it('should accept custom rate limit configuration', () => {
      const o = new CodeReviewOrchestrator({ ...baseOptions, rateLimits: { maxConcurrent: 2, maxRequestsPerMinute: 10 } });
      expect(o.rateLimiter.getConfig()).toMatchObject({ maxConcurrent: 2, maxRequestsPerMinute: 10, maxTokensPerMinute: 100000 });
    });

    it('should register all three subagents, MCP servers, Task tool and structured output', () => {
      const opts = new CodeReviewOrchestrator(baseOptions).buildQueryOptions();
      expect(Object.keys(opts.agents ?? {})).toEqual([AGENT_NAMES.codeQuality, AGENT_NAMES.testCoverage, AGENT_NAMES.refactoring]);
      expect(Object.keys(opts.mcpServers ?? {})).toEqual(['github', 'eslint']);
      expect(opts.allowedTools).toContain('Task');
      expect(opts.allowedTools).toContain('Skill');
      expect(opts.allowedTools).toEqual(expect.arrayContaining([GITHUB_MCP_TOOLS.getPullRequest, GITHUB_MCP_TOOLS.getPullRequestFiles]));
      expect(opts.disallowedTools).toEqual(expect.arrayContaining(['Bash', 'Write', 'Edit']));
      expect(opts.permissionMode).toBe('dontAsk');
      expect(opts.model).toBe('claude-test-model');
      expect(opts.cwd).toBe('/tmp/project');
      expect(opts.settingSources).toEqual(['project']);
      expect(opts.outputFormat?.type).toBe('json_schema');
      expect(opts.outputFormat?.schema).not.toHaveProperty('$schema');
      expect(opts.outputFormat?.schema).toHaveProperty('properties.fileReviews');
    });

    it('allows every tool the subagents need at session level', () => {
      const opts = new CodeReviewOrchestrator(baseOptions).buildQueryOptions();
      for (const agent of Object.values(opts.agents ?? {})) {
        for (const tool of agent.tools ?? []) expect(ORCHESTRATOR_ALLOWED_TOOLS).toContain(tool);
      }
    });
  });

  describe('reviewPullRequest', () => {
    it('should fetch PR files from GitHub MCP', async () => {
      const q = fakeQuery([scriptedRun()]);
      const o = new CodeReviewOrchestrator({ ...baseOptions, queryFn: q });
      await o.reviewPullRequest('udacity', 'cd14715-simple-todo-app', 3);

      const prompt = q.calls[0]!.prompt;
      expect(prompt).toContain(GITHUB_MCP_TOOLS.getPullRequest);
      expect(prompt).toContain(GITHUB_MCP_TOOLS.getPullRequestFiles);
      expect(prompt).toContain('pull_number=3');
      expect(o.getDiagnostics().toolCalls.map(t => t.tool)).toEqual(
        expect.arrayContaining([GITHUB_MCP_TOOLS.getPullRequest, GITHUB_MCP_TOOLS.getPullRequestFiles])
      );
    });

    it('should spawn all 3 subagents in parallel', async () => {
      const q = fakeQuery([scriptedRun()]);
      const o = new CodeReviewOrchestrator({ ...baseOptions, queryFn: q });
      await o.reviewPullRequest('udacity', 'cd14715-simple-todo-app', 3);

      const prompt = q.calls[0]!.prompt;
      for (const name of Object.values(AGENT_NAMES)) expect(prompt).toContain(`Use the ${name} agent`);
      expect(prompt).toMatch(/same turn so they run in parallel/);
      expect(o.getDiagnostics().subagentsInvoked).toEqual([
        AGENT_NAMES.codeQuality, AGENT_NAMES.testCoverage, AGENT_NAMES.refactoring
      ]);
    });

    it('should aggregate results into ReviewReport', async () => {
      const raw = validReport();
      raw.summary = { totalFiles: 99, overallScore: 99, criticalIssues: 0, highPriorityTests: 0, refactoringOpportunities: 0 };
      const o = new CodeReviewOrchestrator({ ...baseOptions, queryFn: fakeQuery([scriptedRun(raw)]) });
      const report = await o.reviewPullRequest('udacity', 'cd14715-simple-todo-app', 3);

      // Summary is recomputed from findings, not trusted from the model
      expect(report.summary).toEqual({
        totalFiles: 1,
        overallScore: Math.round(0.7 * 55 + 0.3 * 0),
        criticalIssues: 1,
        highPriorityTests: 2,
        refactoringOpportunities: 1
      });
      expect(report.pullRequest).toEqual({ owner: 'udacity', repo: 'cd14715-simple-todo-app', number: 3 });
      expect(report.metadata.agentVersions).toMatchObject({ model: 'claude-test-model', [AGENT_NAMES.codeQuality]: '1.0.0' });
      expect(report.fileReviews[0]!.codeQuality.issues[0]!.line).toBe(42);
    });

    it('should validate output with Zod schema', async () => {
      const o = new CodeReviewOrchestrator({ ...baseOptions, maxAttempts: 1, queryFn: fakeQuery([scriptedRun({ fileReviews: 'nope' })]) });
      const error = await o.reviewPullRequest('udacity', 'cd14715-simple-todo-app', 3).catch(e => e);
      expect(error.code).toBe(ErrorCodes.RETRY_EXHAUSTED);
      expect(error.message).toMatch(/did not match the ReviewReport schema/);

      const ok = new CodeReviewOrchestrator({ ...baseOptions, queryFn: fakeQuery([scriptedRun()]) });
      const report = await ok.reviewPullRequest('udacity', 'cd14715-simple-todo-app', 3);
      expect(ReviewReportSchema.safeParse(report).success).toBe(true);
    });

    it('retries a failed run and succeeds on the next attempt', async () => {
      const failed: SDKMessage[] = [{
        type: 'result', subtype: 'error_max_turns', is_error: true, num_turns: 40, total_cost_usd: 0.1,
        errors: ['max turns'], permission_denials: [], usage: {}, modelUsage: {}, duration_ms: 1, duration_api_ms: 1,
        uuid: 'x', session_id: 'test'
      } as unknown as SDKMessage];
      const q = fakeQuery([failed, scriptedRun()]);
      const o = new CodeReviewOrchestrator({ ...baseOptions, maxAttempts: 2, queryFn: q });
      const report = await o.reviewPullRequest('udacity', 'cd14715-simple-todo-app', 3);
      expect(q.calls).toHaveLength(2);
      expect(report.fileReviews).toHaveLength(1);
      expect(o.rateLimiter.getStatus().activeRequests).toBe(0);
      expect(o.rateLimiter.getStatus().requestsInWindow).toBe(2);
    });

    it('rate-limits a retry that would exceed the tokens-per-minute budget', async () => {
      vi.useFakeTimers();
      const failed: SDKMessage[] = [{
        type: 'result', subtype: 'error_during_execution', is_error: true, num_turns: 1, total_cost_usd: 0,
        errors: ['boom'], permission_denials: [], usage: {}, modelUsage: {}, duration_ms: 1, duration_api_ms: 1,
        uuid: 'x', session_id: 'test'
      } as unknown as SDKMessage];
      const q = fakeQuery([failed, scriptedRun()]);
      // 60k tokens per review against a 100k/minute budget: the retry must wait for the window to slide
      const o = new CodeReviewOrchestrator({
        ...baseOptions, estimatedTokensPerReview: 60_000, rateLimits: { maxTokensPerMinute: 100_000 }, queryFn: q
      });
      let done = false;
      const pending = o.reviewPullRequest('udacity', 'cd14715-simple-todo-app', 3).then(() => { done = true; });
      await vi.advanceTimersByTimeAsync(30_000);
      expect(q.calls).toHaveLength(1);
      expect(done).toBe(false);
      await vi.advanceTimersByTimeAsync(31_000);
      await pending;
      expect(q.calls).toHaveLength(2);
      vi.useRealTimers();
    });

    it('still produces a report when one subagent failed, and flags it', async () => {
      const raw = validReport();
      raw.recommendations = [];
      raw.fileReviews[0]!.testCoverage = {
        file: 'src/premium.ts', hasTests: false, testFiles: [], untestedPaths: [], coverageEstimate: 0,
        summary: 'ANALYSIS FAILED: subagent timed out twice'
      };
      const o = new CodeReviewOrchestrator({ ...baseOptions, queryFn: fakeQuery([scriptedRun(raw)]) });
      const report = await o.reviewPullRequest('udacity', 'cd14715-simple-todo-app', 3);
      expect(report.fileReviews).toHaveLength(1);
      expect(report.recommendations.some(r => r.category === 'Review incomplete' && r.description.includes('test coverage'))).toBe(true);
      // Recommendations were derived from findings because the model sent none
      expect(report.recommendations.some(r => r.priority === 'critical')).toBe(true);
    });

    it('falls back to JSON in the result text when structured_output is missing', async () => {
      const text = 'Here is the report:\n```json\n' + JSON.stringify(validReport()) + '\n```';
      const o = new CodeReviewOrchestrator({ ...baseOptions, queryFn: fakeQuery([[success(undefined, text)]]) });
      const report = await o.reviewPullRequest('udacity', 'cd14715-simple-todo-app', 3);
      expect(report.fileReviews[0]!.file).toBe('src/premium.ts');
    });

    it('times out a hung run with AGENT_TIMEOUT', async () => {
      const hung: QueryFn = () => (async function* () { await new Promise(() => {}); })();
      const o = new CodeReviewOrchestrator({ ...baseOptions, maxAttempts: 1, timeoutMs: 20, queryFn: hung });
      const error = await o.reviewPullRequest('o', 'r', 1).catch(e => e);
      expect(error.message).toContain(ErrorCodes.AGENT_TIMEOUT);
    });
  });

  describe('helpers', () => {
    it('computeSummary returns zeros for an empty review', () => {
      expect(computeSummary([])).toEqual({ totalFiles: 0, overallScore: 0, criticalIssues: 0, highPriorityTests: 0, refactoringOpportunities: 0 });
    });

    it('extractJson handles bare JSON, fenced JSON and garbage', () => {
      expect(extractJson('{"a":1}')).toEqual({ a: 1 });
      expect(extractJson('text ```json\n{"b":2}\n``` more')).toEqual({ b: 2 });
      expect(extractJson('no json here')).toBeUndefined();
    });

    it('parseReviewOutput throws STRUCTURED_OUTPUT_FAILED with the failing path', () => {
      expect(() => parseReviewOutput({ pullRequest: {} })).toThrow(/pullRequest\.owner/);
    });

    it('finalizeReport takes identity and timing from the harness', () => {
      const r = finalizeReport(validReport(), { owner: 'a', repo: 'b', prNumber: 7, startedAt: 1_000, now: 4_500, model: 'm' });
      expect(r.pullRequest).toEqual({ owner: 'a', repo: 'b', number: 7 });
      expect(r.metadata.duration).toBe(3_500);
      expect(r.metadata.analyzedAt).toBe(new Date(1_000).toISOString());
    });
  });

  describe('Integration', () => {
    // Real end-to-end run against a public PR. Needs ANTHROPIC_API_KEY (+ ANTHROPIC_BASE_URL on
    // Vocareum) and ANTHROPIC_MODEL, costs real tokens, so it only runs when RUN_INTEGRATION=1:
    //   RUN_INTEGRATION=1 npx vitest run tests/orchestrator.test.ts
    // The CLI equivalent is: npm run dev -- octocat Hello-World 1
    it.skipIf(!process.env.RUN_INTEGRATION)('should review a real small PR (octocat/Hello-World#1)', async () => {
      const o = new CodeReviewOrchestrator();
      const report = await o.reviewPullRequest('octocat', 'Hello-World', 1);
      expect(ReviewReportSchema.safeParse(report).success).toBe(true);
      expect(report.pullRequest).toEqual({ owner: 'octocat', repo: 'Hello-World', number: 1 });
      expect(o.getDiagnostics().subagentsInvoked.length).toBeGreaterThan(0);
    }, 20 * 60 * 1000);
  });
});
