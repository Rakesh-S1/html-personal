import { describe, it, expect } from 'vitest';
import { ZodError } from 'zod';
import { zodToJsonSchema } from 'zod-to-json-schema';
import {
  CodeQualityResultSchema,
  TestCoverageResultSchema,
  RefactoringSuggestionSchema,
  ReviewReportSchema,
  CodeQualityResultJSONSchema,
  TestCoverageResultJSONSchema,
  RefactoringSuggestionJSONSchema,
  ReviewReportJSONSchema
} from '../src/types/index.js';
import { validCodeQuality, validRefactoring, validReport, validTestCoverage } from './fixtures.js';

describe('CodeQualityResultSchema', () => {
  it('accepts a valid result', () => {
    expect(() => CodeQualityResultSchema.parse(validCodeQuality())).not.toThrow();
  });

  it('accepts an empty issues array', () => {
    expect(() => CodeQualityResultSchema.parse({ ...validCodeQuality(), issues: [] })).not.toThrow();
  });

  it.each([0, 100])('accepts boundary score %i', score => {
    expect(CodeQualityResultSchema.parse({ ...validCodeQuality(), overallScore: score }).overallScore).toBe(score);
  });

  it.each([-1, 101])('rejects out-of-range score %i', score => {
    expect(() => CodeQualityResultSchema.parse({ ...validCodeQuality(), overallScore: score })).toThrow(ZodError);
  });

  it('rejects an unknown severity', () => {
    const bad = validCodeQuality();
    (bad.issues[0] as { severity: string }).severity = 'urgent';
    expect(() => CodeQualityResultSchema.parse(bad)).toThrow(ZodError);
  });

  it('rejects an unknown category', () => {
    const bad = validCodeQuality();
    (bad.issues[0] as { category: string }).category = 'vibes';
    expect(() => CodeQualityResultSchema.parse(bad)).toThrow(ZodError);
  });

  it('rejects a line number given as a string', () => {
    const bad = validCodeQuality();
    (bad.issues[0] as unknown as { line: string }).line = '42';
    expect(() => CodeQualityResultSchema.parse(bad)).toThrow(ZodError);
  });

  it('rejects a missing summary', () => {
    const { summary: _omit, ...bad } = validCodeQuality();
    expect(() => CodeQualityResultSchema.parse(bad)).toThrow(ZodError);
  });
});

describe('TestCoverageResultSchema', () => {
  it('accepts a valid result', () => {
    expect(() => TestCoverageResultSchema.parse(validTestCoverage())).not.toThrow();
  });

  it('accepts a fully tested file with empty arrays', () => {
    const tested = { ...validTestCoverage(), hasTests: true, testFiles: ['src/todo.test.ts'], untestedPaths: [], coverageEstimate: 100 };
    expect(() => TestCoverageResultSchema.parse(tested)).not.toThrow();
  });

  it('accepts coverage of 0', () => {
    expect(TestCoverageResultSchema.parse({ ...validTestCoverage(), coverageEstimate: 0 }).coverageEstimate).toBe(0);
  });

  it('rejects coverage above 100', () => {
    expect(() => TestCoverageResultSchema.parse({ ...validTestCoverage(), coverageEstimate: 120 })).toThrow(ZodError);
  });

  it('rejects an invalid untested-path type', () => {
    const bad = validTestCoverage();
    (bad.untestedPaths[0] as { type: string }).type = 'module';
    expect(() => TestCoverageResultSchema.parse(bad)).toThrow(ZodError);
  });

  it('rejects "info" as a priority (only valid for code-quality severity)', () => {
    const bad = validTestCoverage();
    (bad.untestedPaths[0] as { priority: string }).priority = 'info';
    expect(() => TestCoverageResultSchema.parse(bad)).toThrow(ZodError);
  });

  it('rejects hasTests given as a string', () => {
    expect(() => TestCoverageResultSchema.parse({ ...validTestCoverage(), hasTests: 'no' })).toThrow(ZodError);
  });
});

describe('RefactoringSuggestionSchema', () => {
  it('accepts a valid result', () => {
    expect(() => RefactoringSuggestionSchema.parse(validRefactoring())).not.toThrow();
  });

  it('accepts no suggestions for clean code', () => {
    expect(() => RefactoringSuggestionSchema.parse({ ...validRefactoring(), suggestions: [] })).not.toThrow();
  });

  it('rejects an unknown refactoring type', () => {
    const bad = validRefactoring();
    (bad.suggestions[0] as { type: string }).type = 'rewrite-everything';
    expect(() => RefactoringSuggestionSchema.parse(bad)).toThrow(ZodError);
  });

  it('rejects a suggestion without before/after code', () => {
    const bad = validRefactoring();
    const { before: _b, after: _a, ...rest } = bad.suggestions[0]!;
    expect(() => RefactoringSuggestionSchema.parse({ ...bad, suggestions: [rest] })).toThrow(ZodError);
  });
});

describe('ReviewReportSchema', () => {
  it('accepts a valid report', () => {
    expect(() => ReviewReportSchema.parse(validReport())).not.toThrow();
  });

  it('accepts a report with no files and no recommendations', () => {
    const empty = {
      ...validReport(),
      fileReviews: [],
      recommendations: [],
      summary: { totalFiles: 0, overallScore: 0, criticalIssues: 0, highPriorityTests: 0, refactoringOpportunities: 0 }
    };
    expect(() => ReviewReportSchema.parse(empty)).not.toThrow();
  });

  it('accepts an empty agentVersions record', () => {
    const r = validReport();
    r.metadata.agentVersions = {};
    expect(() => ReviewReportSchema.parse(r)).not.toThrow();
  });

  it('rejects a PR number given as a string', () => {
    const r = validReport() as unknown as { pullRequest: { number: unknown } };
    r.pullRequest.number = '3';
    expect(() => ReviewReportSchema.parse(r)).toThrow(ZodError);
  });

  it('rejects a recommendation with an invalid priority', () => {
    const r = validReport();
    (r.recommendations[0] as { priority: string }).priority = 'info';
    expect(() => ReviewReportSchema.parse(r)).toThrow(ZodError);
  });

  it('rejects a file review missing its testCoverage section', () => {
    const r = validReport();
    const { testCoverage: _omit, ...partial } = r.fileReviews[0]!;
    expect(() => ReviewReportSchema.parse({ ...r, fileReviews: [partial] })).toThrow(ZodError);
  });

  it('rejects non-string agent versions', () => {
    const r = validReport() as unknown as { metadata: { agentVersions: Record<string, unknown> } };
    r.metadata.agentVersions = { orchestrator: 1 };
    expect(() => ReviewReportSchema.parse(r)).toThrow(ZodError);
  });

  it('safeParse reports the failing path instead of throwing', () => {
    const result = ReviewReportSchema.safeParse({ ...validReport(), summary: undefined });
    expect(result.success).toBe(false);
    if (!result.success) expect(result.error.issues[0]?.path).toEqual(['summary']);
  });
});

describe('JSON Schema export (SDK structured outputs)', () => {
  type ObjectSchema = { type?: string; properties?: Record<string, unknown>; required?: string[] };

  it.each([
    ['CodeQualityResult', CodeQualityResultJSONSchema, ['file', 'issues', 'overallScore', 'summary']],
    ['TestCoverageResult', TestCoverageResultJSONSchema, ['file', 'hasTests', 'testFiles', 'untestedPaths', 'coverageEstimate', 'summary']],
    ['RefactoringSuggestion', RefactoringSuggestionJSONSchema, ['file', 'suggestions', 'summary']],
    ['ReviewReport', ReviewReportJSONSchema, ['pullRequest', 'fileReviews', 'summary', 'recommendations', 'metadata']]
  ])('%s exports an object schema with the right required fields', (_name, schema, required) => {
    const s = schema as ObjectSchema;
    expect(s.type).toBe('object');
    expect(Object.keys(s.properties ?? {})).toEqual(expect.arrayContaining(required as string[]));
    expect(s.required).toEqual(expect.arrayContaining(required as string[]));
  });

  it('inlines everything (no unresolved $ref) so the SDK can use it directly', () => {
    expect(JSON.stringify(ReviewReportJSONSchema)).not.toContain('"$ref"');
  });

  it('keeps enum constraints and numeric bounds', () => {
    const text = JSON.stringify(CodeQualityResultJSONSchema);
    expect(text).toContain('"critical"');
    expect(text).toContain('"maximum":100');
    expect(text).toContain('"minimum":0');
  });

  it('matches a fresh zodToJsonSchema conversion', () => {
    const fresh = zodToJsonSchema(ReviewReportSchema, { $refStrategy: 'root' });
    expect(ReviewReportJSONSchema).toEqual(fresh);
  });
});
