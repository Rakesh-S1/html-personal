import type {
  CodeQualityResult,
  TestCoverageResult,
  RefactoringSuggestion,
  ReviewReport
} from '../src/types/index.js';

export const validCodeQuality = (file = 'src/premium.ts'): CodeQualityResult => ({
  file,
  issues: [
    {
      line: 42,
      severity: 'critical',
      category: 'security',
      description: 'CVV is stored with the subscription record.',
      suggestion: 'Never persist CVV; send it to the payment provider and discard it.'
    },
    {
      line: 101,
      severity: 'medium',
      category: 'bug-risk',
      description: 'Money is calculated with floating point.',
      suggestion: 'Use integer cents.'
    }
  ],
  overallScore: 55,
  summary: 'Payment handling stores sensitive card data.'
});

export const validTestCoverage = (file = 'src/premium.ts'): TestCoverageResult => ({
  file,
  hasTests: false,
  testFiles: [],
  untestedPaths: [
    {
      type: 'function',
      location: 'processPremiumPayment (line 27)',
      priority: 'critical',
      reasoning: 'Charges a card with no test.',
      suggestedTest: "it('rejects an expired card', async () => { await expect(processPremiumPayment('u1', expired, 'premium')).rejects.toThrow(); });"
    },
    {
      type: 'edge-case',
      location: 'validatePaymentDetails (line 62)',
      priority: 'high',
      reasoning: 'Expiry boundary untested.',
      suggestedTest: "it('accepts a card expiring this month', () => {});"
    }
  ],
  coverageEstimate: 0,
  summary: 'No tests exist for premium.ts.'
});

export const validRefactoring = (file = 'src/premium.ts'): RefactoringSuggestion => ({
  file,
  suggestions: [
    {
      type: 'pattern-improvement',
      location: 'calculateSubscriptionPrice (lines 98-115)',
      impact: 'high',
      description: 'Replace inline pricing constants with a lookup table in cents.',
      before: 'const PRICING = { premium: 9.99, enterprise: 49.99 };',
      after: 'const PRICE_CENTS: Record<Tier, number> = { premium: 999, enterprise: 4999 };',
      benefits: 'Removes float maths and centralizes pricing.'
    }
  ],
  summary: 'Pricing logic would benefit from a lookup table.'
});

export const validReport = (): ReviewReport => ({
  pullRequest: { owner: 'udacity', repo: 'cd14715-simple-todo-app', number: 3 },
  fileReviews: [
    {
      file: 'src/premium.ts',
      codeQuality: validCodeQuality(),
      testCoverage: validTestCoverage(),
      refactorings: validRefactoring()
    }
  ],
  summary: {
    totalFiles: 1,
    overallScore: 39,
    criticalIssues: 1,
    highPriorityTests: 2,
    refactoringOpportunities: 1
  },
  recommendations: [
    {
      priority: 'critical',
      category: 'Security',
      description: 'Stop storing CVV in processPremiumPayment.',
      files: ['src/premium.ts']
    }
  ],
  metadata: {
    analyzedAt: '2026-11-12T10:00:00.000Z',
    duration: 1234,
    agentVersions: { orchestrator: '1.0.0' }
  }
});
