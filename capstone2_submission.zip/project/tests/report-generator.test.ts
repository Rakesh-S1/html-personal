import { describe, it, expect } from 'vitest';
import { ReportGenerator, escapeHtml, reportBaseName } from '../src/utils/report-generator.js';
import { ReviewReportSchema } from '../src/types/index.js';
import { validReport } from './fixtures.js';

const generator = new ReportGenerator();

describe('ReportGenerator', () => {
  it('names files <owner>_<repo>_<number>', () => {
    expect(reportBaseName(validReport())).toBe('udacity_cd14715-simple-todo-app_3');
  });

  it('JSON report round-trips through the schema', () => {
    const json = JSON.parse(generator.generateJSONReport(validReport()));
    expect(ReviewReportSchema.safeParse(json).success).toBe(true);
  });

  it('Markdown report includes line numbers, suggested tests and before/after code', () => {
    const md = generator.generateMarkdownReport(validReport());
    expect(md).toContain('udacity/cd14715-simple-todo-app #3');
    expect(md).toContain('| 42 | `critical` | security |');
    expect(md).toContain("it('rejects an expired card'");
    expect(md).toContain('const PRICE_CENTS');
    expect(md).not.toContain('undefined');
  });

  it('HTML report escapes code so it renders correctly', () => {
    const report = validReport();
    report.fileReviews[0]!.refactorings.suggestions[0]!.after = 'const x: Array<string> = [];';
    const html = generator.generateHTMLReport(report);
    expect(html.startsWith('<!DOCTYPE html>')).toBe(true);
    expect(html).toContain('Array&lt;string&gt;');
    expect(html).not.toContain('Array<string>');
    expect(html).toContain('<td class="num">42</td>');
    expect(html).not.toContain('undefined');
  });

  it('escapeHtml escapes all special characters', () => {
    expect(escapeHtml(`<a href="x">&'</a>`)).toBe('&lt;a href=&quot;x&quot;&gt;&amp;&#39;&lt;/a&gt;');
  });
});
