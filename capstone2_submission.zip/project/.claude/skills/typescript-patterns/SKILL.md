---
name: typescript-patterns
description: Reviews TypeScript code for type safety, idiomatic TypeScript patterns and common type-level mistakes. Use when analyzing .ts or .tsx files.
---

# TypeScript Patterns

Checklist for reviewing TypeScript. Cite the line, name the rule, show the fix.

## Type safety
- `any` disables checking: prefer a precise type, a generic, or `unknown` plus narrowing. **medium** (high when it hides external input).
- Type assertions (`as Foo`, `!`) on data that was never validated are unchecked lies. Validate (zod, a type guard) instead. **high** for external/user input.
- Enable and respect `strict`: implicit `any`, missing `null`/`undefined` handling, unchecked index access.
- Function signatures: annotate exported function parameters and return types; avoid `Function` and `Object` types.
- `==` vs `===`; truthiness checks that treat `0` or `''` as missing (use `??` / explicit comparisons).

## Modelling data
- Discriminated unions instead of optional-property soup:
  ```ts
  // before
  interface Result { ok: boolean; value?: T; error?: string }
  // after
  type Result<T> = { ok: true; value: T } | { ok: false; error: string };
  ```
- String literal unions or `as const` objects instead of magic strings; exhaustive `switch` with a `never` check.
- `readonly` / `ReadonlyArray` for data that must not be mutated; `Readonly<T>` for config objects.
- Utility types (`Pick`, `Omit`, `Partial`, `Record`) instead of duplicated interfaces.
- Do not repeat the same literal union in several places: define it once (`type Tier = Subscription['tier']`).

## Async and errors
- Every `Promise` is awaited or returned; no floating promises in loops (use `Promise.all`).
- `catch (e)` gives `unknown`: narrow before using `e.message`.
- Throw `Error` subclasses with context, not strings.

## Money, dates and numbers
- Never use binary floating point for currency (`9.99 * 0.08`): use integer cents or a decimal library and round once. **high** for payment code.
- `new Date(y, m)` uses local time and 0-based months; `parseInt` without radix; two-digit years.

## Severity guide
- critical: type hole that lets untrusted input reach security- or money-sensitive code.
- high: unchecked assertion or float money maths in production logic.
- medium: `any`, missing return types on exported APIs, non-exhaustive unions.
- low: style (prefer `type` vs `interface` consistency, naming).

## Output
Return findings as concrete issues: line, rule broken, why it matters, and the corrected TypeScript.
