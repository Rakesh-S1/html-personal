---
name: security-analysis
description: Security-focused code review based on the OWASP Top 10 and secure coding practices - secrets, sensitive data, injection, validation, auth. Use for every file in a code quality review.
---

# Security Analysis

Look for the issues below. Report the exact line, the attack or failure it enables, and a concrete fix.

## Sensitive data (PCI / PII)
- Full card numbers (PAN), CVV/CVC, passwords or tokens stored, logged, returned to clients or written to a database. **CVV must never be stored after authorization. critical.**
- Card data in plain objects that flow to `console.log`, error messages or analytics. Mask: `**** **** **** 1234`.
- Payment processing in application code instead of a PCI-compliant provider token (Stripe/Adyen tokens). **high**.
- Secrets hard-coded in source (`apiKey = "sk-..."`), committed `.env` values. **critical**.

## Input validation
- Validation done only by length/regex (e.g. 16-digit card check without Luhn, no type checks) - weak validation is **medium**; missing validation on money amounts or IDs is **high**.
- Trusting client-supplied amounts, prices, tiers or user IDs (price must be computed server-side). **high/critical**.
- Missing bounds: negative quantities, NaN, Infinity, extremely long strings (DoS).

## Injection
- SQL/NoSQL built by string concatenation or template literals with user input -> use parameterised queries. **critical**.
- `eval`, `new Function`, dynamic `require`/`import` with user data. **critical**.
- Regex built from user input (ReDoS), unescaped user text in HTML (XSS), shell commands with user input.

## Authorization and logic
- Missing ownership checks (any `userId` can upgrade/cancel any account) - IDOR. **high**.
- Check-then-act races: charging a card and then failing to record it (no transaction/idempotency key) -> double charges or paid-but-not-upgraded users. **high**.
- Error paths that leave the system half-updated; errors swallowed silently.

## Crypto and randomness
- `Math.random()` for IDs/tokens; MD5/SHA1 for passwords; home-made crypto. **high**.

## Severity guide
- critical: exploitable now or exposes card data/secrets.
- high: realistic abuse or data integrity loss.
- medium: defence-in-depth gap.
- low: hardening suggestion.

## Output
For each finding: line, category "security" (or "bug-risk" for integrity problems), severity per the guide, a one-sentence risk statement, and the fixed code.
