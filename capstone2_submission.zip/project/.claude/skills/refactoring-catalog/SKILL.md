---
name: refactoring-catalog
description: Catalogue of behaviour-preserving refactorings (extract function, simplify conditionals, remove dead code, modernize, design patterns) with guidance on judging impact. Use when suggesting refactorings.
---

# Refactoring Catalog

A refactoring changes structure, never behaviour. Every suggestion needs real "before" code from the file and compilable "after" code.

## extract-function
- A function longer than ~30 lines or doing more than one thing (validate + compute + persist).
- A block with a comment explaining what it does -> a function named after the comment.
- The same 3+ lines in two places -> one helper.

## simplify
- Nested `if` pyramids -> guard clauses with early return.
- `if (x) return true; else return false;` -> `return x;`
- Dead code: unused variables/params/imports, unreachable branches, commented-out code, functions never called.
- Repeated conditions -> one well-named boolean.

## modernize (TypeScript/JavaScript)
- `var` -> `const`/`let`; string concatenation -> template literals.
- Manual loops building arrays -> `map`/`filter`/`reduce`/`some`/`find`.
- `a && a.b && a.b.c` -> `a?.b?.c`; `x !== null && x !== undefined ? x : d` -> `x ?? d`.
- `.then()` chains -> `async`/`await`; sequential independent awaits -> `Promise.all`.
- Magic strings/numbers -> named constants or `as const` lookup objects.

## pattern-improvement
- `switch`/`if` chains on a type or tier -> lookup table (`Record<Tier, Price>`) or strategy objects.
- Hard-wired dependencies (`import { db }` used directly) -> pass dependencies in (dependency injection) so code is testable.
- Primitive obsession (money as `number`, dates as strings) -> small value types (`Money` in cents, `ExpiryDate`).
- Long parameter lists -> one options object.

## rename
- Names that hide intent (`data`, `tmp`, `handle`, `doIt`) -> names that state what and why.

## Judging impact
- **high**: makes important logic testable or removes a real source of bugs/duplication.
- **medium**: clear readability gain in code that changes often.
- **low**: cosmetic.

## Output
For each suggestion: type, location with line range, impact, description, the real before code, the full after code, and the benefit.
