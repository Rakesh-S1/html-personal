---
name: test-coverage-patterns
description: How to estimate test coverage without running tests, prioritise untested code and write actionable test cases with meaningful assertions. Use when analyzing test coverage of a source file.
---

# Test Coverage Patterns

## Estimating coverage statically
1. List every exported function/class and every non-trivial private helper in the source file.
2. For each, list its branches: each `if`/`else`, early `return`/`throw`, `switch` case, `catch`, loop with zero/one/many items.
3. Find tests that call it (directly, or through an exported caller) AND assert on the outcome. A call without an assertion does not count.
4. coverageEstimate ≈ covered branches / total branches × 100, rounded to the nearest 5. No test file → 0.
5. Fixtures, type-only files and constants have little testable behaviour - say so instead of inventing gaps.

## Prioritising gaps
- **critical**: money (charging, pricing, refunds), authentication/authorization, data deletion, security validation.
- **high**: core business rules, error handling paths, state transitions (e.g. subscription upgrade/downgrade).
- **medium**: ordinary logic, formatting with rules, search/filter behaviour.
- **low**: trivial getters, logging.
Always check edge cases: empty input, boundaries (0, 1, max), invalid input, expired dates, case sensitivity, duplicate entries, async failure/rejection.

## Writing an actionable suggestedTest
- Runnable code in the project's framework (Jest/Vitest): `describe` + `it` + `expect`.
- Real inputs and the exact expected value - not "should work correctly".
- One behaviour per `it`; the name states the behaviour (`it('rejects an expired card')`).
- Mock external effects (database, payment gateway, clock) with `jest.fn()`/`vi.fn()` and assert they were (or were not) called.
- Cover both the happy path and the failure path of each branch.

Example:
```ts
describe('searchTodos', () => {
  it('matches titles case-insensitively', () => {
    const todos = [{ id: 1, title: 'Buy Milk', completed: false }];
    expect(searchTodos(todos, 'milk')).toEqual(todos);
  });
  it('returns an empty array when nothing matches', () => {
    expect(searchTodos([], 'x')).toEqual([]);
  });
});
```

## Output
For each gap: type, location (name + line), priority, why it matters, and the full suggested test.
